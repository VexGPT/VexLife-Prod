[VXG RealForever]
Memory Depth Test Campaign A001

One command runs two predecessor-comparable 15-turn lived rounds on exact #403 candidate bytes:
  [Memory Depth Test, 4B 15 Turns]
  [Memory Depth Test, 27B 15 Turns]

The campaign changes only the model between rounds. It keeps Foundation v0.6.3, scenario digest,
80k effective input budget, payload scale 7, 3 sets x 5 turns, and reasoning continuation ON fixed.
It uses only already-downloaded model artifacts and restores the starting model after the campaign.
No model artifact download is authorized by this package.

The canonical RETURN ZIP records each round's exact Foundation/source/model/runtime/configuration,
raw continuity-pressure result/analysis/timing evidence, model-switch transcript, and restore evidence.

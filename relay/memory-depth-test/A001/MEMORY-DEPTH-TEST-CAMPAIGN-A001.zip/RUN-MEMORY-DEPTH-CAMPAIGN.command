#!/bin/bash
set -euo pipefail

CONTINUITY='[VXG RealForever]'
SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then printf '%s' "$candidate"; return 0; fi
  done
  return 1
}
NODE_BIN="$(resolve_exec /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node)" || { echo 'Memory Depth: Node is required.' >&2; exit 10; }
"$NODE_BIN" "$SELF_DIR/campaign.js"

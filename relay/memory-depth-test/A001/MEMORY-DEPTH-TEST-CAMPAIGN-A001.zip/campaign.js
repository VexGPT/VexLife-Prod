#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

const CONTINUITY = '[VXG RealForever]';
const CAMPAIGN_REF = 'campaign.vexlife.memory-depth.baseline-model-readability.a001';
const PRODUCT_REPOSITORY = 'VexGPT/VexLife-Prod';
const PRODUCT_HEAD = '64e8ee70568338f8dbeda50e7d6145e95c09b798';
const PRODUCT_TREE = 'e9002160b07311f5bc5262261690cbafb9d6221c';
const FOUNDATION_VERSION = '0.6.3';
const FOUNDATION_BODY_SHA256 = '1d95f7bbe6d2a3134f50a2f0cb3a0244c93d5343b016a6b4acc892edbd8b77d3';
const SCENARIO_REF = 'scenario.vexlife.continuity-pressure.depth-continuity.v1';
const SCENARIO_SHA256 = '65c81bfdcc0935d261204566bfc05468317c59e962eabceffb9f7e0fca359cc1';
const EFFECTIVE_INPUT_TOKEN_BUDGET = 80000;
const PAYLOAD_SCALE = 7;
const SETS = 3;
const TURNS_PER_SET = 5;
const DEFAULT_CAPABILITY_REQUEST_BLOCK_SIZE = 10;
const MAXIMUM_REQUEST_BLOCKS_PER_TURN = 3;
const SERVICE_ORIGIN = 'http://127.0.0.1:18210';
const RUNTIME_HOME = path.join(os.homedir(), '.vexlife');

const ROUNDS = [
  {
    roundRef: 'memory-depth.4b.15-turns',
    tag: '[Memory Depth Test, 4B 15 Turns]',
    handle: 'heretic-4b',
    modelRef: 'model.vexlife-prod.heretic.qwen3.8-4b-distill.mlx4.d2f8f4028f20',
    modelClass: 'Heretic 4B Distill',
    capabilityRepresentation: 'VEXLIFE_CONTROL_TEXT',
    reachStanding: 'HELD_PROVIDER_BRIDGE',
    historicalReasoningRepresentation: 'ASSISTANT_CONTENT_ENVELOPE',
  },
  {
    roundRef: 'memory-depth.27b.15-turns',
    tag: '[Memory Depth Test, 27B 15 Turns]',
    handle: 'heretic-27b',
    modelRef: 'model.devex.heretic.qwen3.8-27b.mlx4.329658ee8f27',
    modelClass: 'Heretic 27B (4-bit, MLX)',
    capabilityRepresentation: 'PROVIDER_NATIVE_TOOLS',
    reachStanding: 'QUALIFIED',
    historicalReasoningRepresentation: 'PRESERVED_REASONING_FIELD',
  },
];

function sha256Bytes(b) { return crypto.createHash('sha256').update(b).digest('hex'); }
function sha256File(p) { return sha256Bytes(fs.readFileSync(p)); }
function writeJson(p, v) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, JSON.stringify(v, null, 2) + '\n'); }
function readJson(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }
function exists(p) { try { return fs.existsSync(p); } catch { return false; } }
function run(cmd, args, options = {}) {
  const r = spawnSync(cmd, args, {
    cwd: options.cwd,
    env: options.env || process.env,
    encoding: 'utf8',
    maxBuffer: 128 * 1024 * 1024,
    stdio: options.stdio || 'pipe',
  });
  return r;
}
function requireCommand(name, candidates) {
  for (const p of candidates) {
    if (exists(p)) return p;
  }
  const r = run('/usr/bin/env', ['which', name]);
  if (r.status === 0 && r.stdout.trim()) return r.stdout.trim();
  throw new Error(`required executable not found: ${name}`);
}

const GH = requireCommand('gh', ['/opt/homebrew/bin/gh', '/usr/local/bin/gh']);
const GIT = requireCommand('git', ['/usr/bin/git']);
const NODE = process.execPath;
const ZIP = requireCommand('zip', ['/usr/bin/zip']);
const SHASUM = requireCommand('shasum', ['/usr/bin/shasum']);

async function httpJson(method, route, body = null) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(SERVICE_ORIGIN + route, {
      method,
      headers: body == null ? { accept: 'application/json' } : {
        accept: 'application/json',
        'content-type': 'application/json',
      },
      body: body == null ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    if (!response.ok) throw new Error(`${method} ${route} -> HTTP ${response.status}: ${text.slice(0, 1000)}`);
    return JSON.parse(text);
  } finally {
    clearTimeout(timer);
  }
}

function controls(row) {
  return new Set((row?.display?.controls || []).map(x => x.controlRef));
}

async function modelsProjection() {
  return await httpJson('GET', '/api/v1/models');
}

async function modelControl(controlRef, handle) {
  return await httpJson('POST', '/api/v1/models/control', { controlRef, handle });
}

async function sleep(ms) { await new Promise(resolve => setTimeout(resolve, ms)); }

async function switchTo(handle, transcript) {
  let projection = await modelsProjection();
  const target = projection.models.find(x => x.handle === handle);
  if (!target) throw new Error(`target model is not offered by this Home: ${handle}`);
  transcript.push({ at: new Date().toISOString(), phase: 'OBSERVE', handle, projection });
  if (!(target.totalBytes > 0 && target.presentBytes === target.totalBytes)) {
    return { state: 'HELD_MODEL_ARTIFACT_NOT_PRESENT', projection };
  }
  if (projection.servingHandle === handle && projection.selectedHandle === handle && !projection.switchPending && projection.switching == null) {
    return { state: 'ALREADY_SERVING', projection };
  }
  if (projection.switchPending || projection.switching != null) {
    return { state: 'HELD_EXISTING_MODEL_TRANSITION', projection };
  }

  let row = projection.models.find(x => x.handle === handle);
  if (!row.targeted) {
    if (!controls(row).has('SELECT_MODEL')) return { state: 'HELD_SELECT_NOT_LAWFUL', projection };
    projection = await modelControl('SELECT_MODEL', handle);
    transcript.push({ at: new Date().toISOString(), phase: 'SELECT_MODEL', handle, projection });
  }

  projection = await modelsProjection();
  row = projection.models.find(x => x.handle === handle);
  if (projection.servingHandle !== handle) {
    if (!controls(row).has('USE_MODEL')) return { state: 'HELD_USE_NOT_LAWFUL', projection };
    projection = await modelControl('USE_MODEL', handle);
    transcript.push({ at: new Date().toISOString(), phase: 'USE_MODEL', handle, projection });
  }

  const deadline = Date.now() + 240000;
  while (Date.now() < deadline) {
    await sleep(1000);
    projection = await modelsProjection();
    transcript.push({ at: new Date().toISOString(), phase: 'POLL', handle, projection });
    if (projection.servingHandle === handle && projection.selectedHandle === handle && !projection.switchPending && projection.switching == null) {
      return { state: 'SWITCHED', projection };
    }
    const outcome = projection.lastOutcome;
    if (outcome && outcome.handle === handle && outcome.state === 'FAILED') {
      return { state: 'HELD_SWITCH_FAILED', projection };
    }
  }
  return { state: 'HELD_SWITCH_TIMEOUT', projection };
}

function runtimeBinding() {
  const candidates = [
    path.join(RUNTIME_HOME, 'runtime', 'vexlife-prod', 'model-binding.json'),
    path.join(RUNTIME_HOME, 'runtime', 'vexlife-prod', 'model-selection.json'),
  ];
  for (const p of candidates) {
    if (exists(p)) {
      try { return { path: p, value: readJson(p) }; } catch {}
    }
  }
  return { path: null, value: null };
}

function filteredRuntimeBinding(binding) {
  const v = binding?.value || {};
  const keys = [
    'schemaVersion','modelRef','modelProfileRef','artifactRef','artifactContentSetSha256',
    'runtimeAdapterRef','runtimeClass','endpoint','requestModel','runtimeReceiptRef'
  ];
  const out = {};
  for (const k of keys) if (v[k] !== undefined) out[k] = v[k];
  return { sourcePath: binding?.path || null, ...out };
}

function sourceSetup(repoRoot) {
  const foundationPath = path.join(repoRoot, 'src/jvmMain/resources/foundational/vex-foundational-field.json');
  const revisionsPath = path.join(repoRoot, 'src/jvmMain/resources/foundational/vex-foundational-field.revisions.json');
  const scenarioPath = path.join(repoRoot, 'tools/continuity-pressure/scenarios/depth-continuity-v1.json');
  const foundation = readJson(foundationPath);
  const revisions = readJson(revisionsPath);
  const latest = revisions.revisions[revisions.revisions.length - 1];
  if (foundation.version !== FOUNDATION_VERSION) throw new Error(`Foundation version mismatch: ${foundation.version}`);
  if (latest.version !== FOUNDATION_VERSION || latest.bodySha256 !== FOUNDATION_BODY_SHA256) {
    throw new Error(`Foundation revision mismatch: ${latest.version}/${latest.bodySha256}`);
  }
  if (sha256File(scenarioPath) !== SCENARIO_SHA256) throw new Error('scenario digest mismatch');
  return {
    product: { repository: PRODUCT_REPOSITORY, head: PRODUCT_HEAD, tree: PRODUCT_TREE },
    foundation: {
      version: foundation.version,
      bodySha256: latest.bodySha256,
      rawFileSha256: sha256File(foundationPath),
      moduleOrder: foundation.modules.map(m => m.moduleRef),
      effectAuthorityGranted: foundation.effectAuthorityGranted,
    },
    contextConstruction: {
      contextProfile: 'PRODUCT_DEFAULT',
      explicitContextProfileSupplied: false,
      effectiveInputTokenBudget: EFFECTIVE_INPUT_TOKEN_BUDGET,
      ordinaryInputTokenBudget: 192000,
      reservedOutputTokens: 16000,
      capabilityExchangeAllowanceTokens: 24000,
      capabilityRequestBlockSize: DEFAULT_CAPABILITY_REQUEST_BLOCK_SIZE,
      maximumCapabilityRequestBlocksPerTurn: MAXIMUM_REQUEST_BLOCKS_PER_TURN,
      reasoningContinuationEnabled: true,
      memorySource: 'SCRATCH_HOME_NO_COMMITTED_DAILY_MEMORY_UNLESS_SCENARIO_FORMS_ONE',
      personContext: 'replyLanguage from scratch canonical PersonSettings',
    },
    scenario: {
      ref: SCENARIO_REF,
      sha256: SCENARIO_SHA256,
      effectiveInputTokenBudget: EFFECTIVE_INPUT_TOKEN_BUDGET,
      payloadScale: PAYLOAD_SCALE,
      sets: SETS,
      turnsPerSet: TURNS_PER_SET,
      expectedTotalTurns: SETS * TURNS_PER_SET,
      predecessorBaseline: { firstRolloverTurn: 10, successorStartTurn: 11 },
    },
  };
}

function copyIfPresent(src, dst) {
  if (!exists(src)) return;
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
}

function runRound(repoRoot, campaignRoot, round, setup, serviceBefore) {
  const roundDir = path.join(campaignRoot, 'rounds', round.roundRef);
  const rawDir = path.join(roundDir, 'raw');
  fs.mkdirSync(rawDir, { recursive: true });
  const startedAt = new Date().toISOString();
  const binding = runtimeBinding();
  const observedModelRef = binding.value?.modelRef || null;
  const roundConfig = {
    schemaVersion: 'vexlife.memory-depth-round/v1',
    continuity: CONTINUITY,
    campaignRef: CAMPAIGN_REF,
    roundRef: round.roundRef,
    humanTag: round.tag,
    startedAt,
    sourceSetup: setup,
    model: {
      handle: round.handle,
      expectedModelRef: round.modelRef,
      observedModelRef,
      class: round.modelClass,
      capabilityRepresentation: round.capabilityRepresentation,
      reachStanding: round.reachStanding,
      historicalReasoningRepresentation: round.historicalReasoningRepresentation,
    },
    runtimeBinding: filteredRuntimeBinding(binding),
    serviceModelProjection: serviceBefore,
    testIntent: 'Compare Foundation readability and continuity depth while changing only the model; preserve the predecessor 15-turn pressure shape.',
  };
  writeJson(path.join(roundDir, 'round-config.json'), roundConfig);

  if (observedModelRef !== round.modelRef) {
    writeJson(path.join(roundDir, 'round-result.json'), {
      schemaVersion: 'vexlife.memory-depth-round-result/v1',
      state: 'HELD_RUNTIME_BINDING_MISMATCH',
      expectedModelRef: round.modelRef,
      observedModelRef,
      effectsPerformed: false,
    });
    return { roundRef: round.roundRef, tag: round.tag, state: 'HELD_RUNTIME_BINDING_MISMATCH', modelRef: observedModelRef };
  }

  const scenarioPath = path.join(repoRoot, 'tools/continuity-pressure/scenarios/depth-continuity-v1.json');
  const args = [
    path.join(repoRoot, 'tools/continuity-pressure/run.mjs'),
    '--stage','full',
    '--scenario-ref',SCENARIO_REF,
    '--scenario-file',scenarioPath,
    '--result-dir',rawDir,
    '--runtime-home',RUNTIME_HOME,
    '--experiment-window',
    '--effective-input-token-budget',String(EFFECTIVE_INPUT_TOKEN_BUDGET),
    '--payload-scale',String(PAYLOAD_SCALE),
    '--sets',String(SETS),
    '--turns-per-set',String(TURNS_PER_SET),
  ];
  const env = { ...process.env, GRADLE_OPTS: '-Dorg.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=768m -XX:ReservedCodeCacheSize=512m' };
  const full = run(NODE, args, { cwd: repoRoot, env });
  fs.writeFileSync(path.join(roundDir, 'harness.stdout.log'), full.stdout || '');
  fs.writeFileSync(path.join(roundDir, 'harness.stderr.log'), full.stderr || '');

  let analyzeExit = null;
  if (exists(path.join(rawDir, 'result.json'))) {
    const analyze = run(NODE, [
      path.join(repoRoot, 'tools/continuity-pressure/run.mjs'),
      '--stage','analyze',
      '--scenario-ref',SCENARIO_REF,
      '--scenario-file',scenarioPath,
      '--result-dir',rawDir,
    ], { cwd: repoRoot, env });
    analyzeExit = analyze.status;
    fs.appendFileSync(path.join(roundDir, 'harness.stdout.log'), analyze.stdout || '');
    fs.appendFileSync(path.join(roundDir, 'harness.stderr.log'), analyze.stderr || '');
  }

  for (const name of ['result.json','analysis.json','held.json','transition-timing.json','host-scan-timing.json']) {
    copyIfPresent(path.join(rawDir, name), path.join(roundDir, name));
  }
  const nested = fs.readdirSync(rawDir).find(n => n.startsWith('continuity-pressure-') && n.endsWith('.zip'));
  if (nested) copyIfPresent(path.join(rawDir, nested), path.join(roundDir, nested));

  let result = null;
  if (exists(path.join(rawDir, 'result.json'))) {
    try { result = readJson(path.join(rawDir, 'result.json')); } catch {}
  }
  const endedAt = new Date().toISOString();
  const summary = {
    schemaVersion: 'vexlife.memory-depth-round-result/v1',
    roundRef: round.roundRef,
    humanTag: round.tag,
    state: result ? 'RESULT' : (exists(path.join(rawDir,'held.json')) ? 'HELD' : 'NO_RESULT'),
    harnessExit: full.status,
    analyzeExit,
    startedAt,
    endedAt,
    modelRef: result?.source?.modelRef || observedModelRef,
    resultStatus: result?.status || null,
    turnCount: Array.isArray(result?.turns) ? result.turns.length : null,
    summary: result?.summary || null,
    firstRolloverTurn: result?.summary?.firstRolloverTurn ?? null,
    successorStartTurn: result?.summary?.successorStartTurn ?? null,
    rawEvidenceDirectory: `rounds/${round.roundRef}/raw`,
  };
  writeJson(path.join(roundDir, 'round-result.json'), summary);
  return summary;
}

function manifestFor(dir) {
  const files = {};
  function walk(current) {
    for (const name of fs.readdirSync(current).sort()) {
      const p = path.join(current, name);
      const s = fs.statSync(p);
      if (s.isDirectory()) walk(p);
      else if (s.isFile()) {
        const rel = path.relative(dir, p).split(path.sep).join('/');
        if (rel === 'manifest.json') continue;
        const b = fs.readFileSync(p);
        files[rel] = { sha256: sha256Bytes(b), bytes: b.length };
      }
    }
  }
  walk(dir);
  return files;
}

(async () => {
  const downloads = path.join(os.homedir(), 'Downloads');
  fs.mkdirSync(downloads, { recursive: true });
  const root = fs.mkdtempSync(path.join(downloads, '.vexlife-memory-depth-a001.'));
  const repoRoot = path.join(root, 'VexLife-Prod');
  const evidenceDir = path.join(root, 'evidence');
  fs.mkdirSync(evidenceDir, { recursive: true });
  let initialModels = null;
  let initialSourceCurrentness = null;
  let startingHandle = null;
  let restore = { attempted: false, state: 'NOT_NEEDED' };
  const modelSwitchTranscript = [];
  const roundSummaries = [];
  let campaignState = 'RUNNING';
  let campaignFailure = null;

  try {
    const auth = run(GH, ['auth','status','--hostname','github.com']);
    if (auth.status !== 0) throw new Error('GitHub authentication is required');
    let clone = run(GH, ['repo','clone',PRODUCT_REPOSITORY,repoRoot,'--','--no-checkout']);
    if (clone.status !== 0) throw new Error('repository clone failed: ' + (clone.stderr || '').slice(0,1000));
    let checkout = run(GIT, ['-C',repoRoot,'checkout','--detach',PRODUCT_HEAD]);
    if (checkout.status !== 0) throw new Error('exact Product checkout failed');
    const observedHead = run(GIT, ['-C',repoRoot,'rev-parse','HEAD']).stdout.trim();
    const observedTree = run(GIT, ['-C',repoRoot,'rev-parse','HEAD^{tree}']).stdout.trim();
    const dirty = run(GIT, ['-C',repoRoot,'status','--porcelain=v1','-uall']).stdout.trim();
    if (observedHead !== PRODUCT_HEAD || observedTree !== PRODUCT_TREE || dirty) throw new Error('exact Product source identity/currentness check failed');

    const setup = sourceSetup(repoRoot);
    writeJson(path.join(evidenceDir, 'campaign-setup.json'), {
      schemaVersion: 'vexlife.memory-depth-campaign-setup/v1',
      continuity: CONTINUITY,
      campaignRef: CAMPAIGN_REF,
      humanMnemonicFamily: '[Memory Depth Test, <model> <turns>]',
      sourceSetup: setup,
      design: {
        variableChangedInA001: 'MODEL_ONLY',
        heldConstant: ['Foundation v0.6.3','scenario digest','80k effective input budget','payload scale 7','3 sets x 5 turns','reasoning continuation ON'],
        nextTierNotRunYet: '[Memory Depth Test, <model> 35 Turns, 3 Rollovers]',
        whyNextTierHeld: 'Preserve causal readability: first distinguish Foundation/model readability before repeated-rollover endurance.',
      },
      rounds: ROUNDS,
    });

    try { initialSourceCurrentness = await httpJson('GET','/api/v1/source-currentness'); }
    catch (e) { throw new Error('VexLife local service is required for reversible model switching: ' + e.message); }
    initialModels = await modelsProjection();
    writeJson(path.join(evidenceDir, 'service-source-currentness-before.json'), initialSourceCurrentness);
    writeJson(path.join(evidenceDir, 'models-before.json'), initialModels);
    if (initialModels.switchPending || initialModels.switching != null) throw new Error('an existing model switch/pending selection is already in progress; campaign will not overwrite it');
    if (!initialModels.servingHandle || initialModels.selectedHandle !== initialModels.servingHandle) throw new Error('starting model selection is not settled; campaign will not overwrite it');
    startingHandle = initialModels.servingHandle;

    for (const round of ROUNDS) {
      const switchResult = await switchTo(round.handle, modelSwitchTranscript);
      writeJson(path.join(evidenceDir, `switch-${round.handle}.json`), switchResult);
      if (!['ALREADY_SERVING','SWITCHED'].includes(switchResult.state)) {
        const held = { roundRef: round.roundRef, humanTag: round.tag, state: switchResult.state, modelRef: null };
        roundSummaries.push(held);
        writeJson(path.join(evidenceDir, 'campaign-progress.json'), { roundSummaries, modelSwitchTranscript });
        continue;
      }
      const projection = await modelsProjection();
      const summary = runRound(repoRoot, evidenceDir, round, setup, projection);
      roundSummaries.push(summary);
      writeJson(path.join(evidenceDir, 'campaign-progress.json'), { roundSummaries, modelSwitchTranscript });
    }
    campaignState = roundSummaries.every(r => r.state === 'RESULT') ? 'COMPLETE' : 'PARTIAL';
  } catch (error) {
    campaignState = 'SAFE_FAILURE';
    campaignFailure = String(error && error.stack ? error.stack : error);
  } finally {
    if (startingHandle) {
      try {
        const current = await modelsProjection();
        if (current.servingHandle !== startingHandle || current.selectedHandle !== startingHandle || current.switchPending || current.switching != null) {
          restore.attempted = true;
          const r = await switchTo(startingHandle, modelSwitchTranscript);
          restore.state = r.state;
          restore.projection = r.projection;
        }
        const after = await modelsProjection();
        restore.after = after;
        if (after.servingHandle !== startingHandle || after.selectedHandle !== startingHandle || after.switchPending || after.switching != null) {
          restore.state = 'RESTORE_NOT_CONFIRMED';
          campaignState = campaignState === 'COMPLETE' ? 'PARTIAL_RESTORE_NOT_CONFIRMED' : campaignState;
        } else if (restore.state === 'NOT_NEEDED') {
          restore.state = 'CONFIRMED_UNCHANGED';
        } else if (restore.state === 'ALREADY_SERVING' || restore.state === 'SWITCHED') {
          restore.state = 'RESTORED';
        }
      } catch (error) {
        restore = { attempted: true, state: 'RESTORE_FAILED', error: String(error && error.stack ? error.stack : error) };
        if (campaignState === 'COMPLETE') campaignState = 'PARTIAL_RESTORE_FAILED';
      }
    }

    writeJson(path.join(evidenceDir, 'model-switch-transcript.json'), modelSwitchTranscript);
    writeJson(path.join(evidenceDir, 'restore.json'), restore);
    try { writeJson(path.join(evidenceDir, 'models-after.json'), await modelsProjection()); } catch {}
    try { writeJson(path.join(evidenceDir, 'service-source-currentness-after.json'), await httpJson('GET','/api/v1/source-currentness')); } catch {}

    const comparison = {
      schemaVersion: 'vexlife.memory-depth-comparison/v1',
      continuity: CONTINUITY,
      campaignRef: CAMPAIGN_REF,
      state: campaignState,
      failure: campaignFailure,
      baselinePurpose: 'Model readability comparison under one unchanged Foundation/continuity pressure structure.',
      rounds: roundSummaries,
      interpretationRules: [
        '4B PASS + 27B PASS -> Foundation/depth relationship is legible across both ends of the current Qwen size range.',
        '4B FAIL + 27B PASS -> suspect model/provider capacity/representation before changing Foundation.',
        '4B FAIL + 27B FAIL -> inspect shared Foundation/prompt/scenario/continuity architecture before tuning a model-specific path.',
        'Do not infer a generic 4B reach defect from this campaign: 4B generic reach is intentionally HELD_PROVIDER_BRIDGE; exact Conversation Source Return remains separate.',
        'Do not choose a winner from answer accuracy alone; inspect rollover behavior, source custody, honest absence, telemetry, capability/source selection, and latency together.',
      ],
      nextDecision: 'Assistant reviews returned exact round evidence and decides whether 9B is needed as a gradient or the 35-turn / 3-rollover endurance tier is earned.',
      restore,
    };
    writeJson(path.join(evidenceDir, 'COMPARISON.json'), comparison);
    fs.writeFileSync(path.join(evidenceDir, 'README.txt'), [
      CONTINUITY,
      'MEMORY_DEPTH_TEST_CAMPAIGN_A001/v1',
      `campaignRef=${CAMPAIGN_REF}`,
      `state=${campaignState}`,
      `productHead=${PRODUCT_HEAD}`,
      `productTree=${PRODUCT_TREE}`,
      `foundationVersion=${FOUNDATION_VERSION}`,
      `foundationBodySha256=${FOUNDATION_BODY_SHA256}`,
      `scenarioRef=${SCENARIO_REF}`,
      `scenarioSha256=${SCENARIO_SHA256}`,
      `rounds=${ROUNDS.map(r => r.tag).join(' | ')}`,
      `startingModelHandle=${startingHandle || 'UNKNOWN'}`,
      `restoreState=${restore.state}`,
      `failure=${campaignFailure || 'NONE'}`,
      '',
      'Upload the canonical RETURN ZIP. The assistant will compare every round and decide the next test tier.',
      '',
    ].join('\n'));

    const manifest = {
      schemaVersion: 'vexlife.memory-depth-campaign-return-manifest/v1',
      continuity: CONTINUITY,
      campaignRef: CAMPAIGN_REF,
      productHead: PRODUCT_HEAD,
      productTree: PRODUCT_TREE,
      state: campaignState,
      files: manifestFor(evidenceDir),
    };
    writeJson(path.join(evidenceDir, 'manifest.json'), manifest);

    const staging = path.join(os.homedir(), 'Downloads', 'RETURN-MEMORY-DEPTH-TEST-CAMPAIGN-A001.zip');
    try { fs.unlinkSync(staging); } catch {}
    const z = run(ZIP, ['-q','-r',staging,'.'], { cwd: evidenceDir });
    if (z.status !== 0) throw new Error('return ZIP formation failed: ' + z.stderr);
    const digest = sha256File(staging);
    const final = path.join(os.homedir(), 'Downloads', `RETURN-MEMORY-DEPTH-TEST-CAMPAIGN-A001--sha256-${digest}.zip`);
    try { fs.unlinkSync(final); } catch {}
    fs.renameSync(staging, final);
    process.stdout.write(`MEMORY DEPTH: RETURN ${final}\nMEMORY DEPTH: sha256 ${digest}\nMEMORY DEPTH: upload that exact RETURN ZIP.\n`);

    // Remove the temporary clone/evidence only after the canonical RETURN is sealed outside it.
    try { fs.rmSync(root, { recursive: true, force: true }); } catch {}
  }
})().catch(error => {
  console.error(error && error.stack ? error.stack : error);
  process.exitCode = 1;
});

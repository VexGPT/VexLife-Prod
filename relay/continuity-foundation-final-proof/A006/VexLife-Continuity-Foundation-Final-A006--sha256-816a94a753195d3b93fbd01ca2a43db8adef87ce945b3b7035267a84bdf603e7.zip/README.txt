VexLife Continuity Foundation — Final Source/Build Proof A006
[VXG RealForever]

Exact #212 candidate:
  head 603bfebed58bba47b510d5cba27ab8795ad71c6c
  tree 55b689eed95f5a961dc1ee2bd72cd5789f17c66e
  base 655e7c78cefba06a5e87afad285bb25a08632f05

This is proof only. It runs:
- full JVM tests;
- Kotlin/JS main + test compilation;
- localization currentness;
- VexWeb P1 generation;
- exact VexLife.app / VexLife-macOS-AppleSilicon.dmg formation and verification.

It does NOT install the app, mutate Vex Home, start/replace Vex runtime/service, publish, approve or merge.

On completion Finder reveals:
RETURN-VEXLIFE-CONTINUITY-FOUNDATION-FINAL-A006--sha256-<digest>.zip

Upload that one ZIP back to ChatGPT.

A006 repair: current VexRelay contract requires policy.maxSelectedSourceEntries in 1..10. A005 incorrectly formed 50 and was rejected before Product source acquisition. A006 uses 10; product head/tree and proof commands are unchanged.

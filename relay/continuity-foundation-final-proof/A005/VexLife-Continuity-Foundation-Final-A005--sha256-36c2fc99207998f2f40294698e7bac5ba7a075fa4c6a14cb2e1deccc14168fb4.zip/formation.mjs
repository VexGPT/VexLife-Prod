#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const SDK_HEAD = '8543c7d755faba04d4c4019c02e84f992667918a';
const BASE = '655e7c78cefba06a5e87afad285bb25a08632f05';
const HEAD = '603bfebed58bba47b510d5cba27ab8795ad71c6c';
const TREE = '55b689eed95f5a961dc1ee2bd72cd5789f17c66e';
const BRANCH = 'VXG-111626-continuity-foundation-merge-candidate-a001';
const changedPaths = [
  "docs/foundation/DIRECT-PERSONAL-COMPANION.md",
  "docs/foundation/VEXLOGGER.md",
  "localization/strings/manifest.json",
  "localization/strings/source/workspace.json",
  "src/commonMain/kotlin/vexlife/model/VexLifeModelsFamily.kt",
  "src/commonMain/kotlin/vexlife/model/heretic/HereticArtifactDeliveryCatalog.kt",
  "src/commonMain/kotlin/vexlife/model/heretic/HereticCompanionRepresentation.kt",
  "src/commonMain/kotlin/vexlife/model/heretic/HereticModelCatalog.kt",
  "src/commonMain/kotlin/vexlife/model/heretic/HereticModelConfiguration.kt",
  "src/commonMain/kotlin/vexlife/web/VexLifeWebP1RuntimeArtifacts.kt",
  "src/commonTest/kotlin/vexlife/model/VexLifeModelsFamilyTest.kt",
  "src/commonTest/kotlin/vexlife/model/heretic/HereticModelCatalogTest.kt",
  "src/jvmMain/kotlin/vexlife/capability/VexLifeCapabilityBridge.kt",
  "src/jvmMain/kotlin/vexlife/capability/VexLifeReachDefinitions.kt",
  "src/jvmMain/kotlin/vexlife/companion/DirectCompanionConnection.kt",
  "src/jvmMain/kotlin/vexlife/companion/DirectCompanionTurn.kt",
  "src/jvmMain/kotlin/vexlife/companion/DirectPromptContext.kt",
  "src/jvmMain/kotlin/vexlife/companion/HarmonyCapabilityTools.kt",
  "src/jvmMain/kotlin/vexlife/companion/HarmonyResponseSplitter.kt",
  "src/jvmMain/kotlin/vexlife/local/VexLifeProdLocalSetup.kt",
  "src/jvmMain/kotlin/vexlife/logging/VexLogger.kt",
  "src/jvmMain/kotlin/vexlife/model/VexLifeModels.kt",
  "src/jvmMain/kotlin/vexlife/model/heretic/runtime/FileHereticModelConfigurationStore.kt",
  "src/jvmMain/kotlin/vexlife/model/heretic/runtime/HereticPersistentRuntime.kt",
  "src/jvmMain/kotlin/vexlife/model/heretic/runtime/StableVexLifeHereticRuntimeCompatibility.kt",
  "src/jvmMain/kotlin/vexlife/service/VexLifeProdLocalService.kt",
  "src/jvmMain/kotlin/vexlife/setup/VexLifeProdSetupModel.kt",
  "src/jvmTest/kotlin/vexlife/capability/VexLifeCapabilityReachTest.kt",
  "src/jvmTest/kotlin/vexlife/companion/DirectCompanionCapabilityTurnTest.kt",
  "src/jvmTest/kotlin/vexlife/companion/DirectPromptContextTest.kt",
  "src/jvmTest/kotlin/vexlife/companion/DirectProviderStageMeasurementTest.kt",
  "src/jvmTest/kotlin/vexlife/companion/HarmonyCapabilityToolsTest.kt",
  "src/jvmTest/kotlin/vexlife/companion/HarmonyResponseSplitterTest.kt",
  "src/jvmTest/kotlin/vexlife/local/VexLifeProdLocalSetupTest.kt",
  "src/jvmTest/kotlin/vexlife/logging/VexLoggerTest.kt",
  "src/jvmTest/kotlin/vexlife/model/VexLifeModelsTest.kt",
  "src/jvmTest/kotlin/vexlife/model/heretic/runtime/FileHereticModelConfigurationStoreTest.kt",
  "src/jvmTest/kotlin/vexlife/model/heretic/runtime/HereticModelMaterializationTest.kt",
  "src/jvmTest/kotlin/vexlife/model/heretic/runtime/HereticPersistentRuntimeTest.kt",
  "src/jvmTest/kotlin/vexlife/model/heretic/runtime/StableVexLifeHereticRuntimeCompatibilityTest.kt",
  "src/jvmTest/kotlin/vexlife/setup/VexLifeProdMacFrontDoorTest.kt",
  "src/jvmTest/kotlin/vexlife/setup/VexLifeProdSetupModelTest.kt"
];

const sdkRoot = process.argv[2];
const outputDirectory = process.argv[3];
if (!sdkRoot || !path.isAbsolute(sdkRoot)) throw new Error('SDK_ROOT_ABSOLUTE_REQUIRED');
if (!outputDirectory || !path.isAbsolute(outputDirectory)) throw new Error('OUTPUT_DIRECTORY_ABSOLUTE_REQUIRED');

const observedHead = spawnSync('/usr/bin/git', ['-C', sdkRoot, 'rev-parse', 'HEAD'], { encoding: 'utf8' });
if (observedHead.status !== 0 || observedHead.stdout.trim() !== SDK_HEAD) {
  throw new Error(`SDK_HEAD_MISMATCH:${observedHead.stdout.trim()}`);
}
const dirty = spawnSync('/usr/bin/git', ['-C', sdkRoot, 'status', '--porcelain=v1', '--untracked-files=all'], { encoding: 'utf8' });
if (dirty.status !== 0 || dirty.stdout.trim()) throw new Error(`SDK_SOURCE_NOT_CLEAN:${dirty.stdout.trim()}`);

const contract = JSON.parse(fs.readFileSync(path.join(sdkRoot, 'docs/private-continuity/vexrelay/current-contract.json'), 'utf8'));
if (contract.contractRef !== 'source.vexrelay.current-contract/v1') throw new Error('RELAY_CONTRACT_REF_MISMATCH');
if (!contract.acceptedRecipeFamilies?.includes('ExactHeadSourceOwnerProof')) throw new Error('SOURCE_OWNER_RECIPE_NOT_CURRENT');
if (!contract.acceptedAdapters?.some((entry) => entry.adapterRef === 'adapter.vexlocalbridge.native-vexrelay-task-archive/v1' && entry.state === 'TERMINAL_ACCEPTED_CURRENT')) {
  throw new Error('NATIVE_VEXRELAY_CARRIER_NOT_CURRENT');
}
for (const rel of [
  'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
  'lib/vexlocalbridge/vexrelay-task-archive.js',
  'lib/vexlocalbridge/templates/RUN-VEX-TASK.command',
  'lib/vexrelay/recipe-compiler.mjs',
]) {
  if (!fs.existsSync(path.join(sdkRoot, rel))) throw new Error(`REQUIRED_SDK_SOURCE_MISSING:${rel}`);
}

const formationModule = await import(pathToFileURL(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs')).href);
const nativeCarrier = createRequire(import.meta.url)(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js'));
const effects = ['READ_REPOSITORY','CHECK_STATE','QUERY_PROVIDER','RUN_LOCAL_COMMAND','FORM_RESULT'];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.continuity-foundation-final-proof.source-owner.v1',
  attemptRef: 'attempt.vexlife-prod.continuity-foundation-final-proof.source-owner.a005',
  requestRef: 'request.vexlife-prod.continuity-foundation-final-proof.source-owner.a005',
  correlationRef: 'correlation.vexlife-prod.continuity-foundation-final-proof.source-owner.a005',
  packageRef: 'package.vexlife-prod.continuity-foundation-final-proof.source-owner.a005',
  original: {
    originalIntent: 'Prove the exact #212 merge candidate after VexArchitecture naming and relationship convergence.',
    originalGoal: 'Run full source/build proof including the exact macOS application DMG without mutating the installed Product.',
    userProtectedIntent: 'Preserve the stable checkpoint and exact #212 candidate; no Product Home, runtime, service, publication or merge effects during proof.',
    sourceRefs: ['github.pull.VexGPT.VexLife-Prod.212','source.vexrelay.current-contract/v1'],
  },
  lane: {
    entryClass: 'SAME_LANE_SUCCESSOR',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'github.pull.VexGPT.VexLife-Prod.212.continuity-foundation-merge-candidate',
    parentRootRef: 'github.repository.VexGPT.VexLife-Prod',
    workRef: 'github.pull.VexGPT.VexLife-Prod.continuity-final-proof',
    claimRef: 'claim.read-only-source-build-proof.vexlife-prod.pr212',
    returnRouteRef: 'return.victor.vexlife-prod.continuity-foundation-final-proof.a005',
    ownerRef: 'github.pull.VexGPT.VexLife-Prod.212.continuity-foundation-merge-candidate',
    rootHubRef: 'github.repository.VexGPT.VexLife-Prod',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.continuity-foundation-final-proof.a005',
    instanceRef: 'instance.vexlife-prod.continuity-foundation-final-proof.a005',
    occupancyRef: 'occupancy.vexlife-prod.continuity-foundation-final-proof.a005',
    providerBindingRef: 'provider.macos-victor.vexlife-prod.continuity-foundation-final-proof.a005',
    threadRef: 'thread.vexlife-prod.continuity-foundation-final-proof.a005',
    authorityEnvelopeRef: 'authority-envelope.vexlife-prod.continuity-foundation-final-proof.a005',
  },
  capabilities: { platformGitHubRead: 'AVAILABLE', platformGitHubWrite: 'AVAILABLE' },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-continuity-foundation-final-proof-a005',
    duplicateAttemptMarker: 'marker.vexlife-prod-continuity-foundation-final-proof-a005',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: new Date().toISOString(),
    expiresAtOrNull: null,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.continuity-foundation-final-proof',
    projectPath: 'workspace',
    createRoot: true,
    createProjectPath: true,
  },
  repositories: [{
    repositoryRef: 'primary',
    mode: 'CLONE_IN_WORKSPACE',
    cloneTransport: 'GIT',
    cloneUrl: 'https://github.com/VexGPT/VexLife-Prod.git',
    nameWithOwner: 'VexGPT/VexLife-Prod',
    localPath: 'repositories/primary',
    remote: 'origin',
    baseBranch: 'main',
    acceptedBase: BASE,
    checkoutRef: HEAD,
    expectedHead: HEAD,
    branch: BRANCH,
  }],
  authority: {
    authorityRef: 'user.request.vexlife-prod.continuity-foundation-final-proof.2026-11-16',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: [...effects],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: [...effects],
    heldEffects: ['WRITE_SOURCE','CREATE_COMMIT','PUSH_BRANCH','CREATE_PULL_REQUEST','APPROVE_EXACT_HEAD','MARK_READY','ORDINARY_MERGE','MODEL_RUNTIME_EFFECT','PRODUCT_HOME_MUTATION','SERVICE_INSTALL_OR_START'],
    repositoryMembranes: [{ repositoryRef: 'primary', allowedPaths: changedPaths }],
    allowedExecutables: ['bash'],
    allowedEnvironment: [],
    remoteObservationOwner: 'Operations',
    allowMutationLoop: false,
    stopConditions: ['STOP_ON_UNKNOWN','STOP_ON_PATH_ESCAPE','STOP_ON_AUTH_BLOCK','STOP_ON_TEST_FAILURE'],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.continuity-foundation-final.pr212',
    sourceVersionRef: `git:${HEAD}`,
    overlapEvidenceRef: 'github.pull.VexGPT.VexLife-Prod.212',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: changedPaths.map((p) => ({ repositoryRef: 'primary', path: p })),
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 50,
    maxSelectedSourceBytes: 3000000,
    maxDiffBytes: 8000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: true,
    signoffCommit: true,
    draftPullRequest: true,
  },
};

const packageProof = `set -euo pipefail
./gradlew --no-daemon -PvexlifeAppVersion=0.0.0 archiveVexLifeProdMacApplication
SHA="$(git rev-parse HEAD)"
[ "$SHA" = "${HEAD}" ]
APP_DIR="build/vexlife-prod-mac-application/$SHA"
test -f "$APP_DIR/VexLife-macOS-AppleSilicon.dmg"
test -f "$APP_DIR/VexLife-macOS-AppleSilicon.dmg.sha256"
test -f "$APP_DIR/VexLife-macOS-AppleSilicon.receipt.json"
(cd "$APP_DIR" && /usr/bin/shasum -a 256 -c VexLife-macOS-AppleSilicon.dmg.sha256)
/usr/bin/hdiutil verify "$APP_DIR/VexLife-macOS-AppleSilicon.dmg"
printf 'VEXLIFE_FINAL_DMG_SHA256=%s\n' "$(/usr/bin/shasum -a 256 "$APP_DIR/VexLife-macOS-AppleSilicon.dmg" | /usr/bin/awk '{print $1}')"
`;

const stage = {
  repositoryRef: 'primary',
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: BRANCH,
  proofCommands: [
    {
      command: 'bash',
      args: ['./gradlew','jvmTest','--no-daemon','--stacktrace'],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity-foundation-final.jvm',
      timeoutMs: 1800000,
    },
    {
      command: 'bash',
      args: ['./gradlew','compileKotlinJs','compileTestKotlinJs','checkVexLifeStrings','generateVexLifeWebP1','--no-daemon','--stacktrace'],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity-foundation-final.js-currentness',
      timeoutMs: 1800000,
    },
    {
      command: 'bash',
      args: ['-lc', packageProof],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity-foundation-final.mac-app-dmg',
      timeoutMs: 3600000,
    },
  ],
  maxFiles: 50,
  stateRef: 'state.vexlife-prod.continuity-foundation-final.before-a005',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal: 'Prove the exact #212 merge candidate and macOS application artifact after naming convergence.',
  remainingGoals: ['Consume canonical return.','Run fresh semantic/lifecycle review only if exact source/build proof passes.'],
  onPass: {
    lifecycleState: 'ASSURANCE_PENDING',
    nextFunction: 'F13.RUN_FRESH_ASSURANCE',
    nextOwner: 'Operations',
    whyThisIsNext: 'Exact source/build proof is complete; semantic/lifecycle assurance remains separate.',
  },
  resultFilename: 'RETURN-VEXLIFE-CONTINUITY-FOUNDATION-FINAL-A005.zip',
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef: 'user.request.2026-11-16.vexlife-continuity-foundation-final-proof',
  transactionRef: 'transaction.vexlife-prod.continuity-foundation-final.pr212.a005',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: ['effect.source-mutation','effect.publication','effect.model-runtime','effect.product-home','effect.service-lifecycle','effect.merge'],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexlife-prod.continuity-foundation-final.outer.v1',
  attemptRef: 'attempt.vexlife-prod.continuity-foundation-final.outer.a005',
  packageRef: 'package.vexlife-prod.continuity-foundation-final.outer.a005',
  requestRef: 'request.vexlife-prod.continuity-foundation-final.outer.a005',
  correlationRef: 'correlation.vexlife-prod.continuity-foundation-final.outer.a005',
  taskStorageKey: 'vexlife-prod-continuity-foundation-final-pr212',
  attemptStorageKey: 'attempt-a005',
  requestingRoleRef: 'Operations[VexLifeContinuity]',
  requestingInstanceRef: 'instance.vexlife-prod.continuity-foundation-final.outer.a005',
  parentOperationsRef: 'github.pull.VexGPT.VexLife-Prod.212',
  returnRouteRef: 'return.victor.vexlife-prod.continuity-foundation-final-proof.a005',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: 'VexGPT/VexLife-Prod',
  baseRefOrNull: BASE,
  headRefOrNull: HEAD,
  treeRefOrNull: TREE,
  branchRefOrNull: BRANCH,
  claimRefOrNull: 'github.pull.VexGPT.VexLife-Prod.212',
  exactPathRefs: changedPaths,
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'pending-source-managed-binding',
    transactionRef: 'pending-source-managed-binding',
    transactionVersion: 1,
    allowedEffectRefs: ['pending-source-managed-binding'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: nativeCarrier.VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: nativeCarrier.VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [{ path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) }],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexlife-prod-continuity-foundation-final-outer-a005',
  stopConditions: ['stop.on.identity.drift','stop.on.test.failure','stop.on.result.integrity'],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const formed = await formationModule.formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'VexLife-Continuity-Foundation-Final-A005',
  ttlMs: 12 * 60 * 60 * 1000,
});
if (formed.outer.formationEvidence.finalByteQualification !== 'PASS') throw new Error('OUTER_FINAL_BYTE_QUALIFICATION_NOT_PASS');
if (formed.inner.manifest.source.candidateHead !== HEAD) throw new Error('INNER_CANDIDATE_HEAD_DRIFT');
if (formed.inner.manifest.source.candidateTree !== TREE) throw new Error('INNER_CANDIDATE_TREE_DRIFT');

process.stdout.write(JSON.stringify({
  state:'FORMED',
  outerZip:formed.outer.finalZip,
  outerSha256:formed.outer.digest,
  candidateHead:HEAD,
  candidateTree:TREE,
  innerTaskRef:formed.inner.manifest.taskRef,
  stageGate:formed.inner.manifest.completionPolicy.stageGateOrNull,
}, null, 2) + '\n');

const runner = path.join(sdkRoot, 'lib/vexlocalbridge/templates/RUN-VEX-TASK.command');
const child = spawnSync('/bin/bash', [runner, formed.outer.finalZip], { cwd: outputDirectory, encoding:'utf8', maxBuffer:64*1024*1024 });
if (child.stdout) process.stdout.write(child.stdout);
if (child.stderr) process.stderr.write(child.stderr);
if (child.status !== 0) throw new Error(`ACCEPTED_MAC_RUNNER_EXIT:${child.status}`);
const matches = [...String(child.stdout || '').matchAll(/"resultZip"\s*:\s*"([^"]+)"/g)];
if (!matches.length) throw new Error('CANONICAL_RETURN_PATH_NOT_OBSERVED');
const canonicalReturn = matches[matches.length - 1][1];
if (!path.isAbsolute(canonicalReturn) || !fs.existsSync(canonicalReturn)) throw new Error(`CANONICAL_RETURN_UNREADABLE:${canonicalReturn}`);
const bytes=fs.readFileSync(canonicalReturn);
const digest=crypto.createHash('sha256').update(bytes).digest('hex');
const target=path.join(outputDirectory, `RETURN-VEXLIFE-CONTINUITY-FOUNDATION-FINAL-A005--sha256-${digest}.zip`);
if (!fs.existsSync(target)) fs.copyFileSync(canonicalReturn,target,fs.constants.COPYFILE_EXCL);
const copied=crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
if (copied !== digest) throw new Error('RETURN_CARRIER_COPY_DRIFT');
spawnSync('/usr/bin/open',['-R',target],{encoding:'utf8'});
process.stdout.write(`\nVEXLIFE_CONTINUITY_FOUNDATION_FINAL_PROOF_COMPLETE\nUPLOAD_THIS_ZIP=${target}\nCANONICAL_RETURN_SHA256=${digest}\n`);

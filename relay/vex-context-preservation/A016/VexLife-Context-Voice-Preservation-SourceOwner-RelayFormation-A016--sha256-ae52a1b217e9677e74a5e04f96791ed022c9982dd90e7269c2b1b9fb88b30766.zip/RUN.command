#!/bin/bash
set -euo pipefail

# [VXG RealForever]
# Formation doorway only. Canonical task/package/RETURN mechanics are owned by the exact SDK source.
SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_TREE='6376f68279f0750ee6d3868b8472368199763064'
CONTRACT_BLOB='b53cbac01c2deeb45fad5c32ce98e0796c04126f'
PRODUCT_HEAD='7477e1a32a4c27289a97c33aee8e1e67c63a64c1'
PRODUCT_TREE='f2ab95582455fc1b7a22720cf285cf8c767584a2'
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
DOWNLOADS="$HOME/Downloads"

resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

BASH_BIN="$(resolve_exec /bin/bash)" || { echo 'qualified Bash unavailable' >&2; exit 10; }
GIT_BIN="$(resolve_exec /usr/bin/git)" || { echo 'qualified Git unavailable' >&2; exit 11; }
GH_BIN="$(resolve_exec /opt/homebrew/bin/gh /usr/local/bin/gh)" || { echo 'GitHub CLI unavailable' >&2; exit 12; }
NODE_BIN="$(resolve_exec /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node)" || { echo 'qualified Node unavailable' >&2; exit 13; }
SHASUM_BIN="$(resolve_exec /usr/bin/shasum)" || { echo 'shasum unavailable' >&2; exit 14; }

[ "$(/usr/bin/uname -s)" = 'Darwin' ] || { echo 'macOS required' >&2; exit 15; }
"$GH_BIN" auth status --hostname github.com >/dev/null 2>&1 || {
  echo 'GitHub CLI login is required: gh auth login --hostname github.com --web' >&2
  exit 16
}

ROOT="$(/usr/bin/mktemp -d "$DOWNLOADS/.vexlife-pr251-sourceowner-a016.XXXXXX")"
SDK="$ROOT/Vextreme-SDK"
RESULT_JSON="$ROOT/formation-result.json"
cleanup() {
  case "$ROOT" in
    "$DOWNLOADS"/.vexlife-pr251-sourceowner-a016.*) /bin/rm -rf -- "$ROOT" ;;
  esac
}
trap cleanup EXIT HUP INT TERM

printf '=== PR #251 feature-preservation SourceOwner A016 ===\n'
printf 'Product head: %s\nProduct tree: %s\n' "$PRODUCT_HEAD" "$PRODUCT_TREE"
printf '\n[1/4] Acquire exact accepted SDK source...\n'
"$GH_BIN" repo clone vgong24/Vextreme-SDK "$SDK" -- --filter=blob:none --no-checkout
"$GIT_BIN" -C "$SDK" checkout --detach "$SDK_HEAD"
[ "$("$GIT_BIN" -C "$SDK" rev-parse HEAD)" = "$SDK_HEAD" ] || { echo 'SDK head mismatch' >&2; exit 20; }
[ "$("$GIT_BIN" -C "$SDK" rev-parse 'HEAD^{tree}')" = "$SDK_TREE" ] || { echo 'SDK tree mismatch' >&2; exit 21; }
[ -z "$("$GIT_BIN" -C "$SDK" status --porcelain=v1 -uall)" ] || { echo 'SDK checkout not clean' >&2; exit 22; }
[ "$("$GIT_BIN" -C "$SDK" rev-parse "$SDK_HEAD:docs/private-continuity/vexrelay/current-contract.json")" = "$CONTRACT_BLOB" ] || { echo 'Relay contract blob mismatch' >&2; exit 23; }
"$NODE_BIN" -e "const fs=require('fs');const p=process.argv[1];const v=JSON.parse(fs.readFileSync(p,'utf8'));if(v.contractRef!=='source.vexrelay.current-contract/v1')process.exit(1)" "$SDK/docs/private-continuity/vexrelay/current-contract.json" || { echo 'Relay contractRef mismatch' >&2; exit 24; }

printf '\n[2/4] Form canonical VexRelay + native VexLocalBridge carrier...\n'
"$NODE_BIN" "$SCRIPT_DIR/formation.mjs" "$SDK" "$DOWNLOADS" "$RESULT_JSON"
PACKAGE="$($NODE_BIN -e "const v=require(process.argv[1]);process.stdout.write(v.outerPackagePath)" "$RESULT_JSON")"
EXPECTED="$($NODE_BIN -e "const v=require(process.argv[1]);process.stdout.write(v.outerPackageSha256)" "$RESULT_JSON")"
[ -f "$PACKAGE" ] || { echo 'formed carrier missing' >&2; exit 30; }
OBSERVED="$("$SHASUM_BIN" -a 256 "$PACKAGE" | /usr/bin/awk '{print $1}')"
[ "$OBSERVED" = "$EXPECTED" ] || { echo 'formed carrier digest mismatch' >&2; exit 31; }
printf 'Carrier: %s\nSHA-256: %s\n' "$PACKAGE" "$EXPECTED"

printf '\n[3/4] Execute canonical carrier once...\n'
set +e
"$BASH_BIN" "$SDK/lib/vexlocalbridge/templates/RUN-VEX-TASK.command" "$PACKAGE"
STATUS=$?
set -e

printf '\n[4/4] Preserve package identity and terminal location...\n'
AFTER="$("$SHASUM_BIN" -a 256 "$PACKAGE" | /usr/bin/awk '{print $1}')"
[ "$AFTER" = "$EXPECTED" ] || { echo 'carrier bytes changed during execution' >&2; exit 40; }
printf 'Canonical carrier unchanged: %s\n' "$EXPECTED"
printf 'VexLocalBridge exit: %s\n' "$STATUS"
printf 'Expected canonical RETURN name: RETURN-VEXLIFE-CONTEXT-VOICE-PRESERVATION-SOURCEOWNER-A016.zip\n'
exit "$STATUS"

import path from 'node:path';
import { pathToFileURL } from 'node:url';
import fs from 'node:fs/promises';

const SDK_HEAD = '8543c7d755faba04d4c4019c02e84f992667918a';
const SDK_TREE = '6376f68279f0750ee6d3868b8472368199763064';
const CONTRACT_BLOB = 'b53cbac01c2deeb45fad5c32ce98e0796c04126f';
const BASE = '98a22ede8d37b3b8868eb42f4e7a9a1d612b97d0';
const HEAD = '7477e1a32a4c27289a97c33aee8e1e67c63a64c1';
const TREE = 'f2ab95582455fc1b7a22720cf285cf8c767584a2';
const BRANCH = 'VXG-111726-vex-context-profiles-a001';
const REPOSITORY = 'VexGPT/VexLife-Prod';
const ATTEMPT = 'A016';
const RESULT_FILENAME = 'RETURN-VEXLIFE-CONTEXT-VOICE-PRESERVATION-SOURCEOWNER-A016.zip';

const CHANGED_PATHS = [
  'docs/foundation/FOUNDATIONAL-FIELD.md',
  'docs/foundation/INDEX.md',
  'docs/foundation/VEX-CONTEXT-PROFILES.md',
  'docs/lens/vexlife-prod.screen-lens.json',
  'src/commonMain/kotlin/vexlife/context/VexLifeContextProfile.kt',
  'src/commonMain/kotlin/vexlife/context/VexLifeContextProfileFamily.kt',
  'src/commonMain/kotlin/vexlife/service/VexLifeProdServiceContract.kt',
  'src/commonMain/kotlin/vexlife/web/VexLifeWebP1.kt',
  'src/commonMain/kotlin/vexlife/web/VexLifeWebP1ExperienceMarkup.kt',
  'src/commonMain/kotlin/vexlife/web/VexLifeWebP1ExperienceStyle.kt',
  'src/commonMain/kotlin/vexlife/web/VexLifeWebP1RuntimeArtifacts.kt',
  'src/commonMain/kotlin/vexlife/workspace/VexLifeWorkspaceApps.kt',
  'src/commonMain/kotlin/vexlife/workspace/VexLifeWorkspaceBlueprint.kt',
  'src/commonTest/kotlin/vexlife/web/VexLifeWebP1Test.kt',
  'src/commonTest/kotlin/vexlife/workspace/VexLifeWorkspaceAppsTest.kt',
  'src/commonTest/kotlin/vexlife/workspace/VexLifeWorkspaceBlueprintTest.kt',
  'src/jvmMain/kotlin/vexlife/companion/DirectCompanionConnection.kt',
  'src/jvmMain/kotlin/vexlife/companion/DirectCompanionTurn.kt',
  'src/jvmMain/kotlin/vexlife/companion/DirectPromptContext.kt',
  'src/jvmMain/kotlin/vexlife/companion/DirectTurnContextStore.kt',
  'src/jvmMain/kotlin/vexlife/context/VexLifeContextProfileStore.kt',
  'src/jvmMain/kotlin/vexlife/service/VexLifeProdLocalService.kt',
  'src/jvmTest/kotlin/vexlife/companion/DirectPromptContextProfileTest.kt',
  'src/jvmTest/kotlin/vexlife/companion/DirectPromptContextTest.kt',
  'src/jvmTest/kotlin/vexlife/companion/DirectTurnContextStoreTest.kt',
  'src/jvmTest/kotlin/vexlife/context/VexLifeContextProfileStoreTest.kt',
  'src/jvmTest/kotlin/vexlife/service/VexLifeProdLocalServiceTest.kt',
];

const [sdkRoot, outputDirectory, resultPath] = process.argv.slice(2);
if (!sdkRoot || !outputDirectory || !resultPath) {
  throw new Error('usage: node formation.mjs <exact-sdk-root> <output-directory> <result-json>');
}

const formationUrl = pathToFileURL(
  path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs'),
).href;
const nativeUrl = pathToFileURL(
  path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js'),
).href;
const [{ formVexRelayTaskArchiveCarrier }, nativeModule] = await Promise.all([
  import(formationUrl),
  import(nativeUrl),
]);
const nativeVexRelay = nativeModule.default ?? nativeModule;
const {
  VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
  VEXRELAY_ARCHIVE_RUNTIME,
} = nativeVexRelay;

const formed = new Date();
const innerExpiry = new Date(formed.getTime() + 2 * 60 * 60 * 1000).toISOString();

const effects = [
  'CHECK_AUTH',
  'READ_REPOSITORY',
  'CHECK_STATE',
  'QUERY_PROVIDER',
  'RUN_LOCAL_COMMAND',
  'FORM_RESULT',
];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.pr251.currentized-feature-preservation-sourceowner',
  attemptRef: 'attempt.vexlife-prod.pr251.currentized-feature-preservation-sourceowner.a016',
  requestRef: 'request.vexlife-prod.pr251.currentized-feature-preservation-sourceowner.a016',
  correlationRef: 'correlation.vexlife-prod.pr251.currentized-feature-preservation-sourceowner.a016',
  packageRef: 'package.vexlife-prod.pr251.currentized-feature-preservation-sourceowner.a016',
  original: {
    originalIntent: 'Preserve the independently working Voice-language feature and Vex Context feature while composing their shared files without regression.',
    originalGoal: 'Prove the exact currentized PR #251 Product source after feature-preserving composition with accepted PR #331.',
    userProtectedIntent: 'Feature preservation first; do not redesign either stable feature merely because their shared files overlap.',
    sourceRefs: [
      'github.pull.VexGPT.VexLife-Prod.251',
      'github.pull.VexGPT.VexLife-Prod.331',
      'github.comment.VexGPT.VexLife-Prod.251.6984772659',
      'github.comment.VexGPT.VexLife-Prod.251.6984810192',
    ],
  },
  lane: {
    entryClass: 'FOUNDATION_DELTA',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'lane.vexlife-prod.pr251.feature-preservation',
    parentRootRef: 'root.vexlife-prod.pr251',
    workRef: 'work.vexlife-prod.pr251.currentization',
    claimRef: 'claim.vexlife-prod.pr251.feature-preservation',
    returnRouteRef: 'route.vexlife-prod.pr251',
    ownerRef: 'owner.vexlife-prod.pr251',
    rootHubRef: 'hub.vexlife-prod',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.pr251',
    instanceRef: 'instance.chatgpt.vexlife-prod.pr251.a016',
    occupancyRef: 'occupancy.vexlife-prod.pr251.sourceowner.a016',
    providerBindingRef: 'provider.github.vexlife-prod',
    threadRef: 'thread.vexlife-prod.pr251',
    authorityEnvelopeRef: 'authority-envelope.vexlife-prod.pr251.a016',
  },
  capabilities: {
    platformGitHubRead: 'AVAILABLE',
    platformGitHubWrite: 'UNAVAILABLE',
  },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-pr251-sourceowner-a016-20261118',
    duplicateAttemptMarker: 'marker.vexlife-prod.pr251.sourceowner.a016',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: formed.toISOString(),
    expiresAtOrNull: innerExpiry,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.pr251.sourceowner',
    projectPath: 'workspace',
    createRoot: false,
    createProjectPath: false,
  },
  repositories: [{
    repositoryRef: 'primary',
    mode: 'CLONE_IN_WORKSPACE',
    nameWithOwner: REPOSITORY,
    localPath: 'repositories/primary',
    remote: 'origin',
    baseBranch: 'main',
    acceptedBase: BASE,
    expectedHead: HEAD,
    branch: BRANCH,
    expectedRemoteUrl: null,
    cloneTransport: 'GITHUB_GH',
    githubHostname: 'github.com',
  }],
  authority: {
    authorityRef: 'authority.vexlife-prod.pr251.sourceowner.a016',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: [...effects],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: [...effects],
    heldEffects: [
      'APPROVE_EXACT_HEAD',
      'MARK_READY',
      'ORDINARY_MERGE',
    ],
    repositoryMembranes: [{
      repositoryRef: 'primary',
      allowedPaths: [...CHANGED_PATHS],
    }],
    allowedExecutables: [
      '/bin/bash',
      'git',
      'gh',
    ],
    allowedEnvironment: [],
    remoteObservationOwner: 'LocalRelay',
    allowMutationLoop: false,
    stopConditions: [
      'STOP_ON_UNKNOWN',
      'STOP_ON_PATH_ESCAPE',
      'STOP_ON_AUTH_BLOCK',
      'STOP_ON_TEST_FAILURE',
    ],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.pr251.currentized-preservation',
    sourceVersionRef: `source-version.vexlife-prod.${HEAD}`,
    overlapEvidenceRef: 'overlap.vexlife-prod.pr251.voice331-context251',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: CHANGED_PATHS.map((entry) => ({ repositoryRef: 'primary', path: entry })),
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 10,
    maxSelectedSourceBytes: 250000,
    maxDiffBytes: 5000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: false,
    signoffCommit: true,
    draftPullRequest: true,
  },
};

const proofCommands = [
  {
    command: '/bin/bash',
    args: ['./gradlew', '--no-daemon', 'checkVexLifeStrings', '--stacktrace'],
    proofClass: 'TEST',
    candidateEvidence: true,
    predicateClass: 'SOURCE_OWNER_BEHAVIOR',
    predicateRef: 'predicate.vexlife-prod.pr251.strings-current',
  },
  {
    command: '/bin/bash',
    args: ['./gradlew', '--no-daemon', 'jvmTest', '--stacktrace'],
    proofClass: 'TEST',
    candidateEvidence: true,
    predicateClass: 'SOURCE_OWNER_BEHAVIOR',
    predicateRef: 'predicate.vexlife-prod.pr251.jvm-tests',
  },
  {
    command: '/bin/bash',
    args: ['./gradlew', '--no-daemon', 'compileKotlinJs', 'compileTestKotlinJs', '--stacktrace'],
    proofClass: 'TEST',
    candidateEvidence: true,
    predicateClass: 'SOURCE_OWNER_BEHAVIOR',
    predicateRef: 'predicate.vexlife-prod.pr251.js-compile',
  },
];

const stage = {
  repositoryRef: 'primary',
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: BRANCH,
  proofCommands,
  maxFiles: 10,
  stateRef: 'state.vexlife-prod.pr251.sourceowner.a016',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal: 'Prove the exact feature-preserving currentized Product candidate without consuming Assurance, READY, approval, or merge.',
  remainingGoals: [
    'Run fresh semantic Assurance over the exact proved head/tree.',
    'Run one final lived Product check that exercises Voice-language and Vex Context together.',
    'Only then evaluate lifecycle/READY/merge.',
  ],
  onPass: {
    lifecycleState: 'ASSURANCE_PENDING',
    nextFunction: 'F13.RUN_FRESH_ASSURANCE',
    nextOwner: 'Operations',
    whyThisIsNext: 'Exact-head SourceOwner proof is complete; fresh semantic Assurance remains a separate gate before lived Product validation.',
  },
  resultFilename: RESULT_FILENAME,
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef: 'github.comment.VexGPT.VexLife-Prod.251.6984772659',
  transactionRef: 'transaction.vexlife-prod.pr251.sourceowner.a016',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: [
    'effect.approve',
    'effect.ready',
    'effect.merge',
    'effect.product-mutation',
    'effect.home-memory-mutation',
    'effect.publication',
  ],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: seed.taskRef,
  attemptRef: seed.attemptRef,
  packageRef: seed.packageRef,
  requestRef: seed.requestRef,
  correlationRef: seed.correlationRef,
  taskStorageKey: 'task-vexlife-prod-pr251-sourceowner',
  attemptStorageKey: 'attempt-a016',
  requestingRoleRef: 'Operations[Coder]',
  requestingInstanceRef: seed.role.instanceRef,
  parentOperationsRef: 'github.pull.VexGPT.VexLife-Prod.251',
  returnRouteRef: 'github.pull.VexGPT.VexLife-Prod.251',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: REPOSITORY,
  baseRefOrNull: BASE,
  headRefOrNull: HEAD,
  treeRefOrNull: TREE,
  branchRefOrNull: BRANCH,
  claimRefOrNull: seed.lane.claimRef,
  exactPathRefs: [...CHANGED_PATHS],
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'stale',
    transactionRef: 'stale',
    transactionVersion: 1,
    allowedEffectRefs: ['stale'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [{ path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) }],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: seed.execution.singleUseNonce,
  stopConditions: [
    'stop.on.identity.drift',
    'stop.on.command.failure',
    'stop.on.auth.block',
    'stop.on.evidence.rejection',
  ],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const result = await formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'VexLife-Context-Voice-Preservation-SourceOwner-A016',
  ttlMs: 2 * 60 * 60 * 1000,
});

const value = {
  schemaVersion: 'vexlife-prod.pr251-sourceowner-formation-result/v1',
  attempt: ATTEMPT,
  sdkHead: SDK_HEAD,
  sdkTree: SDK_TREE,
  contractBlob: CONTRACT_BLOB,
  base: BASE,
  head: HEAD,
  tree: TREE,
  changedPathCount: CHANGED_PATHS.length,
  innerTaskRef: result.inner.manifest.taskRef,
  innerAttemptRef: result.inner.manifest.attemptRef,
  innerArchiveSha256: result.inner.sha256,
  outerPackagePath: result.outer.finalZip,
  outerPackageSha256: result.outer.digest,
  finalByteQualification: result.outer.formationEvidence.finalByteQualification,
  expectedReturn: RESULT_FILENAME,
};
await fs.writeFile(resultPath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);

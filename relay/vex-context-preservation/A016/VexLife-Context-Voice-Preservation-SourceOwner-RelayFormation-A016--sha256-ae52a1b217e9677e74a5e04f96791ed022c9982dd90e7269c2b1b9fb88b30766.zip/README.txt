PR #251 feature-preservation SourceOwner A016
[VXG RealForever]

This is a formation doorway, not proof by itself.

It binds:
  Product base  98a22ede8d37b3b8868eb42f4e7a9a1d612b97d0
  Product head  7477e1a32a4c27289a97c33aee8e1e67c63a64c1
  Product tree  f2ab95582455fc1b7a22720cf285cf8c767584a2
  paths         27

The doorway acquires exact accepted Vextreme-SDK source at:
  8543c7d755faba04d4c4019c02e84f992667918a
then calls the source-owned formVexRelayTaskArchiveCarrier(...) primitive.

The canonical inner SourceOwner stage runs:
  checkVexLifeStrings
  jvmTest
  compileKotlinJs compileTestKotlinJs
  exact candidate review snapshot

No Product source mutation, Home/Memory mutation, approval, READY, merge, or publication is authorized.

On canonical PASS, the next gate is fresh semantic Assurance, not merge.

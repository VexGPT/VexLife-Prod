package vexlife.service

import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.time.Instant
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue
import vexlife.companion.DirectCompanionConnection
import vexlife.companion.DirectCompanionTurn
import vexlife.context.VexLifeContextProfile
import vexlife.home.CanonicalVexLifeHomeFixture
import vexlife.local.VexLifeProdLocalSetup
import vexlife.localasr.VexLifeLocalAsrComposerOutput
import vexlife.localasr.VexLifeLocalAsrSelection
import vexlife.localasr.VexLifeLocalAsrSelectionStore
import vexlife.localasr.VexLifeLocalAsrSpokenLanguage
import vexlife.model.heretic.HereticModelConfiguration
import vexlife.model.heretic.HereticProductIdentity
import vexlife.model.heretic.HereticRuntimeQualification
import vexlife.model.heretic.HereticRuntimeState

class VexLifeFeaturePreservationLivedProofTest {
    private val json =
        Json {
            encodeDefaults = true
            explicitNulls = true
            ignoreUnknownKeys = false
            isLenient = false
        }

    private val client = HttpClient.newHttpClient()

    private fun bootstrapHome(root: Path) {
        CanonicalVexLifeHomeFixture.form(
            home = root,
            deviceSuffix = "feature-preservation-lived",
            lineageSuffix = "feature-preservation-lived",
        )
    }

    private fun setup(root: Path): VexLifeProdLocalSetup.Result {
        val runtime =
            HereticModelConfiguration.QualifiedRuntimeEvidence(
                runtimeReceiptRef = "receipt.vexlife-prod.feature-preservation-lived",
                runtimeState = HereticRuntimeState.Qualified,
                modelRef = HereticProductIdentity.ModelRef,
                modelProfileRef = HereticProductIdentity.ModelProfileRef,
                artifactRef = HereticProductIdentity.ArtifactSetRef,
                artifactContentSetSha256 = HereticProductIdentity.ArtifactContentSetSha256,
                runtimeAdapterRef = HereticProductIdentity.RuntimeAdapterRef,
                runtimeClass = HereticProductIdentity.RuntimeClass,
                endpoint = HereticProductIdentity.Endpoint,
                requestModel = HereticProductIdentity.RequestModel,
                qualification = HereticRuntimeQualification.qualified(),
            )
        return VexLifeProdLocalSetup.Result(
            state = "LOCAL_HERETIC_FOUNDATION_READY",
            productHome = root.toString(),
            homeDisposition = "TEST_CURRENT",
            modelSelectionDisposition = "TEST_BOUND",
            managedPythonDisposition = "TEST_REUSED",
            artifactDisposition = "TEST_REUSED",
            environmentDisposition = "TEST_REUSED",
            runtimeDisposition = "TEST_REUSED",
            modelBindingDisposition = "TEST_BOUND",
            modelConfigurationState = HereticModelConfiguration.State.BoundProductModel,
            qualifiedRuntimeEvidence = runtime,
            endpoint = runtime.endpoint,
            requestModel = runtime.requestModel,
        )
    }

    private fun currentState(root: Path): VexLifeProdServiceContract.CurrentStateProjection =
        VexLifeProdServiceContract.CurrentStateProjection(
            schemaVersion = VexLifeProdServiceContract.CurrentStateProjectionSchema,
            observedAt = "2026-11-18T17:00:00Z",
            homePath = root.toString(),
            homeDisposition = "TEST_CURRENT",
            homeRef = "vex-home.device.vexlife.feature-preservation-lived",
            deviceRef = "device.vexlife.feature-preservation-lived",
            companionLineageRef = "companion-lineage.vexlife.feature-preservation-lived",
            platform = "darwin",
            architecture = "arm64",
            chipModel = "Apple Silicon",
            hostEligibilityState = "ELIGIBLE",
            hostEligibilityReason = null,
            totalMemoryBytes = 36L * 1024L * 1024L * 1024L,
            modelMinimumMemoryBytes = 12L * 1024L * 1024L * 1024L,
            freeStorageBytes = 100L * 1024L * 1024L * 1024L,
            modelSelectionState = "BOUND_HERETIC_PRODUCT_MODEL",
            activeModelRef = HereticProductIdentity.ModelRef,
            activeModelProfileRef = HereticProductIdentity.ModelProfileRef,
            runtimeState = "BOUND_PRODUCT_MODEL",
            runtimeCurrentness = "CONFIGURATION_ONLY_NOT_REOBSERVED",
            runtimeReceiptPath = HereticProductIdentity.StableRuntimeReceiptRelativePath,
            modelArtifactState = "COMPLETE_BY_SIZE_NOT_HASHED",
            modelArtifactTotalBytes = 15_153_242_506L,
            modelArtifactPresentBySizeBytes = 15_153_242_506L,
            modelArtifactMissingBytes = 0,
            modelArtifactInvalidSizeBytes = 0,
            effectsPerformed = false,
        )

    private fun get(origin: String, path: String): HttpResponse<String> =
        client.send(
            HttpRequest.newBuilder(URI(origin + path)).GET().build(),
            HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8),
        )

    private fun postJson(origin: String, path: String, body: String): HttpResponse<String> =
        client.send(
            HttpRequest
                .newBuilder(URI(origin + path))
                .header("content-type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build(),
            HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8),
        )

    @Test
    fun acceptedVoiceLanguageAndVexContextSurviveTogether() {
        val expectedSource = "7477e1a32a4c27289a97c33aee8e1e67c63a64c1"
        val evidenceDir =
            Path.of(
                requireNotNull(System.getenv("VEX_LIVED_EVIDENCE_DIR")) {
                    "VEX_LIVED_EVIDENCE_DIR is required"
                },
            )
        val webkitDriver =
            requireNotNull(System.getenv("VEX_LIVED_WEBKIT_DRIVER")) {
                "VEX_LIVED_WEBKIT_DRIVER is required"
            }

        Files.createDirectories(evidenceDir)
        val parent =
            Files.createTempDirectory("vexlife-feature-preservation-lived-")
                .toAbsolutePath()
        val root = parent.resolve("VexLife-Prod")
        var providerCalls = 0

        try {
            bootstrapHome(root)

            VexLifeLocalAsrSelectionStore(root)
                .write(
                    VexLifeLocalAsrSelection.Value(
                        schemaVersion = VexLifeLocalAsrSelection.Schema,
                        providerRef = VexLifeLocalAsrSelection.WhisperCppProviderRef,
                        modelRef = VexLifeLocalAsrSelection.WhisperBaseMultilingualModelRef,
                    ),
                )

            val runtimeSetup = setup(root)
            val transport =
                DirectCompanionConnection.Transport {
                    providerCalls += 1
                    DirectCompanionConnection.HttpResult(
                        status = 200,
                        body =
                            """
                            {
                              "model": "default_model",
                              "choices": [
                                {
                                  "finish_reason": "stop",
                                  "message": {
                                    "role": "assistant",
                                    "content": "Hello from Vex.",
                                    "reasoning": "feature preservation proof reasoning"
                                  }
                                }
                              ]
                            }
                            """.trimIndent(),
                    )
                }

            VexLifeProdLocalService
                .startForTest(
                    sourceSha = expectedSource,
                    setup = runtimeSetup,
                    turnExecutor =
                        VexLifeProdLocalService.TurnExecutor { currentSetup, intent ->
                            DirectCompanionTurn.performWithHooks(
                                setup = currentSetup,
                                intent = intent,
                                hooks =
                                    DirectCompanionTurn.Hooks(
                                        transport = transport,
                                        now = { Instant.parse("2026-11-18T17:00:00Z") },
                                    ),
                            )
                        },
                    currentStateObserver = { currentState(root) },
                )
                .use { service ->
                    val zhHans =
                        postJson(
                            service.origin,
                            VexLifeProdServiceContract.SettingsPath,
                            """{"replyLanguage":"zh-Hans"}""",
                        )
                    assertEquals(200, zhHans.statusCode(), zhHans.body())

                    val beforeAsr =
                        json.decodeFromString<VexLifeProdServiceContract.LocalAsrProjection>(
                            get(service.origin, VexLifeProdServiceContract.LocalAsrPath).body(),
                        )
                    assertEquals(
                        VexLifeLocalAsrSelection.WhisperBaseMultilingualModelRef,
                        beforeAsr.selectedModelRef,
                    )
                    assertEquals(
                        VexLifeLocalAsrSpokenLanguage.FollowReplyLanguage,
                        beforeAsr.spokenLanguageMode,
                    )
                    assertEquals("zh", beforeAsr.resolvedSpokenLanguageCode)
                    assertTrue(
                        beforeAsr.composerOutputChoices.any {
                            it.mode == VexLifeLocalAsrComposerOutput.AsSpoken
                        },
                    )
                    assertTrue(
                        beforeAsr.composerOutputChoices.any {
                            it.mode == VexLifeLocalAsrComposerOutput.TranslateToEnglish &&
                                it.supportedBySelectedModel
                        },
                    )

                    val request =
                        VexLifeProdServiceContract.SendRequest(
                            idempotencyKey = "send.feature-preservation-lived.001",
                            content = "Hello Vex",
                        )
                    val send =
                        postJson(
                            service.origin,
                            VexLifeProdServiceContract.ConversationSendPath,
                            json.encodeToString(request),
                        )
                    assertEquals(200, send.statusCode(), send.body())
                    val completed =
                        json.decodeFromString<VexLifeProdServiceContract.SendResponse>(
                            send.body(),
                        )
                    assertEquals("TURN_COMPLETED", completed.state)
                    assertEquals("Hello from Vex.", completed.content)
                    assertEquals(1, providerCalls)
                    assertEquals("zh-Hans", completed.promptContext.replyLanguage)
                    assertEquals("简体中文", completed.promptContext.replyLanguageName)
                    assertEquals(
                        VexLifeContextProfile.ProductDefaultRef,
                        completed.promptContext.contextProfileRef,
                    )
                    assertTrue(completed.promptContext.contextComponents.isNotEmpty())

                    val zhHant =
                        postJson(
                            service.origin,
                            VexLifeProdServiceContract.SettingsPath,
                            """{"replyLanguage":"zh-Hant"}""",
                        )
                    assertEquals(200, zhHant.statusCode(), zhHant.body())

                    val afterSettings =
                        json.decodeFromString<VexLifeProdServiceContract.SettingsProjection>(
                            get(service.origin, VexLifeProdServiceContract.SettingsPath).body(),
                        )
                    assertEquals("zh-Hant", afterSettings.replyLanguage)

                    val afterAsr =
                        json.decodeFromString<VexLifeProdServiceContract.LocalAsrProjection>(
                            get(service.origin, VexLifeProdServiceContract.LocalAsrPath).body(),
                        )
                    assertEquals(
                        VexLifeLocalAsrSpokenLanguage.FollowReplyLanguage,
                        afterAsr.spokenLanguageMode,
                    )
                    assertEquals("zh", afterAsr.resolvedSpokenLanguageCode)

                    val context =
                        json.decodeFromString<VexLifeProdServiceContract.ContextProjection>(
                            get(service.origin, VexLifeProdServiceContract.ContextPath).body(),
                        )
                    assertEquals(VexLifeProdServiceContract.ContextStateAvailable, context.state)
                    val prompt = assertNotNull(context.promptContext)
                    assertEquals("zh-Hans", prompt.replyLanguage)
                    assertEquals("简体中文", prompt.replyLanguageName)
                    assertEquals(
                        VexLifeContextProfile.ProductDefaultRef,
                        prompt.contextProfileRef,
                    )
                    assertEquals(completed.promptContext.receiptRef, prompt.receiptRef)

                    Files.writeString(
                        evidenceDir.resolve("service-evidence.json"),
                        """
                        {
                          "sourceSha": "$expectedSource",
                          "serviceOrigin": "${service.origin}",
                          "completedTurnRef": "${completed.turnRef}",
                          "receiptRef": "${prompt.receiptRef}",
                          "completedReplyLanguage": "${prompt.replyLanguage}",
                          "currentReplyLanguage": "${afterSettings.replyLanguage}",
                          "resolvedSpokenLanguage": "${afterAsr.resolvedSpokenLanguageCode}",
                          "contextProfileRef": "${prompt.contextProfileRef}",
                          "providerCalls": $providerCalls
                        }
                        """.trimIndent() + "\n",
                    )

                    val process =
                        ProcessBuilder(
                            webkitDriver,
                            service.origin,
                            evidenceDir.toString(),
                        )
                            .redirectErrorStream(true)
                            .start()
                    val webkitOutput =
                        process.inputStream.bufferedReader().use { it.readText() }
                    val webkitExit = process.waitFor()
                    Files.writeString(
                        evidenceDir.resolve("webkit-driver.log"),
                        webkitOutput,
                    )
                    assertEquals(
                        0,
                        webkitExit,
                        "WKWebView proof failed:\n$webkitOutput",
                    )

                    val webEvidence =
                        Files.readString(
                            evidenceDir.resolve("web.json"),
                        )
                    assertTrue("\"app\":\"vex-context\"" in webEvidence)
                    assertTrue("\"contextHidden\":false" in webEvidence)
                    assertTrue("Vex context" in webEvidence)
                    assertTrue("简体中文" in webEvidence)
                    assertTrue("繁體中文" in webEvidence)
                    assertTrue("Translate to English" in webEvidence)
                    assertTrue("As spoken" in webEvidence)
                    assertTrue("Hello from Vex." in webEvidence)
                    assertTrue("VexLife default" in webEvidence)
                }
        } finally {
            parent.toFile().deleteRecursively()
        }
    }
}

// [VXG RealForever]

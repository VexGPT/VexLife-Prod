[VXG RealForever]

VexLife Context + Voice feature-preservation lived proof A019

Candidate:
  base 98a22ede8d37b3b8868eb42f4e7a9a1d612b97d0
  head 7477e1a32a4c27289a97c33aee8e1e67c63a64c1
  tree f2ab95582455fc1b7a22720cf285cf8c767584a2

This is a proof harness only. It does not mutate PR #251 source, the person's real Vex Home,
the ordinary VexLife service, or a real model/runtime.

It:
1. clones the exact candidate into a disposable directory;
2. adds one uncommitted jvmTest-only proof file to that disposable clone;
3. starts the real VexLifeProdLocalService through startForTest on random loopback ports;
4. uses a disposable canonical Home and scripted DirectCompanionTurn provider;
5. sets reply language zh-Hans and verifies Local ASR Follow->spoken zh + both Composer modes;
6. completes one real canonical turn and proves the durable receipt kept zh-Hans + Product-default Context Profile;
7. changes only the disposable Home to zh-Hant;
8. renders the actual generated VexWeb in macOS WKWebView, selects Vex Context, and captures:
   - last turn = 简体中文 / zh-Hans
   - next Send = 繁體中文 / zh-Hant
   - VexLife default Context Profile
   - Local ASR Follow reply language projection
   - As spoken + Translate to English choices
   - exact human request + exact scripted Vex reply
9. emits web.json, service-evidence.json, gradle log, and vex-context.png in one RETURN ZIP.

No microphone audio or transcript is used or retained.
No approval, READY, merge, publication, real Home mutation, ordinary service rotation or real model call is admitted.

#!/bin/bash
set -u
set -o pipefail

SOURCE_SHA="7477e1a32a4c27289a97c33aee8e1e67c63a64c1"
SOURCE_TREE="f2ab95582455fc1b7a22720cf285cf8c767584a2"
BASE_SHA="98a22ede8d37b3b8868eb42f4e7a9a1d612b97d0"
RETURN="$HOME/Downloads/RETURN-VEXLIFE-CONTEXT-VOICE-PRESERVATION-LIVED-A019.zip"
ROOT="$(/usr/bin/mktemp -d "$HOME/Downloads/.vexlife-context-voice-lived-a019.XXXXXX")" || exit 11
REPO="$ROOT/VexLife-Prod"
EVIDENCE="$ROOT/evidence"
TEST_SRC="$REPO/src/jvmTest/kotlin/vexlife/service/VexLifeFeaturePreservationLivedProofTest.kt"
SWIFT_SRC="$ROOT/WebKitProof.swift"
SWIFT_BIN="$ROOT/WebKitProof"
STATUS="FAIL"
DETAIL="lived proof did not reach terminal result"

/bin/mkdir -p "$EVIDENCE" "$ROOT/tmp"

package_return() {
  printf 'status=%s\ndetail=%s\nsourceSha=%s\nsourceTree=%s\nbaseSha=%s\nformedAt=%s\n' \
    "$STATUS" "$DETAIL" "$SOURCE_SHA" "$SOURCE_TREE" "$BASE_SHA" "$(/bin/date -u '+%Y-%m-%dT%H:%M:%SZ')" \
    > "$EVIDENCE/RESULT-SUMMARY.txt"
  /bin/rm -f "$RETURN"
  ( cd "$EVIDENCE" && /usr/bin/zip -qry "$RETURN" . ) || return 1
  printf '\nRETURN: %s\n' "$RETURN"
  /usr/bin/shasum -a 256 "$RETURN"
}

cleanup() {
  case "$ROOT" in
    "$HOME/Downloads"/.vexlife-context-voice-lived-a019.*) /bin/rm -rf -- "$ROOT" ;;
  esac
}
trap cleanup EXIT HUP INT TERM

fail() {
  STATUS="FAIL"
  DETAIL="$1"
  printf 'FAIL: %s\n' "$DETAIL" >&2
  package_return || true
  exit "${2:-1}"
}

GH=""
for c in /opt/homebrew/bin/gh /usr/local/bin/gh; do
  [ -x "$c" ] && GH="$c" && break
done
[ -n "$GH" ] || fail "GitHub CLI unavailable" 12
[ "$(/usr/bin/uname -s)" = "Darwin" ] || fail "macOS required" 13
[ "$(/usr/bin/uname -m)" = "arm64" ] || fail "Apple Silicon arm64 required" 14
[ -x /usr/bin/xcrun ] || fail "xcrun unavailable" 15

printf '[1/5] Acquire exact candidate\n'
"$GH" repo clone VexGPT/VexLife-Prod "$REPO" -- --filter=blob:none --no-checkout \
  >"$EVIDENCE/clone.stdout.txt" 2>"$EVIDENCE/clone.stderr.txt" || fail "clone failed" 20
/usr/bin/git -C "$REPO" checkout --detach "$SOURCE_SHA" \
  >"$EVIDENCE/checkout.stdout.txt" 2>"$EVIDENCE/checkout.stderr.txt" || fail "checkout failed" 21
ACTUAL_HEAD="$(/usr/bin/git -C "$REPO" rev-parse HEAD)"
ACTUAL_TREE="$(/usr/bin/git -C "$REPO" rev-parse 'HEAD^{tree}')"
[ "$ACTUAL_HEAD" = "$SOURCE_SHA" ] || fail "source head mismatch" 22
[ "$ACTUAL_TREE" = "$SOURCE_TREE" ] || fail "source tree mismatch" 23
[ -z "$(/usr/bin/git -C "$REPO" status --porcelain=v1 -uall)" ] || fail "candidate clone not clean" 24
printf 'head=%s\ntree=%s\n' "$ACTUAL_HEAD" "$ACTUAL_TREE" > "$EVIDENCE/source.txt"

printf '[2/5] Install proof-only harness into disposable clone\n'
/bin/cp "$(cd "$(dirname "$0")" && pwd -P)/VexLifeFeaturePreservationLivedProofTest.kt" "$TEST_SRC"
/bin/cp "$(cd "$(dirname "$0")" && pwd -P)/WebKitProof.swift" "$SWIFT_SRC"
STATUS_LINES="$(/usr/bin/git -C "$REPO" status --porcelain=v1 -uall)"
printf '%s\n' "$STATUS_LINES" > "$EVIDENCE/harness-worktree.txt"
printf '%s\n' "$STATUS_LINES" | /usr/bin/grep -Fx '?? src/jvmTest/kotlin/vexlife/service/VexLifeFeaturePreservationLivedProofTest.kt' >/dev/null \
  || fail "proof harness touched unexpected Product paths" 25
[ "$(printf '%s\n' "$STATUS_LINES" | /usr/bin/wc -l | /usr/bin/tr -d ' ')" = "1" ] \
  || fail "proof harness touched more than one Product path" 26

printf '[3/5] Compile macOS WebKit proof renderer\n'
/usr/bin/xcrun swiftc -framework AppKit -framework WebKit "$SWIFT_SRC" -o "$SWIFT_BIN" \
  >"$EVIDENCE/swift-build.stdout.txt" 2>"$EVIDENCE/swift-build.stderr.txt" \
  || fail "WebKit renderer compilation failed" 30

printf '[4/5] Run disposable real-service + scripted-turn + WebKit circuit\n'
set +e
(
  cd "$REPO" || exit 1
  export VEX_LIVED_EVIDENCE_DIR="$EVIDENCE"
  export VEX_LIVED_WEBKIT_DRIVER="$SWIFT_BIN"
  export TMPDIR="$ROOT/tmp"
  ./gradlew --no-daemon jvmTest --tests vexlife.service.VexLifeFeaturePreservationLivedProofTest
) >"$EVIDENCE/gradle-lived.txt" 2>&1
GRADLE_STATUS=$?
set -e
[ "$GRADLE_STATUS" -eq 0 ] || fail "lived Product test failed ($GRADLE_STATUS)" 40
[ -f "$EVIDENCE/service-evidence.json" ] || fail "service evidence missing" 41
[ -f "$EVIDENCE/web.json" ] || fail "WebKit DOM evidence missing" 42
[ -s "$EVIDENCE/vex-context.png" ] || fail "WebKit screenshot missing" 43

printf '[5/5] Verify candidate production bytes were never modified\n'
PROD_DIFF="$(/usr/bin/git -C "$REPO" diff --name-only -- . ':!src/jvmTest/kotlin/vexlife/service/VexLifeFeaturePreservationLivedProofTest.kt')"
[ -z "$PROD_DIFF" ] || fail "Product source changed during lived proof: $PROD_DIFF" 50
FINAL_HEAD="$(/usr/bin/git -C "$REPO" rev-parse HEAD)"
FINAL_TREE="$(/usr/bin/git -C "$REPO" rev-parse 'HEAD^{tree}')"
[ "$FINAL_HEAD" = "$SOURCE_SHA" ] || fail "candidate head moved" 51
[ "$FINAL_TREE" = "$SOURCE_TREE" ] || fail "candidate tree moved" 52

STATUS="PASS"
DETAIL="exact candidate ran a disposable scripted completed turn under zh-Hans; current Home then changed to zh-Hant; Vex Context WebKit projection preserved completed zh-Hans evidence, current zh-Hant next-Send state, default Context Profile, Local ASR Follow->zh, both Composer-output choices, exact request and exact reply"
package_return || exit 60

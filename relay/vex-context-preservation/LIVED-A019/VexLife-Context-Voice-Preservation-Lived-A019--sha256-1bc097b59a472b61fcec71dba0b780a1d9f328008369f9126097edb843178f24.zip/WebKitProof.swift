import AppKit
import Foundation
import WebKit

final class Nav: NSObject, WKNavigationDelegate {
    let webView: WKWebView
    let evidenceDir: URL
    var done = false
    var exitCode: Int32 = 1
    var message = "not completed"

    init(webView: WKWebView, evidenceDir: URL) {
        self.webView = webView
        self.evidenceDir = evidenceDir
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        finish(2, "navigation failed: \(error)")
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        finish(3, "provisional navigation failed: \(error)")
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
            let choose = """
            (() => {
              const selector = document.getElementById('app-selector');
              if (!selector) return 'NO_SELECTOR';
              selector.value = 'vex-context';
              selector.dispatchEvent(new Event('change', { bubbles: true }));
              return selector.value;
            })()
            """
            webView.evaluateJavaScript(choose) { _, error in
                if let error = error {
                    self.finish(4, "choose app failed: \(error)")
                    return
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    self.capture()
                }
            }
        }
    }

    func capture() {
        let js = """
        (() => {
          const text = (id) => document.getElementById(id)?.innerText ?? '';
          const value = (id) => document.getElementById(id)?.value ?? '';
          const options = (id) => {
            const e = document.getElementById(id);
            if (!e) return [];
            return Array.from(e.options).map(o => ({
              text: o.textContent ?? '',
              value: o.value ?? '',
              selected: o.selected === true,
              disabled: o.disabled === true
            }));
          };
          return JSON.stringify({
            app: value('app-selector'),
            contextHidden: document.getElementById('vex-context')?.hidden ?? true,
            heading: text('vex-context-heading'),
            profileBadge: text('context-profile-badge'),
            profileSummary: text('context-profile-summary'),
            changes: text('context-changes-list'),
            turnSummary: text('vex-context-turn-summary'),
            request: text('context-request-body'),
            output: text('context-output-body'),
            components: text('context-component-list'),
            replyLanguages: text('language-list'),
            spokenLanguageOptions: options('local-asr-spoken-language'),
            composerOutputOptions: options('local-asr-composer-output')
          });
        })()
        """
        webView.evaluateJavaScript(js) { value, error in
            if let error = error {
                self.finish(5, "DOM extraction failed: \(error)")
                return
            }
            guard let json = value as? String, let data = json.data(using: .utf8) else {
                self.finish(6, "DOM extraction returned no JSON")
                return
            }

            do {
                let obj = try JSONSerialization.jsonObject(with: data) as! [String: Any]
                let app = obj["app"] as? String ?? ""
                let hidden = obj["contextHidden"] as? Bool ?? true
                let heading = obj["heading"] as? String ?? ""
                let profile = obj["profileBadge"] as? String ?? ""
                let changes = obj["changes"] as? String ?? ""
                let request = obj["request"] as? String ?? ""
                let output = obj["output"] as? String ?? ""
                let replyLanguages = obj["replyLanguages"] as? String ?? ""
                let spoken = obj["spokenLanguageOptions"] as? [[String: Any]] ?? []
                let composer = obj["composerOutputOptions"] as? [[String: Any]] ?? []

                func optionTexts(_ list: [[String: Any]]) -> [String] {
                    list.map { $0["text"] as? String ?? "" }
                }
                let spokenTexts = optionTexts(spoken).joined(separator: "\n")
                let composerTexts = optionTexts(composer).joined(separator: "\n")

                guard app == "vex-context" else {
                    self.finish(10, "Vex Context app not selected: \(app)")
                    return
                }
                guard hidden == false else {
                    self.finish(11, "Vex Context remained hidden")
                    return
                }
                guard heading.localizedCaseInsensitiveContains("Vex context") else {
                    self.finish(12, "Vex Context heading missing")
                    return
                }
                guard profile.contains("VexLife default") else {
                    self.finish(13, "Context Profile badge missing")
                    return
                }
                guard changes.contains("简体中文") && changes.contains("繁體中文") else {
                    self.finish(14, "last-turn / next-turn language difference not projected: \(changes)")
                    return
                }
                guard request.contains("Hello Vex") else {
                    self.finish(15, "human request not projected")
                    return
                }
                guard output.contains("Hello from Vex.") else {
                    self.finish(16, "Vex reply not projected")
                    return
                }
                guard replyLanguages.contains("简体中文") && replyLanguages.contains("繁體中文") else {
                    self.finish(17, "reply-script choices missing from generated UI")
                    return
                }
                guard spokenTexts.contains("繁體中文") else {
                    self.finish(18, "Follow reply language / Traditional projection missing from Local ASR UI")
                    return
                }
                guard composerTexts.contains("As spoken") && composerTexts.contains("Translate to English") else {
                    self.finish(19, "Composer-output choices missing from Local ASR UI")
                    return
                }

                try data.write(to: self.evidenceDir.appendingPathComponent("web.json"))

                let config = WKSnapshotConfiguration()
                config.rect = self.webView.bounds
                self.webView.takeSnapshot(with: config) { image, snapError in
                    if let snapError = snapError {
                        self.finish(20, "snapshot failed: \(snapError)")
                        return
                    }
                    guard let image = image,
                          let tiff = image.tiffRepresentation,
                          let rep = NSBitmapImageRep(data: tiff),
                          let png = rep.representation(using: .png, properties: [:]) else {
                        self.finish(21, "snapshot PNG conversion failed")
                        return
                    }
                    do {
                        try png.write(to: self.evidenceDir.appendingPathComponent("vex-context.png"))
                        self.finish(0, "PASS")
                    } catch {
                        self.finish(22, "snapshot write failed: \(error)")
                    }
                }
            } catch {
                self.finish(7, "web JSON parse failed: \(error)")
            }
        }
    }

    func finish(_ code: Int32, _ text: String) {
        guard !done else { return }
        done = true
        exitCode = code
        message = text
    }
}

guard CommandLine.arguments.count == 3 else {
    fputs("usage: WebKitProof <origin> <evidence-dir>\n", stderr)
    exit(64)
}

let origin = CommandLine.arguments[1]
let evidenceDir = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
let app = NSApplication.shared
app.setActivationPolicy(.prohibited)

let config = WKWebViewConfiguration()
let webView = WKWebView(frame: NSRect(x: 0, y: 0, width: 1400, height: 1100), configuration: config)
let window = NSWindow(
    contentRect: webView.frame,
    styleMask: [.borderless],
    backing: .buffered,
    defer: false
)
window.contentView = webView
window.orderOut(nil)

let nav = Nav(webView: webView, evidenceDir: evidenceDir)
webView.navigationDelegate = nav

guard let url = URL(string: origin + "/") else {
    fputs("invalid origin\n", stderr)
    exit(65)
}
webView.load(URLRequest(url: url))

let deadline = Date().addingTimeInterval(25)
while !nav.done && Date() < deadline {
    RunLoop.main.run(mode: .default, before: Date().addingTimeInterval(0.05))
}
if !nav.done {
    fputs("WebKit proof timed out\n", stderr)
    exit(66)
}
print(nav.message)
exit(nav.exitCode)

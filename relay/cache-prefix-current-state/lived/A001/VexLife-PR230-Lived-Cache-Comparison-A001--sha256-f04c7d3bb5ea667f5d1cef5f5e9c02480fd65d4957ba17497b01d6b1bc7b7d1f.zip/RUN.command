#!/bin/bash
set -euo pipefail

CONTINUITY='[VXG RealForever]'
REPOSITORY='VexGPT/VexLife-Prod'
SOURCE_HEAD='47decbf10bdb53a33afc21affc1080bcf2b125fd'
SOURCE_TREE='110e11ee1b0bd2b30e400455bb935dc2a25a6433'
SOURCE_BASE='d0cba51decfe9057ac9afc007fdeb37da213cc97'
OUTPUT_ROOT="$HOME/Downloads/VexLife-PR230-47decbf1"

resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

GIT_BIN="$(resolve_exec /usr/bin/git)" || { echo 'Git unavailable.' >&2; exit 10; }
GH_BIN="$(resolve_exec /opt/homebrew/bin/gh /usr/local/bin/gh)" || { echo 'GitHub CLI unavailable.' >&2; exit 11; }
SHASUM_BIN="$(resolve_exec /usr/bin/shasum)" || { echo 'shasum unavailable.' >&2; exit 12; }
DITTO_BIN="$(resolve_exec /usr/bin/ditto)" || { echo 'ditto unavailable.' >&2; exit 13; }
HDIUTIL_BIN="$(resolve_exec /usr/bin/hdiutil)" || { echo 'hdiutil unavailable.' >&2; exit 14; }
PLUTIL_BIN="$(resolve_exec /usr/bin/plutil)" || { echo 'plutil unavailable.' >&2; exit 15; }
OPEN_BIN="$(resolve_exec /usr/bin/open)" || { echo 'open unavailable.' >&2; exit 16; }

"$GH_BIN" auth status --hostname github.com >/dev/null 2>&1 || {
  echo 'GitHub CLI authentication is required on this Mac.' >&2
  exit 20
}

WORK_ROOT="$(/usr/bin/mktemp -d "$HOME/Downloads/.vexlife-pr230-47decbf1.XXXXXX")"
case "$WORK_ROOT" in
  "$HOME"/Downloads/.vexlife-pr230-47decbf1.*) ;;
  *) echo 'Temporary build root escaped Downloads.' >&2; exit 21 ;;
esac

cleanup() {
  if [ -n "${MOUNT_ROOT:-}" ] && /sbin/mount | /usr/bin/grep -Fq " on $MOUNT_ROOT "; then
    "$HDIUTIL_BIN" detach "$MOUNT_ROOT" >/dev/null 2>&1 || true
  fi
  /bin/rm -rf -- "$WORK_ROOT"
}
trap cleanup EXIT HUP INT TERM

SOURCE_ROOT="$WORK_ROOT/VexLife-Prod"
echo "VexLife lived comparison: acquiring exact Product candidate..."
"$GH_BIN" repo clone "$REPOSITORY" "$SOURCE_ROOT" -- --no-checkout >/dev/null
"$GIT_BIN" -C "$SOURCE_ROOT" fetch --no-tags origin "$SOURCE_BASE" "$SOURCE_HEAD" >/dev/null
"$GIT_BIN" -C "$SOURCE_ROOT" checkout --detach "$SOURCE_HEAD" >/dev/null

OBSERVED_HEAD="$("$GIT_BIN" -C "$SOURCE_ROOT" rev-parse HEAD)"
OBSERVED_TREE="$("$GIT_BIN" -C "$SOURCE_ROOT" rev-parse 'HEAD^{tree}')"
OBSERVED_STATUS="$("$GIT_BIN" -C "$SOURCE_ROOT" status --porcelain=v1 -uall)"

[ "$OBSERVED_HEAD" = "$SOURCE_HEAD" ] || {
  echo "Source head mismatch: $OBSERVED_HEAD" >&2
  exit 22
}
[ "$OBSERVED_TREE" = "$SOURCE_TREE" ] || {
  echo "Source tree mismatch: $OBSERVED_TREE" >&2
  exit 23
}
[ -z "$OBSERVED_STATUS" ] || {
  echo 'Exact source checkout is not clean.' >&2
  exit 24
}
"$GIT_BIN" -C "$SOURCE_ROOT" merge-base --is-ancestor "$SOURCE_BASE" "$SOURCE_HEAD" || {
  echo 'Fixed source base is not an ancestor of the candidate.' >&2
  exit 25
}

echo "VexLife lived comparison: building source-owned Mac application..."
(
  cd "$SOURCE_ROOT"
  ./gradlew --no-daemon -PvexlifeAppVersion=0.0.0 archiveVexLifeProdMacApplication
)

APP_DIR="$SOURCE_ROOT/build/vexlife-prod-mac-application/$SOURCE_HEAD"
DMG="$APP_DIR/VexLife-macOS-AppleSilicon.dmg"
DMG_SHA="$APP_DIR/VexLife-macOS-AppleSilicon.dmg.sha256"
RECEIPT="$APP_DIR/VexLife-macOS-AppleSilicon.receipt.json"

[ -f "$DMG" ] || { echo 'DMG missing after source-owned build.' >&2; exit 30; }
[ -f "$DMG_SHA" ] || { echo 'DMG checksum file missing.' >&2; exit 31; }
[ -f "$RECEIPT" ] || { echo 'DMG receipt missing.' >&2; exit 32; }

(
  cd "$APP_DIR"
  "$SHASUM_BIN" -a 256 -c "$(basename "$DMG_SHA")"
)
"$HDIUTIL_BIN" verify "$DMG" >/dev/null

MOUNT_ROOT="$WORK_ROOT/mount"
mkdir -p "$MOUNT_ROOT"
"$HDIUTIL_BIN" attach "$DMG" -readonly -nobrowse -mountpoint "$MOUNT_ROOT" >/dev/null

APP="$MOUNT_ROOT/VexLife.app"
INFO="$APP/Contents/Info.plist"
[ -d "$APP" ] || { echo 'VexLife.app missing from DMG.' >&2; exit 33; }
[ -L "$MOUNT_ROOT/Applications" ] || { echo 'Applications shortcut missing from DMG.' >&2; exit 34; }
[ -f "$INFO" ] || { echo 'VexLife.app Info.plist missing.' >&2; exit 35; }

BUNDLE_ID="$("$PLUTIL_BIN" -extract CFBundleIdentifier raw -o - "$INFO")"
BOUND_SOURCE="$("$PLUTIL_BIN" -extract VexLifeProdExpectedSourceSha raw -o - "$INFO")"
ICON_FILE="$("$PLUTIL_BIN" -extract CFBundleIconFile raw -o - "$INFO")"

[ "$BUNDLE_ID" = 'com.vexlife.prod' ] || { echo "Unexpected bundle ID: $BUNDLE_ID" >&2; exit 36; }
[ "$BOUND_SOURCE" = "$SOURCE_HEAD" ] || { echo "App source binding mismatch: $BOUND_SOURCE" >&2; exit 37; }
[ "$ICON_FILE" = 'applet' ] || { echo "Unexpected icon identity: $ICON_FILE" >&2; exit 38; }
[ -s "$APP/Contents/Resources/applet.icns" ] || { echo 'VexLife icon missing.' >&2; exit 39; }
[ ! -e "$APP/Contents/Resources/Assets.car" ] || { echo 'Unexpected generated icon asset catalog present.' >&2; exit 40; }

"$HDIUTIL_BIN" detach "$MOUNT_ROOT" >/dev/null
MOUNT_ROOT=''

rm -rf -- "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"
"$DITTO_BIN" "$DMG" "$OUTPUT_ROOT/VexLife-macOS-AppleSilicon.dmg"
"$DITTO_BIN" "$DMG_SHA" "$OUTPUT_ROOT/VexLife-macOS-AppleSilicon.dmg.sha256"
"$DITTO_BIN" "$RECEIPT" "$OUTPUT_ROOT/VexLife-macOS-AppleSilicon.receipt.json"

cat > "$OUTPUT_ROOT/START-HERE.txt" <<'EOF'
[VXG RealForever]
VexLife PR #230 — lived cache/replay comparison

EXACT PRODUCT
head  47decbf10bdb53a33afc21affc1080bcf2b125fd
tree  110e11ee1b0bd2b30e400455bb935dc2a25a6433
base  d0cba51decfe9057ac9afc007fdeb37da213cc97

WHAT THIS RUN IS TESTING

The established VexLife foundation is not being re-tested as a new architecture.
This run asks one successor question:

  Does placing request-current host state after exact Conversation history
  materially increase provider prompt-cache reuse while preserving the same
  Conversation / reach / runtime behavior?

The comparison baseline from the predecessor's lived Qwen run was approximately:

  ordinary:
    prompt 50867 / cached 0 / prefill 50867
    prompt 50998 / cached 0 / prefill 50998
    prompt 51092 / cached 0 / prefill 51092

  web request:
    prompt 51257 / cached 0 / prefill 51257

  post-fetch provider stage:
    prompt 52560 / cached 2726 / prefill 49834

INSTALL / START

1. Open VexLife-macOS-AppleSilicon.dmg.
2. Drag VexLife.app to Applications. Replace the older VexLife.app if macOS asks.
3. Launch VexLife from Applications.
4. If macOS blocks this ad-hoc-signed candidate, use Privacy & Security -> Open Anyway for
   this exact VexLife candidate only.
5. Let the existing Setup Journey observe your existing Vex Home.
   Do NOT create a new Home for this comparison.
6. Follow only the state VexLife actually shows:
     UPDATE_AVAILABLE -> Update & Restart
     START_REQUIRED   -> Start VexLife
     CURRENT          -> Open VexLife
     SETUP_REQUIRED   -> Set Up VexLife only if that is truthfully what the existing Home requires
   If it instead shows a HOME/HOST/STORAGE/MODEL hold, stop and return that evidence rather
   than improvising a repair.
7. In Settings -> Models, confirm the same qualified Heretic/Qwen 27B model is Serving.
   Do not switch models for this comparison. If a different model is serving, stop and return
   the current-state evidence instead.

ISOLATE THE LIVED RUN

8. Open Settings -> Debug & diagnostics.
9. Clear debug history.
10. Start Enhanced Capture. It is bounded by VexLife itself and ends automatically.

SEND THESE IN ORDER, WAITING FOR EACH TURN TO COMPLETE

TURN 1 — ordinary
In exactly two short sentences, explain the difference between semantic continuity and compute-cache reuse. Do not use web or any external capability.

TURN 2 — ordinary continuation
Continue the same thought. In exactly two short sentences, explain why a cache miss can make the next response slower without changing what is true. Do not use web or any external capability.

TURN 3 — ordinary continuation
Give exactly three bullets defining: semantic truth, context projection, KV cache. Do not use web or any external capability.

TURN 4 — real same-turn reach
Use your web capability to fetch https://example.com/ and tell me in one sentence what the page says this domain is for.

TURN 5 — ordinary turn after reach
Without fetching anything else, in exactly two short sentences connect that returned web result to the difference between semantic continuity and compute-cache reuse.

RETURN

11. After TURN 5 completes, either:
    - Settings -> Debug & diagnostics -> Export Debug ZIP
      OR
    - double-click COLLECT-COMPARISON.command in this folder.

12. Upload that one debug ZIP to ChatGPT.

Do not interpret cached/prefill values yourself. The successor will compare:
  SEND_ACCEPTED
  PROVIDER_STAGE_OBSERVED
  TURN_COMPLETED / TURN_FAILED
  CAPABILITY_RESULT_RETURNED
  promptTokens
  cachedPromptTokens
  prefillTokens
  firstTokenMs
  firstAnswerMs
  totalMs
  serving runtime receipt / PID
  prompt-cache-size
  enhanced-capture runtime-alive observations

A materially better cache result earns the placement change.
If reuse improves only partially, preserve this placement result and investigate the separately
named epoch-spine edge rather than folding another redesign into this run.
EOF

cat > "$OUTPUT_ROOT/COLLECT-COMPARISON.command" <<'EOF'
#!/bin/bash
set -euo pipefail
ORIGIN='http://127.0.0.1:18210'
OUT="$HOME/Downloads/vexlife-pr230-cache-comparison-$(date -u +%Y%m%dT%H%M%SZ).zip"
CURL=''
for candidate in /usr/bin/curl /opt/homebrew/bin/curl /usr/local/bin/curl; do
  if [ -x "$candidate" ] && [ -f "$candidate" ]; then CURL="$candidate"; break; fi
done
[ -n "$CURL" ] || { echo 'curl unavailable.' >&2; exit 10; }
"$CURL" -fsS --max-time 120 "$ORIGIN/api/v1/diagnostics/export" -o "$OUT"
[ -s "$OUT" ] || { echo 'VexLife debug export is empty.' >&2; exit 11; }
DIGEST="$(/usr/bin/shasum -a 256 "$OUT" | /usr/bin/cut -d ' ' -f 1)"
printf 'VexLife comparison debug ZIP\n%s\nsha256 %s\n' "$OUT" "$DIGEST"
/usr/bin/open -R "$OUT" >/dev/null 2>&1 || true
EOF
chmod 0755 "$OUTPUT_ROOT/COLLECT-COMPARISON.command"

DMG_DIGEST="$("$SHASUM_BIN" -a 256 "$OUTPUT_ROOT/VexLife-macOS-AppleSilicon.dmg" | /usr/bin/cut -d ' ' -f 1)"
printf '%s\n' "$CONTINUITY"
printf 'Exact Product head: %s\n' "$SOURCE_HEAD"
printf 'Exact Product tree: %s\n' "$SOURCE_TREE"
printf 'DMG sha256: %s\n' "$DMG_DIGEST"
printf 'Lived comparison folder: %s\n' "$OUTPUT_ROOT"

"$OPEN_BIN" -R "$OUTPUT_ROOT/VexLife-macOS-AppleSilicon.dmg" >/dev/null 2>&1 || true

[VXG RealForever]

VexLife PR #230 lived cache/replay comparison carriage

This is a human-facing Mac startup/measurement companion to Product PR #230.
It does not change the Product candidate.

Exact Product:
  repository VexGPT/VexLife-Prod
  base d0cba51decfe9057ac9afc007fdeb37da213cc97
  head 47decbf10bdb53a33afc21affc1080bcf2b125fd
  tree 110e11ee1b0bd2b30e400455bb935dc2a25a6433

RUN.command:
- acquires that exact source through the authenticated GitHub CLI;
- verifies head/tree/clean ancestry;
- runs the Product-owned archiveVexLifeProdMacApplication task;
- verifies DMG checksum, hdiutil integrity, bundle/source/icon identity;
- writes the verified DMG, receipt, START-HERE.txt and COLLECT-COMPARISON.command under:
    ~/Downloads/VexLife-PR230-47decbf1/
- reveals the exact DMG.

The lived procedure intentionally reuses the predecessor's PR #211 startup/diagnostics pattern.
It preserves the existing Home and serving Qwen model, clears only debug-owned chronology, starts
the Product's bounded enhanced capture, runs three baseline-compatible ordinary turns plus one real
web reach and one ordinary post-reach turn, then returns one Product-owned debug export ZIP.

This carriage authorizes no source mutation, merge, release publication, Home recreation, model
switch, or cache-policy change.

PRODUCT CANDIDATE != LIVED CARRIAGE

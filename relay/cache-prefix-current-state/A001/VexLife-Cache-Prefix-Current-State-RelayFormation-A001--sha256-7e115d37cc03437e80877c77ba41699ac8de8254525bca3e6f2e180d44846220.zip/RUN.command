#!/bin/bash
set -euo pipefail

SDK_REPOSITORY='vgong24/Vextreme-SDK'
SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_TREE='6376f68279f0750ee6d3868b8472368199763064'
CONTRACT_REF='source.vexrelay.current-contract/v1'
EXPECTED_FORMATION_SHA="${VEX_FORMATION_EXPECTED_SHA256:-}"
FORMATION_ZIP="${1:-}"
SCRIPT_ROOT="$(cd "$(dirname "$0")" && pwd -P)"

resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

BASH_BIN="$(resolve_exec /bin/bash)" || { printf '%s\n' 'VexRelay formation: qualified Bash unavailable.' >&2; exit 10; }
GIT_BIN="$(resolve_exec /usr/bin/git)" || { printf '%s\n' 'VexRelay formation: qualified Git unavailable.' >&2; exit 11; }
GH_BIN="$(resolve_exec /opt/homebrew/bin/gh /usr/local/bin/gh)" || { printf '%s\n' 'VexRelay formation: qualified GitHub CLI unavailable.' >&2; exit 12; }
NODE_BIN="$(resolve_exec /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node)" || { printf '%s\n' 'VexRelay formation: qualified Node unavailable.' >&2; exit 13; }
SHASUM_BIN="$(resolve_exec /usr/bin/shasum)" || { printf '%s\n' 'VexRelay formation: shasum unavailable.' >&2; exit 14; }
CUT_BIN="$(resolve_exec /usr/bin/cut)" || { printf '%s\n' 'VexRelay formation: cut unavailable.' >&2; exit 15; }
RM_BIN="$(resolve_exec /bin/rm /usr/bin/rm)" || { printf '%s\n' 'VexRelay formation: rm unavailable.' >&2; exit 16; }

[ -n "$EXPECTED_FORMATION_SHA" ] || { printf '%s\n' 'VexRelay formation: trusted formation ZIP digest was not supplied.' >&2; exit 17; }
case "$EXPECTED_FORMATION_SHA" in
  *[!0-9a-f]*|'') printf '%s\n' 'VexRelay formation: trusted digest is invalid.' >&2; exit 17 ;;
esac
[ "${#EXPECTED_FORMATION_SHA}" -eq 64 ] || { printf '%s\n' 'VexRelay formation: trusted digest is invalid.' >&2; exit 17; }
[ -f "$FORMATION_ZIP" ] && [ ! -L "$FORMATION_ZIP" ] || { printf '%s\n' 'VexRelay formation: formation ZIP is missing or unsafe.' >&2; exit 18; }
OBSERVED_FORMATION_SHA="$("$SHASUM_BIN" -a 256 "$FORMATION_ZIP" | "$CUT_BIN" -d ' ' -f 1)"
[ "$OBSERVED_FORMATION_SHA" = "$EXPECTED_FORMATION_SHA" ] || { printf '%s\n' 'VexRelay formation: formation ZIP digest mismatch.' >&2; exit 19; }

case "$SCRIPT_ROOT" in
  "$HOME"/Downloads/.vexlife-cache-prefix-formation-*) ;;
  *) printf '%s\n' 'VexRelay formation: extracted formation root is outside the admitted Downloads capsule.' >&2; exit 20 ;;
esac

cleanup() {
  case "$SCRIPT_ROOT" in
    "$HOME"/Downloads/.vexlife-cache-prefix-formation-*) "$RM_BIN" -rf -- "$SCRIPT_ROOT" ;;
    *) return 1 ;;
  esac
}
trap cleanup EXIT HUP INT TERM

"$GH_BIN" auth status --hostname github.com >/dev/null 2>&1 || {
  printf '%s\n' 'VexRelay formation: GitHub authentication unavailable.' >&2
  printf '%s\n' 'Run: gh auth login --hostname github.com --web' >&2
  exit 21
}

SDK_ROOT="$SCRIPT_ROOT/Vextreme-SDK"
printf '%s\n' 'VexRelay formation: acquiring exact current SDK source...'
"$GH_BIN" repo clone "$SDK_REPOSITORY" "$SDK_ROOT" -- --no-checkout >/dev/null
"$GIT_BIN" -C "$SDK_ROOT" checkout --detach "$SDK_HEAD" >/dev/null
OBSERVED_SDK_HEAD="$("$GIT_BIN" -C "$SDK_ROOT" rev-parse HEAD)"
OBSERVED_SDK_TREE="$("$GIT_BIN" -C "$SDK_ROOT" rev-parse 'HEAD^{tree}')"
[ "$OBSERVED_SDK_HEAD" = "$SDK_HEAD" ] || { printf '%s\n' 'VexRelay formation: SDK head mismatch.' >&2; exit 22; }
[ "$OBSERVED_SDK_TREE" = "$SDK_TREE" ] || { printf '%s\n' 'VexRelay formation: SDK tree mismatch.' >&2; exit 23; }
[ -z "$("$GIT_BIN" -C "$SDK_ROOT" status --porcelain=v1 -uall)" ] || { printf '%s\n' 'VexRelay formation: acquired SDK source is dirty.' >&2; exit 24; }

CONTRACT="$SDK_ROOT/docs/private-continuity/vexrelay/current-contract.json"
CARRIER_FORMATION="$SDK_ROOT/lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs"
RUNNER="$SDK_ROOT/lib/vexlocalbridge/templates/RUN-VEX-TASK.command"
[ -f "$CONTRACT" ] && [ -f "$CARRIER_FORMATION" ] && [ -f "$RUNNER" ] || {
  printf '%s\n' 'VexRelay formation: required current Relay source is missing.' >&2
  exit 25
}
"$NODE_BIN" -e 'const fs=require("node:fs");const c=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));if(c.contractRef!==process.argv[2])process.exit(1);if(!c.acceptedRecipeFamilies.includes("ExactHeadSourceOwnerProof"))process.exit(2);const a=c.acceptedAdapters.find(x=>x.adapterRef==="adapter.vexlocalbridge.native-vexrelay-task-archive/v1");if(!a||!String(a.state).includes("CURRENT"))process.exit(3);' "$CONTRACT" "$CONTRACT_REF" || {
  printf '%s\n' 'VexRelay formation: current contract does not admit the required recipe/carrier.' >&2
  exit 26
}

RECEIPT="$SCRIPT_ROOT/formation-result.json"
printf '%s\n' 'VexRelay formation: forming fresh time-bound source-owner task...'
"$NODE_BIN" "$SCRIPT_ROOT/formation.mjs" \
  --sdk-root "$SDK_ROOT" \
  --output-directory "$HOME/Downloads" \
  --receipt "$RECEIPT"

TASK_PATH="$("$NODE_BIN" -e 'const fs=require("node:fs");const x=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));process.stdout.write(x.outer.finalZip);' "$RECEIPT")"
TASK_SHA="$("$NODE_BIN" -e 'const fs=require("node:fs");const x=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));process.stdout.write(x.outer.digest);' "$RECEIPT")"
[ -f "$TASK_PATH" ] && [ ! -L "$TASK_PATH" ] || { printf '%s\n' 'VexRelay formation: formed task ZIP is missing or unsafe.' >&2; exit 27; }
OBSERVED_TASK_SHA="$("$SHASUM_BIN" -a 256 "$TASK_PATH" | "$CUT_BIN" -d ' ' -f 1)"
[ "$OBSERVED_TASK_SHA" = "$TASK_SHA" ] || { printf '%s\n' 'VexRelay formation: formed task ZIP digest mismatch.' >&2; exit 28; }

printf 'VexRelay formation: exact task %s\n' "$TASK_PATH"
printf 'VexRelay formation: task sha256 %s\n' "$TASK_SHA"
printf '%s\n' 'VexRelay formation: executing bounded source-owner proof...'
set +e
VEX_EXPECTED_PACKAGE_SHA256="$TASK_SHA" "$BASH_BIN" "$RUNNER" "$TASK_PATH"
STATUS=$?
set -e
[ "$STATUS" -eq 0 ] || exit "$STATUS"
printf '%s\n' 'VexRelay formation: source-owner execution returned. Upload the exact RETURN ZIP revealed by VexLocalBridge.'

#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const PRODUCT = Object.freeze({
  repository: 'VexGPT/VexLife-Prod',
  base: 'd0cba51decfe9057ac9afc007fdeb37da213cc97',
  head: 'cb1280d61e38b9d9a1e64cb80e4f28b59f8124e5',
  tree: '7cda340ab4f725efde3a3ae9b289c8abcb0ab68e',
  branch: 'VXG-111726-cache-prefix-current-state-a001',
  pullRequest: 230,
  changedPaths: Object.freeze([
    'docs/foundation/DIRECT-PERSONAL-COMPANION.md',
    'src/jvmMain/kotlin/vexlife/companion/DirectPromptContext.kt',
    'src/jvmTest/kotlin/vexlife/companion/DirectCompanionCapabilityTurnTest.kt',
    'src/jvmTest/kotlin/vexlife/companion/DirectCompanionTurnFoundationalFieldTest.kt',
    'src/jvmTest/kotlin/vexlife/companion/DirectPromptContextTest.kt',
    'src/jvmTest/kotlin/vexlife/companion/DirectPromptCurrentStateTest.kt',
    'src/jvmTest/kotlin/vexlife/companion/DirectPromptFoundationalFieldTest.kt',
  ]),
});

const SDK = Object.freeze({
  repository: 'vgong24/Vextreme-SDK',
  head: '8543c7d755faba04d4c4019c02e84f992667918a',
  tree: '6376f68279f0750ee6d3868b8472368199763064',
  contractRef: 'source.vexrelay.current-contract/v1',
});

const Scope = 'vexlife-prod.cache-prefix-current-state';
const stable = (kind, ...children) => [kind, Scope, ...children].join('.');
const child = (parent, kind) => `${parent}.${kind}.${crypto.randomUUID()}`;
const identity = Object.freeze({
  root: stable('root'),
  hub: stable('hub'),
  lane: stable('lane'),
  work: stable('work'),
  claim: stable('claim', 'pr230'),
  owner: stable('owner', 'direct-prompt-context'),
  returnRoute: stable('route', 'source-owner-return'),
  task: stable('task', 'source-owner-proof'),
  authority: stable('authority', 'source-owner-proof'),
  sourceSet: stable('source-set', 'prompt-placement'),
  sourceVersion: stable('source-version', PRODUCT.head),
  overlap: stable('overlap', 'pr230-current-main'),
});

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) throw new Error(`unexpected argument: ${token}`);
    const key = token.slice(2);
    const value = argv[++i];
    if (!value || value.startsWith('--')) throw new Error(`missing value for --${key}`);
    out[key] = value;
  }
  return out;
}

function requireFile(filePath, label) {
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    throw new Error(`${label} missing: ${filePath}`);
  }
  return filePath;
}

function makeSeed(now) {
  const attemptRef = child(identity.task, 'attempt');
  const requestRef = child(attemptRef, 'request');
  const correlationRef = child(attemptRef, 'correlation');
  const packageRef = child(attemptRef, 'package');
  const roleRef = child(identity.lane, 'role.coder');
  const instanceRef = child(roleRef, 'instance');
  const occupancyRef = child(roleRef, 'occupancy');
  const providerBindingRef = child(roleRef, 'provider-binding');
  const threadRef = child(identity.lane, 'thread');
  const authorityEnvelopeRef = child(identity.authority, 'envelope');
  const effects = [
    'READ_REPOSITORY',
    'CHECK_STATE',
    'RUN_LOCAL_COMMAND',
    'QUERY_PROVIDER',
    'FORM_RESULT',
  ];
  return {
    schemaVersion: 'vex.relay.task/v2',
    continuity: '[VXG RealForever]',
    taskRef: identity.task,
    attemptRef,
    requestRef,
    correlationRef,
    packageRef,
    original: {
      originalIntent: 'Move only request-current host state behind exact Conversation history so truthful continuity can reuse a stable provider prefix.',
      originalGoal: 'Prove the exact PR #230 source candidate without changing Product, Home, model runtime, provider state, or lifecycle.',
      userProtectedIntent: 'Preserve VexArchitecture ownership and relational identity; cache computation must not become continuity truth.',
      sourceRefs: [
        'github.pull-request.VexGPT.VexLife-Prod.230',
        'github.pull-request.VexGPT.VexLife-Prod.209',
        'source.vexarchitecture.live-demonstration',
        SDK.contractRef,
      ],
    },
    lane: {
      entryClass: 'SAME_LANE_SUCCESSOR',
      scopeMode: 'STAGE_BOUNDED',
      laneRef: identity.lane,
      parentRootRef: identity.root,
      workRef: identity.work,
      claimRef: identity.claim,
      returnRouteRef: identity.returnRoute,
      ownerRef: identity.owner,
      rootHubRef: identity.hub,
    },
    role: {
      activeRole: 'CODER',
      roleRef,
      instanceRef,
      occupancyRef,
      providerBindingRef,
      threadRef,
      authorityEnvelopeRef,
    },
    capabilities: {
      platformGitHubRead: 'AVAILABLE',
      platformGitHubWrite: 'AVAILABLE',
    },
    execution: {
      hostProfile: 'macos-victor',
      executionSurface: 'MAC_ZIP_RUN_COMMAND',
      singleUseNonce: `nonce-${crypto.randomUUID()}`,
      duplicateAttemptMarker: child(attemptRef, 'duplicate-marker'),
      duplicateProtectionMode: 'OUTER_RELAY_BOUND',
      formedAt: now.toISOString(),
      expiresAtOrNull: null,
    },
    workspace: {
      mode: 'RUN_ROOT',
      projectRef: stable('project', 'source-owner-proof'),
      projectPath: 'workspace',
      createRoot: true,
      createProjectPath: true,
    },
    repositories: [
      {
        repositoryRef: 'primary',
        mode: 'CLONE_IN_WORKSPACE',
        cloneTransport: 'GIT',
        cloneUrl: `https://github.com/${PRODUCT.repository}.git`,
        nameWithOwner: PRODUCT.repository,
        localPath: 'repositories/vexlife-prod',
        remote: 'origin',
        baseBranch: 'main',
        acceptedBase: PRODUCT.base,
        checkoutRef: PRODUCT.head,
        expectedHead: PRODUCT.head,
        branch: PRODUCT.branch,
      },
    ],
    authority: {
      authorityRef: identity.authority,
      authorityMode: 'EXACT_STAGE_EFFECTS',
      grantedEffects: effects,
      conditionalEffects: [],
      consumedEffects: [],
      remainingEffects: effects,
      heldEffects: [
        'WRITE_SOURCE',
        'CREATE_BRANCH',
        'CREATE_COMMIT',
        'PUSH_BRANCH',
        'CREATE_PULL_REQUEST',
        'UPDATE_COORDINATION_METADATA',
        'APPROVE_EXACT_HEAD',
        'MARK_READY',
        'ORDINARY_MERGE',
      ],
      repositoryMembranes: [
        { repositoryRef: 'primary', allowedPaths: [...PRODUCT.changedPaths] },
      ],
      allowedExecutables: ['/bin/bash'],
      allowedEnvironment: [],
      remoteObservationOwner: 'Operations',
      allowMutationLoop: false,
      stopConditions: [
        'STOP_ON_IDENTITY_DRIFT',
        'STOP_ON_CANDIDATE_HEAD_OR_TREE_DRIFT',
        'STOP_ON_TEST_FAILURE',
        'STOP_ON_PATH_ESCAPE',
      ],
    },
    source: {
      sourceSetRef: identity.sourceSet,
      sourceVersionRef: identity.sourceVersion,
      overlapEvidenceRef: identity.overlap,
      activeConflictState: 'NONE',
      candidateState: 'EXACT',
      candidateHead: PRODUCT.head,
      candidateTree: PRODUCT.tree,
      expectedChangedPaths: PRODUCT.changedPaths.map((pathValue) => ({
        repositoryRef: 'primary',
        path: pathValue,
      })),
      intentionallyUnchangedAuthorizedPaths: [],
    },
    policy: {
      maxOuterReturnFiles: 10,
      maxSelectedSourceEntries: 10,
      maxSelectedSourceBytes: 5_000_000,
      maxDiffBytes: 10_000_000,
      requireRacePreflightBeforeMutation: false,
      requireLocalValidationBeforePublish: false,
      requireInputPackageManifest: false,
      signoffCommit: true,
      draftPullRequest: true,
    },
  };
}

function makeStage() {
  return {
    repositoryRef: 'primary',
    expectedBase: PRODUCT.base,
    expectedHead: PRODUCT.head,
    expectedTree: PRODUCT.tree,
    branch: PRODUCT.branch,
    maxFiles: PRODUCT.changedPaths.length,
    proofCommands: [
      {
        command: '/bin/bash',
        args: ['./gradlew', '--no-daemon', 'jvmTest'],
        proofClass: 'TEST',
        predicateClass: 'SOURCE_OWNER_BEHAVIOR',
        predicateRef: stable('predicate', 'jvm-source-behavior'),
        candidateEvidence: true,
        acceptedExitCodes: [0],
        timeoutMs: 1_800_000,
      },
      {
        command: '/bin/bash',
        args: [
          './gradlew',
          '--no-daemon',
          'compileKotlinJs',
          'compileTestKotlinJs',
          'checkVexLifeStrings',
          'generateVexLifeWebP1',
        ],
        proofClass: 'TEST',
        predicateClass: 'SOURCE_OWNER_REPOSITORY',
        predicateRef: stable('predicate', 'js-localization-generation'),
        candidateEvidence: true,
        acceptedExitCodes: [0],
        timeoutMs: 1_800_000,
      },
    ],
    stateRef: stable('state', 'source-proof-pending'),
    currentLifecycleState: 'CODER_ACTIVE',
    currentGoal: 'Prove the exact relational current-state placement candidate on Victor Mac.',
    remainingGoals: [
      'Run fresh semantic Assurance on the exact proved head.',
      'Run lived Qwen 27B cache-effectiveness comparison without changing cache/runtime policy.',
    ],
    onPass: {
      lifecycleState: 'ASSURANCE_PENDING',
      nextFunction: 'F13.RUN_FRESH_ASSURANCE',
      nextOwner: 'Operations',
      whyThisIsNext: 'Exact-head source proof is complete; semantic Assurance remains a distinct unconsumed gate.',
    },
    resultFilename: 'RETURN-VEXLIFE-CACHE-PREFIX-CURRENT-STATE-SOURCE-OWNER-A001.zip',
  };
}

function makeAuthorityEnvelope() {
  return {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    semanticAdmissionRef: 'github.pull-request.VexGPT.VexLife-Prod.230',
    transactionRef: stable('transaction', 'source-owner-proof'),
    transactionVersion: 1,
    allowedEffectRefs: ['effect.vexrelay.execute'],
    heldEffectRefs: [
      'effect.source.mutation',
      'effect.provider.publication',
      'effect.lifecycle.approval-ready-merge',
      'effect.home.mutation',
      'effect.model-runtime.mutation',
    ],
  };
}

function makeOuterTask(attemptToken) {
  const outerTaskRef = stable('task', 'source-owner-proof-carrier');
  const outerAttemptRef = `${outerTaskRef}.attempt.${attemptToken}`;
  return {
    schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
    artifactClass: 'EXECUTABLE_RELAY',
    taskRef: outerTaskRef,
    attemptRef: outerAttemptRef,
    packageRef: `${outerAttemptRef}.package`,
    requestRef: `${outerAttemptRef}.request`,
    correlationRef: `${outerAttemptRef}.correlation`,
    taskStorageKey: 'vexlife-prod-cache-prefix-current-state-source-owner-proof',
    attemptStorageKey: `attempt-${attemptToken}`,
    requestingRoleRef: stable('role', 'operations'),
    requestingInstanceRef: `${stable('instance', 'operations')}.${attemptToken}`,
    parentOperationsRef: 'github.pull-request.VexGPT.VexLife-Prod.230',
    returnRouteRef: identity.returnRoute,
    hostProfileRef: 'macos-victor',
    repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
    repositoryRefOrNull: PRODUCT.repository,
    baseRefOrNull: PRODUCT.base,
    headRefOrNull: PRODUCT.head,
    treeRefOrNull: PRODUCT.tree,
    branchRefOrNull: PRODUCT.branch,
    claimRefOrNull: identity.claim,
    exactPathRefs: [...PRODUCT.changedPaths],
    authorityBinding: {
      authoritySchemaRef: 'vextreme.effect-transaction/v1',
      authorityEnvelopePath: 'authority/effect.json',
      authorityEnvelopeSha256: '0'.repeat(64),
      semanticAdmissionRef: 'stale-before-source-managed-binding',
      transactionRef: 'stale-before-source-managed-binding',
      transactionVersion: 1,
      allowedEffectRefs: ['stale-before-source-managed-binding'],
      heldEffectRefs: [],
    },
    payload: {
      payloadClass: 'VEXRELAY_TASK_ARCHIVE',
      payloadRuntime: 'NATIVE_VEXRELAY',
      payloadPath: 'payload/inner-vexrelay.zip',
      payloadSha256: '0'.repeat(64),
      typedArgv: [],
      immutableInputs: [
        { path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) },
      ],
    },
    executionStateAtFormation: 'TASK_PREPARED',
    singleUseNonce: `nonce-${crypto.randomUUID()}`,
    stopConditions: [
      'stop.on.identity.drift',
      'stop.on.package.integrity.failure',
      'stop.on.source-proof.failure',
    ],
    archiveDigestBinding: 'FILENAME_SHA256',
  };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const sdkRoot = path.resolve(args['sdk-root'] ?? '');
  const outputDirectory = path.resolve(args['output-directory'] ?? '');
  const receiptPath = path.resolve(args.receipt ?? '');
  if (!args['sdk-root'] || !args['output-directory'] || !args.receipt) {
    throw new Error('--sdk-root, --output-directory, and --receipt are required');
  }

  const contractPath = requireFile(
    path.join(sdkRoot, 'docs/private-continuity/vexrelay/current-contract.json'),
    'current Relay contract',
  );
  const contract = JSON.parse(fs.readFileSync(contractPath, 'utf8'));
  if (contract.contractRef !== SDK.contractRef) {
    throw new Error(`unexpected Relay contract: ${contract.contractRef}`);
  }
  if (!contract.acceptedRecipeFamilies?.includes('ExactHeadSourceOwnerProof')) {
    throw new Error('ExactHeadSourceOwnerProof is not current');
  }
  const carrier = contract.acceptedAdapters?.find(
    (value) => value.adapterRef === 'adapter.vexlocalbridge.native-vexrelay-task-archive/v1',
  );
  if (!carrier || !String(carrier.state).includes('CURRENT')) {
    throw new Error('native VexRelay task archive carrier is not current');
  }

  const modulePath = requireFile(
    path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs'),
    'native carrier formation source',
  );
  const { formVexRelayTaskArchiveCarrier } = await import(pathToFileURL(modulePath).href);
  const attemptToken = crypto.randomUUID();
  const result = await formVexRelayTaskArchiveCarrier({
    recipe: 'ExactHeadSourceOwnerProof',
    seed: makeSeed(new Date()),
    stage: makeStage(),
    outerTaskTemplate: makeOuterTask(attemptToken),
    authorityEnvelope: makeAuthorityEnvelope(),
    outputDirectory,
    outputStem: 'VEXLIFE-CACHE-PREFIX-CURRENT-STATE-SOURCE-OWNER-A001',
    ttlMs: 4 * 60 * 60 * 1000,
  });

  const receipt = {
    schemaVersion: 'vexlife-prod.cache-prefix-current-state-relay-formation/v1',
    continuity: '[VXG RealForever]',
    product: PRODUCT,
    sdk: SDK,
    inner: {
      taskRef: result.inner.manifest.taskRef,
      attemptRef: result.inner.manifest.attemptRef,
      packageRef: result.inner.manifest.packageRef,
      sha256: result.inner.sha256,
    },
    outer: {
      taskRef: result.outer.task.taskRef,
      attemptRef: result.outer.task.attemptRef,
      packageRef: result.outer.task.packageRef,
      finalZip: result.outer.finalZip,
      digest: result.outer.digest,
      formationEvidence: result.outer.formationEvidence,
    },
  };
  fs.mkdirSync(path.dirname(receiptPath), { recursive: true });
  fs.writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`, 'utf8');
  process.stdout.write(`${JSON.stringify(receipt)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});

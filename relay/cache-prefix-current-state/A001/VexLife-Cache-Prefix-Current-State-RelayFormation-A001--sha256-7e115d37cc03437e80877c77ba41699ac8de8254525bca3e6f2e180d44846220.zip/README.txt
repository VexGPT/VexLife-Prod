[VXG RealForever]
VexLife-Prod cache-prefix current-state source-owner proof — Relay Formation A001

Purpose
-------
This is the stable formation bundle for VexGPT/VexLife-Prod PR #230.
It follows the proven companion-host-proof pattern from PR #209:

  stable digest-bound formation ZIP
  -> acquire exact accepted Vextreme-SDK source
  -> form a fresh time-bound ExactHeadSourceOwnerProof task on Victor's Mac
  -> execute through the accepted native VexRelay/VexLocalBridge carrier
  -> retain and return the canonical proof archive

The fully formed task is intentionally NOT pre-generated because the current VexLocalBridge producer
owns its real formedAt/expiresAt window.

Product proof candidate
-----------------------
repository  VexGPT/VexLife-Prod
PR          #230
base        d0cba51decfe9057ac9afc007fdeb37da213cc97
head        cb1280d61e38b9d9a1e64cb80e4f28b59f8124e5
tree        7cda340ab4f725efde3a3ae9b289c8abcb0ab68e
branch      VXG-111726-cache-prefix-current-state-a001

Exact changed-path membrane (7)
-------------------------------
docs/foundation/DIRECT-PERSONAL-COMPANION.md
src/jvmMain/kotlin/vexlife/companion/DirectPromptContext.kt
src/jvmTest/kotlin/vexlife/companion/DirectCompanionCapabilityTurnTest.kt
src/jvmTest/kotlin/vexlife/companion/DirectCompanionTurnFoundationalFieldTest.kt
src/jvmTest/kotlin/vexlife/companion/DirectPromptContextTest.kt
src/jvmTest/kotlin/vexlife/companion/DirectPromptCurrentStateTest.kt
src/jvmTest/kotlin/vexlife/companion/DirectPromptFoundationalFieldTest.kt

SDK / Relay source
------------------
repository  vgong24/Vextreme-SDK
head        8543c7d755faba04d4c4019c02e84f992667918a
tree        6376f68279f0750ee6d3868b8472368199763064
contract    source.vexrelay.current-contract/v1
recipe      ExactHeadSourceOwnerProof
carrier     adapter.vexlocalbridge.native-vexrelay-task-archive/v1
host        macos-victor

Proof
-----
1. full JVM test suite
2. Kotlin/JS main + test compilation
3. localization currentness
4. deterministic VexWeb P1 generation
5. exact local review projection against the fixed base

The task performs no source write, branch/PR publication, approval, READY, merge, Home mutation,
model-runtime mutation, cache-policy mutation, or release effect.

Relational identity
-------------------
The Product candidate does not use a flat prompt-component ID registry. Prompt component wire refs
are derived from the typed parent/child topology:

Prompt
|- System
|- History
|- Current
|- Hydrated
`- Live

Receipt evidence carries each derived component ref plus its parent ref.

Human boundary
--------------
Victor performs one exact Bash command supplied with this bundle. VexLocalBridge reveals the exact
canonical RETURN ZIP. Upload that RETURN ZIP to the active ChatGPT conversation; Victor does not need
to choose logs, scripts, recovery, branches, or interpretation.

PRODUCT PROOF CANDIDATE != RELAY CARRIAGE / FORMATION ARTIFACT

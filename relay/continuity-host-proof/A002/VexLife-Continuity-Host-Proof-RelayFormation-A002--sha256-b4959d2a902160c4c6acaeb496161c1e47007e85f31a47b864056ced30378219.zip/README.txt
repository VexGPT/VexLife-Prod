VexLife Continuity Host Proof — Relay Formation Bundle A002
[VXG RealForever]

Why this exists
---------------
The canonical VexRelay/VexLocalBridge task ZIP is time-bounded by the current contract
(formedAt/expiresAt), so the stable artifact retained in PR #209 is the exact formation bundle,
not one already-expired task package.

One run:
1. acquires the exact SDK source that contains the current native task-archive formation owner;
2. validates current contractRef + accepted route;
3. forms a fresh ExactHeadSourceOwnerProof package for exact PR #209;
4. executes that package through the accepted macOS VexLocalBridge runner;
5. copies the canonical RETURN ZIP byte-for-byte into ~/Downloads and reveals it.

Bound VexLife-Prod source
-------------------------
PR #208 base/head:
03aee62cdbe3c1e269d9e94e05b1bc06901e3a25

PR #209 exact head:
f065b23e5db99245335c8955e5d51f365197662f

PR #209 exact tree:
41435b82f5e7574ee3e501170e11d3d280dacf5d

PR #209 branch:
VXG-111626-direct-continuity-host-proof-a001

Bound SDK formation source
--------------------------
8543c7d755faba04d4c4019c02e84f992667918a

Human return
------------
Upload the file revealed in Finder whose name begins:
RETURN-VEXLIFE-CONTINUITY-HOST-PROOF-A002--sha256-

No source mutation, push, merge, Product Home mutation, or model-runtime effect is authorized.

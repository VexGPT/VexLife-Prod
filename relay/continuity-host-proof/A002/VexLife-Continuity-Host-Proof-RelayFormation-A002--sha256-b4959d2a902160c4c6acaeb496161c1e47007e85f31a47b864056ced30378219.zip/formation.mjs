#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const SDK_HEAD = '8543c7d755faba04d4c4019c02e84f992667918a';

const BASE = '03aee62cdbe3c1e269d9e94e05b1bc06901e3a25';
const HEAD = 'f065b23e5db99245335c8955e5d51f365197662f';
const TREE = '41435b82f5e7574ee3e501170e11d3d280dacf5d';
const BRANCH = 'VXG-111626-direct-continuity-host-proof-a001';
const BASE_BRANCH = 'VXG-111626-direct-continuity-workbench-a001';
const CHANGED_PATH =
  'src/jvmTest/kotlin/vexlife/companion/DirectContinuityProjectionHostProofTest.kt';

const sdkRoot = process.argv[2];
const outputDirectory = process.argv[3];
if (!sdkRoot || !path.isAbsolute(sdkRoot)) throw new Error('SDK_ROOT_ABSOLUTE_REQUIRED');
if (!outputDirectory || !path.isAbsolute(outputDirectory)) throw new Error('OUTPUT_DIRECTORY_ABSOLUTE_REQUIRED');

const gitHead = spawnSync('/usr/bin/git', ['-C', sdkRoot, 'rev-parse', 'HEAD'], {
  encoding: 'utf8',
});
if (gitHead.status !== 0 || gitHead.stdout.trim() !== SDK_HEAD) {
  throw new Error(`SDK_HEAD_MISMATCH:${gitHead.stdout.trim()}`);
}
const dirty = spawnSync(
  '/usr/bin/git',
  ['-C', sdkRoot, 'status', '--porcelain=v1', '--untracked-files=all'],
  { encoding: 'utf8' },
);
if (dirty.status !== 0 || dirty.stdout.trim()) {
  throw new Error(`SDK_SOURCE_NOT_CLEAN:${dirty.stdout.trim()}`);
}

const contractPath = path.join(
  sdkRoot,
  'docs/private-continuity/vexrelay/current-contract.json',
);
const contract = JSON.parse(fs.readFileSync(contractPath, 'utf8'));
if (contract.contractRef !== 'source.vexrelay.current-contract/v1') {
  throw new Error(`RELAY_CONTRACT_REF_MISMATCH:${contract.contractRef}`);
}
if (
  !contract.acceptedRecipeFamilies?.includes('ExactHeadSourceOwnerProof') ||
  !contract.acceptedAdapters?.some(
    (entry) =>
      entry.adapterRef === 'adapter.vexlocalbridge.native-vexrelay-task-archive/v1' &&
      entry.state === 'TERMINAL_ACCEPTED_CURRENT',
  )
) {
  throw new Error('RELAY_CURRENT_CONTRACT_REQUIRED_ROUTE_NOT_ACCEPTED');
}

for (const rel of [
  'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
  'lib/vexlocalbridge/vexrelay-task-archive.js',
  'lib/vexlocalbridge/package-builder.js',
  'lib/vexlocalbridge/templates/RUN-VEX-TASK.command',
  'lib/vexrelay/recipe-compiler.mjs',
]) {
  if (!fs.existsSync(path.join(sdkRoot, rel))) {
    throw new Error(`REQUIRED_SDK_SOURCE_MISSING:${rel}`);
  }
}

const formationModule = await import(
  pathToFileURL(
    path.join(
      sdkRoot,
      'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
    ),
  ).href,
);
const nativeCarrier = createRequire(import.meta.url)(
  path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js'),
);

const effects = [
  'READ_REPOSITORY',
  'CHECK_STATE',
  'QUERY_PROVIDER',
  'RUN_LOCAL_COMMAND',
  'FORM_RESULT',
];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.continuity-host-proof.source-owner.v1',
  attemptRef: 'attempt.vexlife-prod.continuity-host-proof.source-owner.a002',
  requestRef: 'request.vexlife-prod.continuity-host-proof.source-owner.a002',
  correlationRef: 'correlation.vexlife-prod.continuity-host-proof.source-owner.a002',
  packageRef: 'package.vexlife-prod.continuity-host-proof.source-owner.a002',
  original: {
    originalIntent:
      'Pressure the real DirectPromptContext continuity projection without creating a second semantic owner.',
    originalGoal:
      'Prove the exact PR #209 source shape and reproduce the changing-prefix-before-history relationship on the Mac host.',
    userProtectedIntent:
      'Keep Vex semantic truth separate from prompt/KV computation; do not merge, publish, mutate Home, or start a model runtime in this proof.',
    sourceRefs: [
      'github.pull.VexGPT.VexLife-Prod.208',
      'github.pull.VexGPT.VexLife-Prod.209',
      'source.vexrelay.current-contract/v1',
    ],
  },
  lane: {
    entryClass: 'SAME_LANE_SUCCESSOR',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'github.pull.VexGPT.VexLife-Prod.208.continuity-workbench',
    parentRootRef: 'github.pull.VexGPT.VexLife-Prod.191.cross-model-qualification',
    workRef: 'github.pull.VexGPT.VexLife-Prod.209.continuity-host-proof',
    claimRef: 'claim.read-only-source-proof.vexlife-prod.pr209',
    returnRouteRef: 'return.victor.vexlife-prod.continuity-host-proof.a002',
    ownerRef: 'github.pull.VexGPT.VexLife-Prod.208.continuity-workbench',
    rootHubRef: 'github.repository.VexGPT.VexLife-Prod',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.continuity-host-proof.a002',
    instanceRef: 'instance.vexlife-prod.continuity-host-proof.a002',
    occupancyRef: 'occupancy.vexlife-prod.continuity-host-proof.a002',
    providerBindingRef: 'provider.macos-victor.vexlife-prod.continuity-host-proof.a002',
    threadRef: 'thread.vexlife-prod.continuity-host-proof.a002',
    authorityEnvelopeRef: 'authority-envelope.vexlife-prod.continuity-host-proof.a002',
  },
  capabilities: {
    platformGitHubRead: 'AVAILABLE',
    platformGitHubWrite: 'AVAILABLE',
  },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-continuity-host-proof-a002',
    duplicateAttemptMarker: 'marker.vexlife-prod.continuity-host-proof-a002',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: new Date().toISOString(),
    expiresAtOrNull: null,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.continuity-host-proof',
    projectPath: 'workspace',
    createRoot: true,
    createProjectPath: true,
  },
  repositories: [
    {
      repositoryRef: 'primary',
      mode: 'CLONE_IN_WORKSPACE',
      cloneTransport: 'GIT',
      cloneUrl: 'https://github.com/VexGPT/VexLife-Prod.git',
      nameWithOwner: 'VexGPT/VexLife-Prod',
      localPath: 'repositories/primary',
      remote: 'origin',
      baseBranch: BASE_BRANCH,
      acceptedBase: BASE,
      checkoutRef: HEAD,
      expectedHead: HEAD,
      branch: BRANCH,
    },
  ],
  authority: {
    authorityRef: 'user.request.vexlife-prod.continuity-host-proof.2026-11-16T19-57-08',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: [...effects],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: [...effects],
    heldEffects: [
      'WRITE_SOURCE',
      'CREATE_COMMIT',
      'PUSH_BRANCH',
      'CREATE_PULL_REQUEST',
      'APPROVE_EXACT_HEAD',
      'MARK_READY',
      'ORDINARY_MERGE',
      'MODEL_RUNTIME_EFFECT',
    ],
    repositoryMembranes: [
      {
        repositoryRef: 'primary',
        allowedPaths: [CHANGED_PATH],
      },
    ],
    allowedExecutables: ['bash'],
    allowedEnvironment: [],
    remoteObservationOwner: 'Operations',
    allowMutationLoop: false,
    stopConditions: [
      'STOP_ON_UNKNOWN',
      'STOP_ON_PATH_ESCAPE',
      'STOP_ON_AUTH_BLOCK',
      'STOP_ON_TEST_FAILURE',
    ],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.continuity-host-proof.pr209',
    sourceVersionRef: `git:${HEAD}`,
    overlapEvidenceRef: 'github.pull.VexGPT.VexLife-Prod.209',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: [
      { repositoryRef: 'primary', path: CHANGED_PATH },
    ],
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 10,
    maxSelectedSourceBytes: 1000000,
    maxDiffBytes: 5000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: true,
    signoffCommit: true,
    draftPullRequest: true,
  },
};

const stage = {
  repositoryRef: 'primary',
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: BRANCH,
  proofCommands: [
    {
      command: 'bash',
      args: [
        './gradlew',
        'jvmTest',
        '--tests',
        'vexlife.companion.DirectContinuityProjectionWorkbenchTest',
        '--tests',
        'vexlife.companion.DirectContinuityProjectionHostProofTest',
        '--no-daemon',
        '--stacktrace',
      ],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity.host-proof.focused-jvm',
      timeoutMs: 1200000,
    },
    {
      command: 'bash',
      args: [
        './gradlew',
        'compileKotlinJs',
        'compileTestKotlinJs',
        'checkVexLifeStrings',
        'generateVexLifeWebP1',
        '--no-daemon',
        '--stacktrace',
      ],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity.host-proof.compile-currentness',
      timeoutMs: 1200000,
    },
  ],
  maxFiles: 10,
  stateRef: 'state.vexlife-prod.continuity-host-proof.before-a002',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal:
    'Prove the exact #209 source-only host-proof candidate without changing product behavior.',
  remainingGoals: [
    'Consume canonical VexRelay/VexLocalBridge evidence.',
    'Use the result to decide the smallest production DirectPromptContext experiment.',
  ],
  onPass: {
    lifecycleState: 'ASSURANCE_PENDING',
    nextFunction: 'F13.RUN_FRESH_ASSURANCE',
    nextOwner: 'Operations',
    whyThisIsNext:
      'Exact-head source proof is complete; semantic refinement and any production implementation remain separate.',
  },
  resultFilename: 'RETURN-VEXLIFE-CONTINUITY-HOST-PROOF-A002.zip',
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef:
    'user.request.2026-11-16T19:57-08:00.vexlife-continuity-host-proof',
  transactionRef: 'transaction.vexlife-prod.continuity-host-proof.pr209.a002',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: [
    'effect.source-mutation',
    'effect.publication',
    'effect.model-runtime',
    'effect.merge',
  ],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexlife-prod.continuity-host-proof.outer.v1',
  attemptRef: 'attempt.vexlife-prod.continuity-host-proof.outer.a002',
  packageRef: 'package.vexlife-prod.continuity-host-proof.outer.a002',
  requestRef: 'request.vexlife-prod.continuity-host-proof.outer.a002',
  correlationRef: 'correlation.vexlife-prod.continuity-host-proof.outer.a002',
  taskStorageKey: 'vexlife-prod-continuity-host-proof-pr209',
  attemptStorageKey: 'attempt-a002',
  requestingRoleRef: 'Operations[VexLifeContinuity]',
  requestingInstanceRef: 'instance.vexlife-prod.continuity-host-proof.outer.a002',
  parentOperationsRef: 'github.pull.VexGPT.VexLife-Prod.208',
  returnRouteRef: 'return.victor.vexlife-prod.continuity-host-proof.a002',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: 'VexGPT/VexLife-Prod',
  baseRefOrNull: BASE,
  headRefOrNull: HEAD,
  treeRefOrNull: TREE,
  branchRefOrNull: BRANCH,
  claimRefOrNull: 'github.pull.VexGPT.VexLife-Prod.209',
  exactPathRefs: [CHANGED_PATH],
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'pending-source-managed-binding',
    transactionRef: 'pending-source-managed-binding',
    transactionVersion: 1,
    allowedEffectRefs: ['pending-source-managed-binding'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: nativeCarrier.VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: nativeCarrier.VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [
      {
        path: 'inputs/vexrelay-binding.json',
        sha256: '0'.repeat(64),
      },
    ],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexlife-prod-continuity-host-proof-outer-a002',
  stopConditions: [
    'stop.on.identity.drift',
    'stop.on.test.failure',
    'stop.on.result.integrity',
  ],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const formed = await formationModule.formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'Vex-Continuity-Host-Proof-A002',
  ttlMs: 12 * 60 * 60 * 1000,
});

if (formed.outer.formationEvidence.finalByteQualification !== 'PASS') {
  throw new Error('OUTER_FINAL_BYTE_QUALIFICATION_NOT_PASS');
}
if (formed.inner.manifest.source.candidateHead !== HEAD) {
  throw new Error('INNER_CANDIDATE_HEAD_DRIFT');
}
if (formed.inner.manifest.source.candidateTree !== TREE) {
  throw new Error('INNER_CANDIDATE_TREE_DRIFT');
}

process.stdout.write(
  JSON.stringify(
    {
      state: 'FORMED',
      outerZip: formed.outer.finalZip,
      outerSha256: formed.outer.digest,
      candidateHead: HEAD,
      candidateTree: TREE,
      innerTaskRef: formed.inner.manifest.taskRef,
      stageGate: formed.inner.manifest.completionPolicy.stageGateOrNull,
    },
    null,
    2,
  ) + '\n',
);

const runner = path.join(
  sdkRoot,
  'lib/vexlocalbridge/templates/RUN-VEX-TASK.command',
);
const child = spawnSync('/bin/bash', [runner, formed.outer.finalZip], {
  cwd: outputDirectory,
  encoding: 'utf8',
  maxBuffer: 64 * 1024 * 1024,
});

if (child.stdout) process.stdout.write(child.stdout);
if (child.stderr) process.stderr.write(child.stderr);

if (child.status !== 0) {
  throw new Error(`ACCEPTED_MAC_RUNNER_EXIT:${child.status}`);
}

const matches = [
  ...String(child.stdout || '').matchAll(/"resultZip"\s*:\s*"([^"]+)"/g),
];
if (!matches.length) {
  throw new Error('CANONICAL_RETURN_PATH_NOT_OBSERVED');
}
const canonicalReturn = matches[matches.length - 1][1];
if (!path.isAbsolute(canonicalReturn) || !fs.existsSync(canonicalReturn)) {
  throw new Error(`CANONICAL_RETURN_UNREADABLE:${canonicalReturn}`);
}

const returnBytes = fs.readFileSync(canonicalReturn);
const returnSha256 = crypto.createHash('sha256').update(returnBytes).digest('hex');
const carrierName =
  `RETURN-VEXLIFE-CONTINUITY-HOST-PROOF-A002--sha256-${returnSha256}.zip`;
const carrierPath = path.join(outputDirectory, carrierName);

if (fs.existsSync(carrierPath)) {
  const existing = fs.readFileSync(carrierPath);
  const existingSha256 = crypto.createHash('sha256').update(existing).digest('hex');
  if (existingSha256 !== returnSha256) {
    throw new Error(`RETURN_CARRIER_CONFLICT:${carrierPath}`);
  }
} else {
  fs.copyFileSync(canonicalReturn, carrierPath, fs.constants.COPYFILE_EXCL);
}
const copied = fs.readFileSync(carrierPath);
const copiedSha256 = crypto.createHash('sha256').update(copied).digest('hex');
if (copiedSha256 !== returnSha256) {
  throw new Error('RETURN_CARRIER_COPY_DRIFT');
}

spawnSync('/usr/bin/open', ['-R', carrierPath], {
  encoding: 'utf8',
  maxBuffer: 1024 * 1024,
});

process.stdout.write(
  [
    '',
    'VEX_CONTINUITY_HOST_PROOF_COMPLETE',
    `CANONICAL_RETURN_ZIP=${canonicalReturn}`,
    `CANONICAL_RETURN_SHA256=${returnSha256}`,
    `UPLOAD_THIS_ZIP=${carrierPath}`,
    '',
  ].join('\n'),
);

#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_TREE='6376f68279f0750ee6d3868b8472368199763064'
SDK_REPO='vgong24/Vextreme-SDK'

NODE=''
for candidate in /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node; do
  if [ -x "$candidate" ]; then NODE="$candidate"; break; fi
done
if [ -z "$NODE" ]; then
  printf '%s\n' 'Vex main-health Relay formation: qualified Node executable not found.' >&2
  exit 127
fi

GH=''
for candidate in /opt/homebrew/bin/gh /usr/local/bin/gh; do
  if [ -x "$candidate" ]; then GH="$candidate"; break; fi
done
if [ -z "$GH" ]; then
  printf '%s\n' 'Vex main-health Relay formation: GitHub CLI is required for exact SDK source acquisition.' >&2
  exit 127
fi

"$GH" auth status --hostname github.com >/dev/null

ROOT="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/vex-main-health-relay.XXXXXX")"
SDK="$ROOT/sdk"
cleanup() { /bin/rm -rf "$ROOT"; }
trap cleanup EXIT HUP INT TERM

"$GH" repo clone "$SDK_REPO" "$SDK" -- --no-checkout
/usr/bin/git -C "$SDK" checkout --detach "$SDK_HEAD" >/dev/null

OBSERVED_HEAD="$(/usr/bin/git -C "$SDK" rev-parse HEAD)"
OBSERVED_TREE="$(/usr/bin/git -C "$SDK" rev-parse 'HEAD^{tree}')"
if [ "$OBSERVED_HEAD" != "$SDK_HEAD" ]; then
  printf 'Vex main-health Relay formation: SDK head mismatch expected=%s observed=%s\n' "$SDK_HEAD" "$OBSERVED_HEAD" >&2
  exit 20
fi
if [ "$OBSERVED_TREE" != "$SDK_TREE" ]; then
  printf 'Vex main-health Relay formation: SDK tree mismatch expected=%s observed=%s\n' "$SDK_TREE" "$OBSERVED_TREE" >&2
  exit 21
fi
if [ -n "$(/usr/bin/git -C "$SDK" status --porcelain=v1 --untracked-files=all)" ]; then
  printf '%s\n' 'Vex main-health Relay formation: acquired SDK source is not clean.' >&2
  exit 22
fi

"$NODE" "$SCRIPT_DIR/formation.mjs" "$SDK" "$HOME/Downloads"

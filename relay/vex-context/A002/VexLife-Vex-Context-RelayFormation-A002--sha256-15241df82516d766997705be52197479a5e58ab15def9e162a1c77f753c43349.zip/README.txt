VexLife Vex Context — SourceOwner A002
[VXG RealForever]

Purpose
-------
Re-run the exact current VexRelay SourceOwner proof for corrected VexLife-Prod PR #251.

A001 evidence
-------------
A001 outer carrier PASS; inner SourceOwner SAFE_FAILURE during compileKotlinJvm.
The candidate had two mechanical compile wiring defects: VexWeb did not expose the new Vex Context
Blueprint nodes, and the provider-turn helper referenced intent.contextProfile outside its scope.
Both are corrected in the Product candidate below.

Product candidate
-----------------
PR      #251
base    64c5be05a2e4331de86672d1285923f175e88e9f
head    d70c80bbd0e9da6dc83a136e172b3068978852bf
tree    7705498545fddee01a4e297c7913b548f2cdbb5b
branch  VXG-111726-vex-context-profiles-a001

Sibling Memory currentness observed at formation
-----------------------------------------------
PR #247 head 09598d29282f4d792a277cb5eedb375806214b7f
Relay #254 head 037fb71ebe4af0a55b37ed20a9c4d1804c09fb29
This is sibling context only; A002 does not absorb or rebase Memory semantics.

Relay
-----
contract source.vexrelay.current-contract/v1
SDK head 8543c7d755faba04d4c4019c02e84f992667918a
SDK tree 6376f68279f0750ee6d3868b8472368199763064
recipe   ExactHeadSourceOwnerProof
host     macos-victor

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact full-diff review accounting for all current PR paths

No Product mutation, Home/Memory mutation, approval, READY, merge, or publication effect is authorized.

Expected human return
---------------------
~/Downloads/RETURN-VEXLIFE-VEX-CONTEXT-SOURCEOWNER-A002--sha256-<64 hex>.zip

Upload that one RETURN ZIP even when the terminal says SAFE_FAILURE.

VexLife Vex Context — SourceOwner A001
[VXG RealForever]

Purpose
-------
Run the exact current VexRelay SourceOwner proof for VexLife-Prod PR #251.

Product candidate
-----------------
PR      #251
base    64c5be05a2e4331de86672d1285923f175e88e9f
head    ea6d35f5f5acd63e03c8d7e66c8fbd3c01440187
tree    be2ded12500b9ba412a4e489afdd567468ff78c0
branch  VXG-111726-vex-context-profiles-a001

Relay
-----
contract source.vexrelay.current-contract/v1
SDK head 8543c7d755faba04d4c4019c02e84f992667918a
SDK tree 6376f68279f0750ee6d3868b8472368199763064
recipe   ExactHeadSourceOwnerProof
host     macos-victor

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact full-diff review accounting for all 18 PR paths
   (the current Relay contract permits at most 10 full source-file projections;
    omitted source files remain accounted for in the full diff/index)

No Product mutation, Home/Memory mutation, approval, READY, merge, or publication effect is authorized.

Expected human return
---------------------
~/Downloads/RETURN-VEXLIFE-VEX-CONTEXT-SOURCEOWNER-A001--sha256-<64 hex>.zip

Upload that one RETURN ZIP to the Vex Context ChatGPT conversation even when the terminal says
SAFE_FAILURE. The RETURN owns the exact failure evidence.

This formation bundle is proof carriage only. The source-managed SDK forms the real VexRelay/VexLocalBridge
task window and canonical RETURN on the Mac at execution time.

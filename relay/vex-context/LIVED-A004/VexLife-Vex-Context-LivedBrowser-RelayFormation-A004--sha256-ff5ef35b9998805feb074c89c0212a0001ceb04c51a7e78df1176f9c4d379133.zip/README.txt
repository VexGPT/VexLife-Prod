[VXG RealForever]

VexLife-Prod PR #251 — lived Vex Context browser A004

Purpose
-------
Re-run the exact disposable Vex Context/Profile lived UI circuit on Victor's Mac using the host-native
WebKit stack instead of requiring a separate Google Chrome / Chromium installation.

Predecessor
-----------
LIVED-A003 reached the exact candidate, compiled the temporary Kotlin harness, formed one canonical
scripted DirectCompanionTurn and then stopped at:

    HEADLESS_CHROME_NOT_FOUND

That is a host lived-render dependency absence, not a Product source finding.

Exact Product candidate
-----------------------
repository  VexGPT/VexLife-Prod
PR          #251
base        64c5be05a2e4331de86672d1285923f175e88e9f
head        4ecf2d3c0fb21f9958455313148b7e04eeb759fd
tree        dbf3ec8511c99ee940fd78eecebcd3963eada495
branch      VXG-111726-vex-context-profiles-a001

Lived membrane
--------------
- disposable canonical Vex Home only
- proof-only random-port VexLifeProdLocalService
- one canonical scripted DirectCompanionTurn
- macOS-native WKWebView + AppKit snapshotting
- no ~/.vexlife read/mutation
- no real model call
- no ordinary Product service rotation
- no Memory semantic mutation
- no approval / READY / merge / publication

Host-native renderer
--------------------
The proof command uses:

    /usr/bin/xcrun --find swiftc
    Swift + WebKit.framework + AppKit.framework

A temporary Swift driver loads the actual generated VexWeb and exercises:

- baseline exact request/reply + Product Foundation visibility
- Save As personal Foundation extension
- last-turn receipt remains historical while next-turn profile changes
- save revision 2
- process-view preference remains browser-session presentation
- portable export excludes process retention / Conversation / Memory
- restore Product default while saved profiles remain
- import a new local copy
- View in Vex Home against the disposable Home
- two WKWebView PNG snapshots

The Kotlin and Swift proof files exist only in the exact-checkout build/test workspace; repository
status must return clean before SourceOwner review.

Return
------
Upload the exact canonical:

    RETURN-VEXLIFE-VEX-CONTEXT-LIVED-BROWSER-A004--sha256-<digest>.zip

even on SAFE_FAILURE.

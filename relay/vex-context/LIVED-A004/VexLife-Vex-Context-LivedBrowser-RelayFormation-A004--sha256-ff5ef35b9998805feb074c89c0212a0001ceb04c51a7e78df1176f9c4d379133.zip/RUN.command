#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
SDK_HEAD="8543c7d755faba04d4c4019c02e84f992667918a"
SDK_TREE="6376f68279f0750ee6d3868b8472368199763064"
SDK_REPOSITORY="vgong24/Vextreme-SDK"

resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

GH_BIN="$(resolve_exec /opt/homebrew/bin/gh /usr/local/bin/gh)" || {
  printf '%s\n' 'Vex Context Relay: GitHub CLI is not available.' >&2
  exit 12
}
GIT_BIN="$(resolve_exec /usr/bin/git)" || {
  printf '%s\n' 'Vex Context Relay: Git is not available.' >&2
  exit 13
}
NODE_BIN="$(resolve_exec /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node)" || {
  printf '%s\n' 'Vex Context Relay: Node is not available.' >&2
  exit 14
}
MKTEMP_BIN="$(resolve_exec /usr/bin/mktemp)" || {
  printf '%s\n' 'Vex Context Relay: mktemp is not available.' >&2
  exit 15
}
RM_BIN="$(resolve_exec /bin/rm /usr/bin/rm)" || {
  printf '%s\n' 'Vex Context Relay: rm is not available.' >&2
  exit 16
}

"$GH_BIN" auth status --hostname github.com >/dev/null 2>&1 || {
  printf '%s\n' 'Vex Context Relay: GitHub authentication is required for the private Vextreme-SDK source.' >&2
  printf '%s\n' 'Run: gh auth login --hostname github.com' >&2
  exit 21
}

DOWNLOADS="$HOME/Downloads"
[ -d "$DOWNLOADS" ] || {
  printf '%s\n' 'Vex Context Relay: Downloads folder is unavailable.' >&2
  exit 22
}

BOOT_ROOT="$("$MKTEMP_BIN" -d "$DOWNLOADS/.vex-context-sdk-lived-a004.XXXXXX")"
cleanup() {
  case "$BOOT_ROOT" in
    "$DOWNLOADS"/.vex-context-sdk-lived-a004.*) "$RM_BIN" -rf -- "$BOOT_ROOT" ;;
    *) return 1 ;;
  esac
}
trap cleanup EXIT HUP INT TERM

SDK_ROOT="$BOOT_ROOT/Vextreme-SDK"
printf '%s\n' 'Vex Context Relay: acquiring exact current VexRelay source...'
"$GH_BIN" repo clone "$SDK_REPOSITORY" "$SDK_ROOT" -- --no-checkout >/dev/null
"$GIT_BIN" -C "$SDK_ROOT" checkout --detach "$SDK_HEAD" >/dev/null

OBSERVED_HEAD="$("$GIT_BIN" -C "$SDK_ROOT" rev-parse HEAD)"
OBSERVED_TREE="$("$GIT_BIN" -C "$SDK_ROOT" rev-parse 'HEAD^{tree}')"
[ "$OBSERVED_HEAD" = "$SDK_HEAD" ] || {
  printf 'Vex Context Relay: SDK head mismatch. expected=%s observed=%s\n' "$SDK_HEAD" "$OBSERVED_HEAD" >&2
  exit 23
}
[ "$OBSERVED_TREE" = "$SDK_TREE" ] || {
  printf 'Vex Context Relay: SDK tree mismatch. expected=%s observed=%s\n' "$SDK_TREE" "$OBSERVED_TREE" >&2
  exit 24
}
[ -z "$("$GIT_BIN" -C "$SDK_ROOT" status --porcelain=v1 -uall)" ] || {
  printf '%s\n' 'Vex Context Relay: acquired SDK source is dirty.' >&2
  exit 25
}

"$NODE_BIN" -e 'const fs=require("node:fs"); const x=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); if(x.contractRef!=="source.vexrelay.current-contract/v1") process.exit(27);'   "$SDK_ROOT/docs/private-continuity/vexrelay/current-contract.json"

printf '%s\n' 'Vex Context Relay: forming and executing the exact PR #251 lived Vex Context macOS WebKit proof...'
"$NODE_BIN" "$SCRIPT_DIR/formation.mjs" "$SCRIPT_DIR/relay-context.json" "$SDK_ROOT" "$DOWNLOADS"

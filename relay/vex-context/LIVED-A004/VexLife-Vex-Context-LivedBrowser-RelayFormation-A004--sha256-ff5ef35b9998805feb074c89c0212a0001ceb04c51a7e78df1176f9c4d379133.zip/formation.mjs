import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';

function fail(message) {
  console.error(message);
  process.exit(2);
}

function sha256File(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function filesRecursive(root) {
  const out = [];
  if (!fs.existsSync(root)) return out;
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isSymbolicLink()) fail(`SYMLINK_NOT_ADMITTED:${full}`);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile()) out.push(full);
    }
  };
  walk(root);
  return out.sort();
}

async function runStreaming(command, args, options = {}) {
  const child = spawn(command, args, {
    cwd: options.cwd,
    env: options.env ?? process.env,
    stdio: ['inherit', 'pipe', 'pipe'],
    shell: false,
  });
  let stdout = '';
  let stderr = '';
  child.stdout.on('data', (chunk) => {
    const text = chunk.toString('utf8');
    stdout += text;
    process.stdout.write(text);
  });
  child.stderr.on('data', (chunk) => {
    const text = chunk.toString('utf8');
    stderr += text;
    process.stderr.write(text);
  });
  const status = await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('close', (code, signal) => resolve({ code, signal }));
  });
  return { ...status, stdout, stderr };
}

const [contextPathArg, sdkRootArg, outputDirectoryArg] = process.argv.slice(2);
if (!contextPathArg || !sdkRootArg || !outputDirectoryArg) {
  fail('FORM_ARGS_REQUIRED');
}

const contextPath = path.resolve(contextPathArg);
const sdkRoot = path.resolve(sdkRootArg);
const outputDirectory = path.resolve(outputDirectoryArg);
const context = JSON.parse(fs.readFileSync(contextPath, 'utf8'));

if (context?.sdk?.contractRef !== 'source.vexrelay.current-contract/v1') {
  fail('CONTEXT_RELAY_CONTRACT_REF_MISMATCH');
}

const contractPath = path.join(
  sdkRoot,
  'docs',
  'private-continuity',
  'vexrelay',
  'current-contract.json',
);
const contract = JSON.parse(fs.readFileSync(contractPath, 'utf8'));
if (contract.contractRef !== context.sdk.contractRef) {
  fail(`CURRENT_RELAY_CONTRACT_REF_MISMATCH:${contract.contractRef}`);
}

const seed = structuredClone(context.seed);
const now = new Date();
seed.execution.formedAt = now.toISOString();
seed.execution.expiresAtOrNull =
  new Date(now.getTime() + Number(context.ttlMs)).toISOString();

const formationModule = path.join(
  sdkRoot,
  'lib',
  'vexlocalbridge',
  'vexrelay-task-archive-carrier-formation.mjs',
);
const macRunnerModule = path.join(
  sdkRoot,
  'lib',
  'vexlocalbridge',
  'mac-runner.js',
);
const sourceBootstrapModule = path.join(
  sdkRoot,
  'lib',
  'vexlocalbridge',
  'mac-source-bootstrap-command.js',
);
const cliModule = path.join(
  sdkRoot,
  'lib',
  'vexlocalbridge',
  'cli.js',
);
const profilePath = path.join(
  sdkRoot,
  'docs',
  'private-continuity',
  'vexlocalbridge',
  'profiles',
  'macos-victor-vextreme-sdk.json',
);

const { formVexRelayTaskArchiveCarrier } =
  await import(pathToFileURL(formationModule).href);
const macRunnerImport = await import(pathToFileURL(macRunnerModule).href);
const macRunner = macRunnerImport.default ?? macRunnerImport;
const bootstrapImport = await import(pathToFileURL(sourceBootstrapModule).href);
const bootstrap = bootstrapImport.default ?? bootstrapImport;
const cliImport = await import(pathToFileURL(cliModule).href);
const cli = cliImport.default ?? cliImport;

const profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
const executables = macRunner.resolveProfileExecutables(profile);
const archiveAdapter = macRunner.archiveAdapter(executables);

const formed = await formVexRelayTaskArchiveCarrier({
  recipe: context.recipe,
  seed,
  stage: context.stage,
  outerTaskTemplate: context.outerTaskTemplate,
  authorityEnvelope: context.authorityEnvelope,
  outputDirectory,
  outputStem: context.canonicalOutputStem,
  ttlMs: Number(context.ttlMs),
  archiveAdapter,
});

console.log(
  'VEXRELAY_FORMED\t' +
    JSON.stringify({
      outerZip: formed.outer.finalZip,
      outerSha256: formed.outer.digest,
      innerTaskRef: formed.inner.manifest.taskRef,
      innerAttemptRef: formed.inner.manifest.attemptRef,
      innerPackageRef: formed.inner.manifest.packageRef,
      innerSha256: formed.inner.sha256,
      stageGate: formed.inner.manifest.completionPolicy.stageGateOrNull,
      canonicalInnerReturn: context.stage.resultFilename,
    }),
);

const bootstrapCommand = bootstrap.renderMacSourceBootstrapCommand({
  packageSha256: formed.outer.digest,
  sdkHead: context.sdk.head,
  sdkTree: context.sdk.tree,
});

console.log('VEXRELAY_EXECUTION_START\tVexContextLivedBrowser');
const host = await runStreaming('/bin/bash', ['-c', bootstrapCommand], {
  cwd: outputDirectory,
});

const capsuleRoot = cli.expectedCapsuleRoot(
  formed.outer.finalZip,
  formed.outer.digest,
  profile.zipRelayCapsule,
);
const terminalPointers = filesRecursive(path.join(capsuleRoot, 'state'))
  .filter((filePath) => filePath.endsWith('.terminal.json'));

if (terminalPointers.length !== 1) {
  fail(
    `CANONICAL_TERMINAL_POINTER_COUNT:${terminalPointers.length}:hostExit=${host.code}`,
  );
}

const pointer = JSON.parse(fs.readFileSync(terminalPointers[0], 'utf8'));
if (
  typeof pointer.resultZip !== 'string' ||
  typeof pointer.resultZipSha256 !== 'string' ||
  !/^[a-f0-9]{64}$/.test(pointer.resultZipSha256) ||
  !fs.existsSync(pointer.resultZip)
) {
  fail('CANONICAL_RETURN_POINTER_INVALID');
}

const observedReturnSha256 = sha256File(pointer.resultZip);
if (observedReturnSha256 !== pointer.resultZipSha256) {
  fail(
    `CANONICAL_RETURN_DIGEST_MISMATCH:${pointer.resultZipSha256}:${observedReturnSha256}`,
  );
}

const finalReturn = path.join(
  outputDirectory,
  `${path.basename(context.stage.resultFilename, '.zip')}--sha256-${observedReturnSha256}.zip`,
);

if (fs.existsSync(finalReturn)) {
  const existingSha256 = sha256File(finalReturn);
  if (existingSha256 !== observedReturnSha256) {
    fail(`RETURN_COPY_COLLISION:${finalReturn}`);
  }
} else {
  fs.copyFileSync(pointer.resultZip, finalReturn);
}

if (sha256File(finalReturn) !== observedReturnSha256) {
  fail('FINAL_RETURN_COPY_DIGEST_MISMATCH');
}

console.log(
  'VEXRELAY_HOST_EXIT\t' +
    JSON.stringify({
      code: host.code,
      signal: host.signal,
      canonicalOuterReturn: pointer.resultZip,
      canonicalOuterReturnSha256: observedReturnSha256,
    }),
);
console.log(`RETURN_ZIP=${finalReturn}`);
console.log(`RETURN_SHA256=${observedReturnSha256}`);
console.log(
  host.code === 0
    ? 'VEXRELAY_RETURN_READY: upload the RETURN_ZIP to the Vex Context chat.'
    : 'VEXRELAY_RETURN_READY_WITH_SAFE_FAILURE: upload the RETURN_ZIP anyway; the RETURN owns the failure evidence.',
);

// The human boundary is satisfied when a canonical RETURN exists. Product PASS/SAFE_FAILURE remains
// inside that RETURN and is never rewritten into this helper's exit code.
process.exitCode = 0;

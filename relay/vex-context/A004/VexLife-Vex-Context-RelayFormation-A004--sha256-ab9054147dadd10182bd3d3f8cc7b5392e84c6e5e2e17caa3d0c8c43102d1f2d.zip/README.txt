VexLife Vex Context — SourceOwner A004
[VXG RealForever]

Purpose
-------
Re-prove the exact PR #251 candidate after fresh semantic assurance found and corrected three
ownership leaks that deterministic SourceOwner tests could not classify on their own.

A003 evidence
-------------
A003 outer carrier PASS and inner SourceOwner PASS.

Exact proven A003 candidate:
head d76cc1f212d2aed5ac7a1f3241c6bd18d7205ceb
tree 7cef99e8df38976dfdfcd7537332b34d43c943dd

A003 passed:
- checkVexLifeStrings
- full jvmTest
- compileKotlinJs + compileTestKotlinJs
- exact 21-path SourceOwner review

Fresh semantic assurance
------------------------
Current Vextreme architecture still gives:
- Family -> semantic State / Control / Act / Effect / projection;
- Relay/convergence -> relationship truth composed from independently-owned truths;
- Store/provider -> outside truth;
- presentation -> manifestation, not semantic authority.

Current Memory / Consideration PR #247 remains sibling-owned. Its scaffold explicitly preserves:
CONSIDERATION != MEMORY
SALIENCE != ACCEPTANCE
and does not yet integrate Consideration into DirectPromptContext.

Assurance found three #251 ownership corrections:
1. ProcessRetention was in the portable Context Profile even though it only changes browser-session
   human presentation. It is now a local Vex Context process-view preference and is neither exported
   nor recorded as prompt evidence.
2. View in Vex Home was a ContextProfileFamily Control even though it does not change profile State.
   It is now a direct host/presentation service action.
3. REPLACE/OFF profile modes contradicted the canonical Foundational Field guarantee that the Product
   field is present in every prompt mode. Profiles now preserve Product Foundation always and may only
   add a separately identified personal extension after it.

Product candidate
-----------------
PR      #251
base    64c5be05a2e4331de86672d1285923f175e88e9f
head    4ecf2d3c0fb21f9958455313148b7e04eeb759fd
tree    dbf3ec8511c99ee940fd78eecebcd3963eada495
branch  VXG-111726-vex-context-profiles-a001
paths   22 exact Product paths

Sibling Memory currentness observed at formation
------------------------------------------------
PR #247 head 41473ca787b17bb143d50fb79da565d256856335
Relay #254 head 037fb71ebe4af0a55b37ed20a9c4d1804c09fb29

Memory remains an independently-owned sibling. A004 does not rebase, mutate or absorb it.

Relay
-----
contract source.vexrelay.current-contract/v1
SDK head 8543c7d755faba04d4c4019c02e84f992667918a
SDK tree 6376f68279f0750ee6d3868b8472368199763064
recipe   ExactHeadSourceOwnerProof
host     macos-victor

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact full-diff review accounting for all 22 current PR paths

The current Relay source selects at most 10 complete source-file bodies into the RETURN; the review
index and full diff still account for every changed path.

No Product mutation, Home/Memory mutation, approval, READY, merge, or publication effect is authorized.

Expected human return
---------------------
~/Downloads/RETURN-VEXLIFE-VEX-CONTEXT-SOURCEOWNER-A004--sha256-<64 hex>.zip

Upload that one RETURN ZIP even when the terminal says SAFE_FAILURE.

VexLife Vex Context — SourceOwner A003
[VXG RealForever]

Purpose
-------
Re-run the exact current VexRelay SourceOwner proof for VexLife-Prod PR #251 after A002 reached
the complete JVM suite and exposed three stale proof/projection expectations.

A002 evidence
-------------
A002 outer carrier PASS; inner SourceOwner SAFE_FAILURE during full jvmTest.

Reached:
- repository grounding PASS
- expected head/tree PASS
- checkVexLifeStrings PASS
- compileKotlinJvm PASS
- full jvmTest: 646 tests / 3 failed

The three failures were candidate proof/projection currentness:
1. Foundational Field currentness behavior still failed correctly, but its old assertion substring was
   broken when the error text also named Context Profile.
2. VexLifeWebP1Test still expected 59 Blueprint coordinates after Vex Context earned 11 more.
3. The committed Product Screen Lens had not been regenerated after the Blueprint changed.

Corrections:
- preserve the prior Foundational Field failure vocabulary while checking Context Profile too;
- advance VexWeb coordinate proof to 70;
- regenerate docs/lens/vexlife-prod.screen-lens.json to the exact 70-coordinate Blueprint/VexWeb projection.

Product candidate
-----------------
PR      #251
base    64c5be05a2e4331de86672d1285923f175e88e9f
head    d76cc1f212d2aed5ac7a1f3241c6bd18d7205ceb
tree    7cef99e8df38976dfdfcd7537332b34d43c943dd
branch  VXG-111726-vex-context-profiles-a001
paths   21 exact Product paths

Sibling Memory currentness observed at formation
-----------------------------------------------
PR #247 head 41473ca787b17bb143d50fb79da565d256856335
Relay #254 head 037fb71ebe4af0a55b37ed20a9c4d1804c09fb29

Memory is still moving independently. A003 does not rebase or absorb its semantics. If SourceOwner
passes, semantic assurance must re-read the then-current Memory/Consideration/convergence trajectory.

Relay
-----
contract source.vexrelay.current-contract/v1
SDK head 8543c7d755faba04d4c4019c02e84f992667918a
SDK tree 6376f68279f0750ee6d3868b8472368199763064
recipe   ExactHeadSourceOwnerProof
host     macos-victor

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact full-diff review accounting for all 21 current PR paths

The current Relay source selects at most 10 complete source-file bodies into the RETURN; the review
index and full diff still account for every changed path.

No Product mutation, Home/Memory mutation, approval, READY, merge, or publication effect is authorized.

Expected human return
---------------------
~/Downloads/RETURN-VEXLIFE-VEX-CONTEXT-SOURCEOWNER-A003--sha256-<64 hex>.zip

Upload that one RETURN ZIP even when the terminal says SAFE_FAILURE.

#!/bin/bash
set -euo pipefail

REPO_URL="https://github.com/VexGPT/VexLife-Prod.git"
EXPECTED_HEAD="64d830f3afbc4429a651aa707d4078df740bbb11"
BRANCH="VXG-112126-vex-evolve-context-stage-a002"
ATTEMPT="A006"
DOWNLOADS="$HOME/Downloads"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
WORK="$DOWNLOADS/.vex-evolve-context-$ATTEMPT-$STAMP"
REPO="$WORK/repo"
EVIDENCE="$WORK/evidence"
RETURN_DIR="$WORK/return"
RETURN_ZIP="$DOWNLOADS/RETURN-VEX-EVOLVECONTEXT-STAGE-A006-$STAMP.zip"

mkdir -p "$REPO" "$EVIDENCE" "$RETURN_DIR"

finish_zip() {
  local exit_code="$1"
  {
    echo "attempt=$ATTEMPT"
    echo "expected_head=$EXPECTED_HEAD"
    echo "observed_head=${OBSERVED_HEAD:-UNKNOWN}"
    echo "branch=$BRANCH"
    echo "focused_exit=${FOCUSED_EXIT:-NOT_RUN}"
    echo "full_exit=${FULL_EXIT:-NOT_RUN}"
    echo "runner_exit=$exit_code"
    echo "formed_at_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  } > "$RETURN_DIR/status.txt"

  cp -f "$EVIDENCE"/* "$RETURN_DIR"/ 2>/dev/null || true
  if [[ -d "$EVIDENCE/focused-test-results" ]]; then cp -R "$EVIDENCE/focused-test-results" "$RETURN_DIR/"; fi
  if [[ -d "$EVIDENCE/focused-test-report" ]]; then cp -R "$EVIDENCE/focused-test-report" "$RETURN_DIR/"; fi
  if [[ -d "$EVIDENCE/full-test-results" ]]; then cp -R "$EVIDENCE/full-test-results" "$RETURN_DIR/"; fi
  if [[ -d "$EVIDENCE/full-test-report" ]]; then cp -R "$EVIDENCE/full-test-report" "$RETURN_DIR/"; fi
  (
    cd "$RETURN_DIR"
    /usr/bin/zip -qr "$RETURN_ZIP" .
  )
  echo
  echo "RETURN ZIP: $RETURN_ZIP"
}
trap 'code=$?; finish_zip "$code"; exit "$code"' EXIT

{
  echo "uname: $(uname -a)"
  echo "sw_vers:"
  sw_vers 2>/dev/null || true
  echo "java:"
  java -version 2>&1 || true
  echo "git: $(git --version 2>&1 || true)"
} > "$EVIDENCE/environment.txt"

echo "Fetching exact A006 implementation..."
cd "$REPO"
git init -q
git remote add origin "$REPO_URL"
git fetch -q --depth=1 origin "$EXPECTED_HEAD"
git checkout -q --detach FETCH_HEAD
OBSERVED_HEAD="$(git rev-parse HEAD)"
if [[ "$OBSERVED_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "Expected $EXPECTED_HEAD but observed $OBSERVED_HEAD" >&2
  exit 20
fi
{
  echo "attempt=$ATTEMPT"
  echo "branch=$BRANCH"
  echo "expected_head=$EXPECTED_HEAD"
  echo "observed_head=$OBSERVED_HEAD"
  echo "clean_before=$([[ -z "$(git status --porcelain)" ]] && echo true || echo false)"
} > "$EVIDENCE/source-binding.txt"

git status --short > "$EVIDENCE/source-status-before.txt"
chmod +x gradlew

COMMON=(--no-daemon --max-workers=1 -Pkotlin.compiler.execution.strategy=in-process -Dorg.gradle.jvmargs=-Xmx4g)

echo
echo "Running A006 focused gate..."
set +e
./gradlew jvmTest "${COMMON[@]}" \
  --tests 'vexlife.continuity.DirectConversationContextProjectionTest' \
  --tests 'vexlife.harness.ContinuityPressureAdapterTest.conversationContextProjectionTreatmentPutsOlderExactSourceInTheFirstProviderCall' \
  --tests 'vexlife.companion.DirectPromptContextTest' \
  --tests 'vexlife.companion.DirectTurnContextStoreTest' \
  --tests 'vexlife.service.VexLifeProdLocalServiceTest.newerDurablePromptReceiptHoldsOnlyContextProjection' \
  2>&1 | tee "$EVIDENCE/focused-jvmTest.log"
FOCUSED_EXIT=${PIPESTATUS[0]}
set -e

if [[ -d build/test-results/jvmTest ]]; then cp -R build/test-results/jvmTest "$EVIDENCE/focused-test-results"; fi
if [[ -d build/reports/tests/jvmTest ]]; then cp -R build/reports/tests/jvmTest "$EVIDENCE/focused-test-report"; fi

if [[ "$FOCUSED_EXIT" -ne 0 ]]; then
  echo "Focused gate failed; full regression held." >&2
  exit "$FOCUSED_EXIT"
fi

echo
echo "Focused gate PASS. Running full JVM regression..."
set +e
./gradlew jvmTest "${COMMON[@]}" 2>&1 | tee "$EVIDENCE/full-jvmTest.log"
FULL_EXIT=${PIPESTATUS[0]}
set -e

if [[ -d build/test-results/jvmTest ]]; then cp -R build/test-results/jvmTest "$EVIDENCE/full-test-results"; fi
if [[ -d build/reports/tests/jvmTest ]]; then cp -R build/reports/tests/jvmTest "$EVIDENCE/full-test-report"; fi

git status --short > "$EVIDENCE/source-status-after.txt"
{
  echo "clean_after=$([[ -z "$(git status --porcelain)" ]] && echo true || echo false)"
} >> "$EVIDENCE/source-binding.txt"

if [[ "$FULL_EXIT" -ne 0 ]]; then
  exit "$FULL_EXIT"
fi

echo
echo "A006 focused + full JVM PASS."

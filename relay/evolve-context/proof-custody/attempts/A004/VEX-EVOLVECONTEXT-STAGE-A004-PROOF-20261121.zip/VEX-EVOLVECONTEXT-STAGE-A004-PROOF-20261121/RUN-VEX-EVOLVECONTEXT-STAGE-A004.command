#!/bin/bash
set -euo pipefail

EXPECTED_HEAD="6a793ea6dcd438dfb9be307ed266b38f420cf986"
BRANCH="VXG-112126-vex-evolve-context-stage-a002"
REPO_URL="https://github.com/VexGPT/VexLife-Prod.git"
ATTEMPT="A004"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
ROOT="${TMPDIR:-/tmp}/vex-evolve-context-stage-a004-${STAMP}-$$"
SRC="$ROOT/VexLife-Prod"
RESULT="$ROOT/return"
DOWNLOADS="$HOME/Downloads"
RETURN_ZIP="$DOWNLOADS/RETURN-VEX-EVOLVECONTEXT-STAGE-A004-${STAMP}.zip"
mkdir -p "$ROOT" "$RESULT" "$DOWNLOADS"

capture_test_reports() {
  if [ -d "$SRC/build/test-results/jvmTest" ]; then
    mkdir -p "$RESULT/test-results"
    cp -R "$SRC/build/test-results/jvmTest" "$RESULT/test-results/" || true
  fi
  if [ -d "$SRC/build/reports/tests/jvmTest" ]; then
    mkdir -p "$RESULT/test-reports"
    cp -R "$SRC/build/reports/tests/jvmTest" "$RESULT/test-reports/" || true
  fi
}

finish_failure() {
  code=$?
  capture_test_reports
  if [ -d "$SRC/.git" ]; then
    git -C "$SRC" status --porcelain=v1 > "$RESULT/source-status-after.txt" 2>/dev/null || true
  fi
  {
    echo "state=FAILED"
    echo "attempt=$ATTEMPT"
    echo "exit_code=$code"
    echo "expected_head=$EXPECTED_HEAD"
    echo "branch=$BRANCH"
    echo "formed_at_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  } > "$RESULT/status.txt"
  if command -v zip >/dev/null 2>&1; then
    (cd "$RESULT" && zip -qr "$RETURN_ZIP" .) || true
    if [ -f "$RETURN_ZIP" ]; then
      echo
      echo "RETURN ZIP: $RETURN_ZIP"
      shasum -a 256 "$RETURN_ZIP" 2>/dev/null || true
    fi
  fi
  echo "Proof failed. The RETURN ZIP/report preserves the exact checkpoint."
  exit "$code"
}
trap finish_failure ERR

{
  echo "Vex EvolveContext Stage A004 proof"
  echo "attempt=$ATTEMPT"
  echo "expected_head=$EXPECTED_HEAD"
  echo "branch=$BRANCH"
  echo "started_at_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "host=$(uname -a)"
  echo "git=$(git --version 2>&1 || true)"
  echo "java_begin"
  java -version 2>&1 || true
  echo "java_end"
} | tee "$RESULT/environment.txt"

command -v git >/dev/null 2>&1
command -v java >/dev/null 2>&1
command -v shasum >/dev/null 2>&1
command -v zip >/dev/null 2>&1

echo
echo "[1/4] Cloning exact proof branch..."
git clone --quiet --depth 1 --branch "$BRANCH" "$REPO_URL" "$SRC"
OBSERVED_HEAD="$(git -C "$SRC" rev-parse HEAD)"
printf 'attempt=%s\nexpected_head=%s\nobserved_head=%s\nbranch=%s\n' "$ATTEMPT" "$EXPECTED_HEAD" "$OBSERVED_HEAD" "$BRANCH" | tee "$RESULT/source-binding.txt"
if [ "$OBSERVED_HEAD" != "$EXPECTED_HEAD" ]; then
  echo "SOURCE_HEAD_MISMATCH: branch moved; refusing to test different bytes." >&2
  exit 41
fi

git -C "$SRC" status --porcelain=v1 > "$RESULT/source-status-before.txt"
if [ -s "$RESULT/source-status-before.txt" ]; then
  echo "SOURCE_NOT_CLEAN before proof" >&2
  exit 42
fi

cd "$SRC"
chmod +x gradlew

echo
echo "[2/4] Focused EvolveContext proof..."
set +e
./gradlew jvmTest \
  --no-daemon \
  --max-workers=1 \
  -Pkotlin.compiler.execution.strategy=in-process \
  -Dorg.gradle.jvmargs=-Xmx4g \
  --tests 'vexlife.continuity.VexLifeHostContextContinuationTest' \
  --tests 'vexlife.harness.ContinuityPressureAdapterTest.hostContinuationTreatmentPutsOlderExactSourceInTheFirstProviderCall' \
  2>&1 | tee "$RESULT/focused-jvmTest.log"
FOCUSED_STATUS=${PIPESTATUS[0]}
set -e
printf 'focused_jvmTest_exit=%s\n' "$FOCUSED_STATUS" > "$RESULT/test-status.txt"
if [ "$FOCUSED_STATUS" -ne 0 ]; then
  echo "Focused proof failed; preserving evidence without replaying full JVM regression." >&2
  exit "$FOCUSED_STATUS"
fi

echo
echo "[3/4] Full JVM regression..."
set +e
./gradlew jvmTest \
  --no-daemon \
  --max-workers=1 \
  -Pkotlin.compiler.execution.strategy=in-process \
  -Dorg.gradle.jvmargs=-Xmx4g \
  2>&1 | tee "$RESULT/full-jvmTest.log"
FULL_STATUS=${PIPESTATUS[0]}
set -e
printf 'full_jvmTest_exit=%s\n' "$FULL_STATUS" >> "$RESULT/test-status.txt"
if [ "$FULL_STATUS" -ne 0 ]; then
  echo "Full JVM regression failed; preserving exact completed focused proof + regression failure." >&2
  exit "$FULL_STATUS"
fi

echo
echo "[4/4] Forming RETURN ZIP..."
git -C "$SRC" status --porcelain=v1 > "$RESULT/source-status-after.txt"
printf 'state=PASS\nattempt=%s\nexpected_head=%s\nobserved_head=%s\nfocused_jvmTest_exit=%s\nfull_jvmTest_exit=%s\ncompleted_at_utc=%s\n' \
  "$ATTEMPT" "$EXPECTED_HEAD" "$OBSERVED_HEAD" "$FOCUSED_STATUS" "$FULL_STATUS" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$RESULT/status.txt"

capture_test_reports
(cd "$RESULT" && zip -qr "$RETURN_ZIP" .)
echo
echo "PASS"
echo "RETURN ZIP: $RETURN_ZIP"
shasum -a 256 "$RETURN_ZIP"
trap - ERR
rm -rf "$ROOT"

#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_REPO='vgong24/Vextreme-SDK'

NODE=''
for candidate in /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node; do
  if [ -x "$candidate" ]; then NODE="$candidate"; break; fi
done
[ -n "$NODE" ] || { printf '%s\n' 'Qualified Node executable not found.' >&2; exit 127; }

GH=''
for candidate in /opt/homebrew/bin/gh /usr/local/bin/gh; do
  if [ -x "$candidate" ]; then GH="$candidate"; break; fi
done
[ -n "$GH" ] || { printf '%s\n' 'GitHub CLI not found.' >&2; exit 127; }

"$GH" auth status --hostname github.com >/dev/null

ROOT="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/vex-continuity-cache-baseline.XXXXXX")"
SDK="$ROOT/sdk"
cleanup() { /bin/rm -rf "$ROOT"; }
trap cleanup EXIT

"$GH" repo clone "$SDK_REPO" "$SDK" -- --no-checkout
/usr/bin/git -C "$SDK" checkout --detach "$SDK_HEAD" >/dev/null
OBSERVED="$(/usr/bin/git -C "$SDK" rev-parse HEAD)"
[ "$OBSERVED" = "$SDK_HEAD" ] || { printf 'SDK head mismatch expected=%s observed=%s\n' "$SDK_HEAD" "$OBSERVED" >&2; exit 20; }
[ -z "$(/usr/bin/git -C "$SDK" status --porcelain=v1 --untracked-files=all)" ] || { printf '%s\n' 'Acquired SDK source is not clean.' >&2; exit 21; }

"$NODE" "$SCRIPT_DIR/formation.mjs" "$SDK" "$HOME/Downloads"

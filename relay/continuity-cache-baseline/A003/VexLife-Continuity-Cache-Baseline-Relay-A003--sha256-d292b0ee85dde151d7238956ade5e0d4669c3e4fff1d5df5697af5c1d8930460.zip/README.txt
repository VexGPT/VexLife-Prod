VexLife Continuity Cache Baseline — Relay A003
[VXG RealForever]

This is the SOURCE-PROOF gate for PR #210.

Exact baseline candidate:
head d370079fbaaa863412f859f233f37cc706e25f2d
tree c2698fba02810a8278152d142338c27d78a40c6d
base 03aee62cdbe3c1e269d9e94e05b1bc06901e3a25

It runs:
- full JVM tests, including the new cross-model provider-stage measurement test;
- Kotlin/JS compile;
- localization currentness;
- Web P1 generation.

It does NOT:
- install/replace the VexLife service;
- mutate Product Home;
- start/replace model runtime;
- merge/push/publish.

If PASS, Finder reveals:
RETURN-VEXLIFE-CONTINUITY-CACHE-BASELINE-A003--sha256-<digest>.zip

Upload that ZIP back to ChatGPT. Only after this source proof passes should the lived
two-turn cache baseline be run.

#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const SDK_HEAD = '8543c7d755faba04d4c4019c02e84f992667918a';
const BASE = '03aee62cdbe3c1e269d9e94e05b1bc06901e3a25';
const HEAD = 'd370079fbaaa863412f859f233f37cc706e25f2d';
const TREE = 'c2698fba02810a8278152d142338c27d78a40c6d';
const BRANCH = 'VXG-111626-continuity-cache-baseline-a001';

const sdkRoot = process.argv[2];
const outputDirectory = process.argv[3];
if (!sdkRoot || !path.isAbsolute(sdkRoot)) throw new Error('SDK_ROOT_ABSOLUTE_REQUIRED');
if (!outputDirectory || !path.isAbsolute(outputDirectory)) throw new Error('OUTPUT_DIRECTORY_ABSOLUTE_REQUIRED');

const observedHead = spawnSync('/usr/bin/git', ['-C', sdkRoot, 'rev-parse', 'HEAD'], { encoding: 'utf8' });
if (observedHead.status !== 0 || observedHead.stdout.trim() !== SDK_HEAD) {
  throw new Error(`SDK_HEAD_MISMATCH:${observedHead.stdout.trim()}`);
}
const dirty = spawnSync('/usr/bin/git', ['-C', sdkRoot, 'status', '--porcelain=v1', '--untracked-files=all'], { encoding: 'utf8' });
if (dirty.status !== 0 || dirty.stdout.trim()) throw new Error(`SDK_SOURCE_NOT_CLEAN:${dirty.stdout.trim()}`);

const contract = JSON.parse(fs.readFileSync(path.join(sdkRoot, 'docs/private-continuity/vexrelay/current-contract.json'), 'utf8'));
if (contract.contractRef !== 'source.vexrelay.current-contract/v1') throw new Error('RELAY_CONTRACT_REF_MISMATCH');
if (!contract.acceptedRecipeFamilies?.includes('ExactHeadSourceOwnerProof')) throw new Error('SOURCE_OWNER_RECIPE_NOT_CURRENT');
if (!contract.acceptedAdapters?.some((entry) => entry.adapterRef === 'adapter.vexlocalbridge.native-vexrelay-task-archive/v1' && entry.state === 'TERMINAL_ACCEPTED_CURRENT')) {
  throw new Error('NATIVE_VEXRELAY_CARRIER_NOT_CURRENT');
}

for (const rel of [
  'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
  'lib/vexlocalbridge/vexrelay-task-archive.js',
  'lib/vexlocalbridge/templates/RUN-VEX-TASK.command',
  'lib/vexrelay/recipe-compiler.mjs',
]) {
  if (!fs.existsSync(path.join(sdkRoot, rel))) throw new Error(`REQUIRED_SDK_SOURCE_MISSING:${rel}`);
}

const formationModule = await import(pathToFileURL(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs')).href);
const nativeCarrier = createRequire(import.meta.url)(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js'));

const changedPaths = [
  'docs/foundation/VEXLOGGER.md',
  'src/jvmMain/kotlin/vexlife/companion/DirectCompanionConnection.kt',
  'src/jvmMain/kotlin/vexlife/companion/DirectCompanionTurn.kt',
  'src/jvmMain/kotlin/vexlife/logging/VexLogger.kt',
  'src/jvmTest/kotlin/vexlife/companion/DirectContinuityProjectionHostProofTest.kt',
  'src/jvmTest/kotlin/vexlife/companion/DirectProviderStageMeasurementTest.kt',
];

const effects = ['READ_REPOSITORY','CHECK_STATE','QUERY_PROVIDER','RUN_LOCAL_COMMAND','FORM_RESULT'];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.continuity-cache-baseline.source-owner.v1',
  attemptRef: 'attempt.vexlife-prod.continuity-cache-baseline.source-owner.a003',
  requestRef: 'request.vexlife-prod.continuity-cache-baseline.source-owner.a003',
  correlationRef: 'correlation.vexlife-prod.continuity-cache-baseline.source-owner.a003',
  packageRef: 'package.vexlife-prod.continuity-cache-baseline.source-owner.a003',
  original: {
    originalIntent: 'Measure real provider-stage cache reuse before changing DirectPromptContext topology.',
    originalGoal: 'Prove the cross-model baseline instrumentation compiles and preserves existing behavior on exact source.',
    userProtectedIntent: 'Do not mutate Product Home, start/replace model runtime, publish, merge, or alter semantic continuity during source proof.',
    sourceRefs: ['github.pull.VexGPT.VexLife-Prod.208','github.pull.VexGPT.VexLife-Prod.210','github.pull.VexGPT.VexLife-Prod.207','source.vexrelay.current-contract/v1'],
  },
  lane: {
    entryClass: 'SAME_LANE_SUCCESSOR',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'github.pull.VexGPT.VexLife-Prod.208.continuity-workbench',
    parentRootRef: 'github.pull.VexGPT.VexLife-Prod.191.cross-model-qualification',
    workRef: 'github.pull.VexGPT.VexLife-Prod.210.cache-baseline',
    claimRef: 'claim.read-only-source-proof.vexlife-prod.pr210',
    returnRouteRef: 'return.victor.vexlife-prod.continuity-cache-baseline.a003',
    ownerRef: 'github.pull.VexGPT.VexLife-Prod.210.cache-baseline',
    rootHubRef: 'github.repository.VexGPT.VexLife-Prod',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.continuity-cache-baseline.a003',
    instanceRef: 'instance.vexlife-prod.continuity-cache-baseline.a003',
    occupancyRef: 'occupancy.vexlife-prod.continuity-cache-baseline.a003',
    providerBindingRef: 'provider.macos-victor.vexlife-prod.continuity-cache-baseline.a003',
    threadRef: 'thread.vexlife-prod.continuity-cache-baseline.a003',
    authorityEnvelopeRef: 'authority-envelope.vexlife-prod.continuity-cache-baseline.a003',
  },
  capabilities: { platformGitHubRead: 'AVAILABLE', platformGitHubWrite: 'AVAILABLE' },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-continuity-cache-baseline-a003',
    duplicateAttemptMarker: 'marker.vexlife-prod-continuity-cache-baseline-a003',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: new Date().toISOString(),
    expiresAtOrNull: null,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.continuity-cache-baseline',
    projectPath: 'workspace',
    createRoot: true,
    createProjectPath: true,
  },
  repositories: [{
    repositoryRef: 'primary',
    mode: 'CLONE_IN_WORKSPACE',
    cloneTransport: 'GIT',
    cloneUrl: 'https://github.com/VexGPT/VexLife-Prod.git',
    nameWithOwner: 'VexGPT/VexLife-Prod',
    localPath: 'repositories/primary',
    remote: 'origin',
    baseBranch: 'VXG-111626-direct-continuity-workbench-a001',
    acceptedBase: BASE,
    checkoutRef: HEAD,
    expectedHead: HEAD,
    branch: BRANCH,
  }],
  authority: {
    authorityRef: 'user.request.vexlife-prod.continuity-cache-baseline.2026-11-16',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: [...effects],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: [...effects],
    heldEffects: ['WRITE_SOURCE','CREATE_COMMIT','PUSH_BRANCH','CREATE_PULL_REQUEST','APPROVE_EXACT_HEAD','MARK_READY','ORDINARY_MERGE','MODEL_RUNTIME_EFFECT','PRODUCT_HOME_MUTATION'],
    repositoryMembranes: [{ repositoryRef: 'primary', allowedPaths: changedPaths }],
    allowedExecutables: ['bash'],
    allowedEnvironment: [],
    remoteObservationOwner: 'Operations',
    allowMutationLoop: false,
    stopConditions: ['STOP_ON_UNKNOWN','STOP_ON_PATH_ESCAPE','STOP_ON_AUTH_BLOCK','STOP_ON_TEST_FAILURE'],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.continuity-cache-baseline.pr210',
    sourceVersionRef: `git:${HEAD}`,
    overlapEvidenceRef: 'github.pull.VexGPT.VexLife-Prod.210',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: changedPaths.map((p) => ({ repositoryRef: 'primary', path: p })),
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 10,
    maxSelectedSourceBytes: 1500000,
    maxDiffBytes: 5000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: true,
    signoffCommit: true,
    draftPullRequest: true,
  },
};

const stage = {
  repositoryRef: 'primary',
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: BRANCH,
  proofCommands: [
    {
      command: 'bash',
      args: ['./gradlew','jvmTest','--no-daemon','--stacktrace'],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity-cache-baseline.jvm',
      timeoutMs: 1800000,
    },
    {
      command: 'bash',
      args: ['./gradlew','compileKotlinJs','compileTestKotlinJs','checkVexLifeStrings','generateVexLifeWebP1','--no-daemon','--stacktrace'],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.continuity-cache-baseline.compile',
      timeoutMs: 1200000,
    },
  ],
  maxFiles: 10,
  stateRef: 'state.vexlife-prod.continuity-cache-baseline.before-a003',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal: 'Prove exact baseline measurement source before any lived runtime test.',
  remainingGoals: ['Consume canonical return.','Run controlled lived cache baseline only if source proof passes.'],
  onPass: {
    lifecycleState: 'ASSURANCE_PENDING',
    nextFunction: 'F13.RUN_FRESH_ASSURANCE',
    nextOwner: 'Operations',
    whyThisIsNext: 'Exact source proof is complete; lived measurement remains a separate host effect.',
  },
  resultFilename: 'RETURN-VEXLIFE-CONTINUITY-CACHE-BASELINE-A003.zip',
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef: 'user.request.2026-11-16.vexlife-continuity-cache-baseline',
  transactionRef: 'transaction.vexlife-prod.continuity-cache-baseline.pr210.a003',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: ['effect.source-mutation','effect.publication','effect.model-runtime','effect.product-home','effect.merge'],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexlife-prod.continuity-cache-baseline.outer.v1',
  attemptRef: 'attempt.vexlife-prod.continuity-cache-baseline.outer.a003',
  packageRef: 'package.vexlife-prod.continuity-cache-baseline.outer.a003',
  requestRef: 'request.vexlife-prod.continuity-cache-baseline.outer.a003',
  correlationRef: 'correlation.vexlife-prod.continuity-cache-baseline.outer.a003',
  taskStorageKey: 'vexlife-prod-continuity-cache-baseline-pr210',
  attemptStorageKey: 'attempt-a003',
  requestingRoleRef: 'Operations[VexLifeContinuity]',
  requestingInstanceRef: 'instance.vexlife-prod.continuity-cache-baseline.outer.a003',
  parentOperationsRef: 'github.pull.VexGPT.VexLife-Prod.210',
  returnRouteRef: 'return.victor.vexlife-prod.continuity-cache-baseline.a003',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: 'VexGPT/VexLife-Prod',
  baseRefOrNull: BASE,
  headRefOrNull: HEAD,
  treeRefOrNull: TREE,
  branchRefOrNull: BRANCH,
  claimRefOrNull: 'github.pull.VexGPT.VexLife-Prod.210',
  exactPathRefs: changedPaths,
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'pending-source-managed-binding',
    transactionRef: 'pending-source-managed-binding',
    transactionVersion: 1,
    allowedEffectRefs: ['pending-source-managed-binding'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: nativeCarrier.VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: nativeCarrier.VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [{ path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) }],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexlife-prod-continuity-cache-baseline-outer-a003',
  stopConditions: ['stop.on.identity.drift','stop.on.test.failure','stop.on.result.integrity'],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const formed = await formationModule.formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'Vex-Continuity-Cache-Baseline-A003',
  ttlMs: 12 * 60 * 60 * 1000,
});

if (formed.outer.formationEvidence.finalByteQualification !== 'PASS') throw new Error('OUTER_FINAL_BYTE_QUALIFICATION_NOT_PASS');
if (formed.inner.manifest.source.candidateHead !== HEAD) throw new Error('INNER_CANDIDATE_HEAD_DRIFT');
if (formed.inner.manifest.source.candidateTree !== TREE) throw new Error('INNER_CANDIDATE_TREE_DRIFT');

process.stdout.write(JSON.stringify({
  state:'FORMED',
  outerZip:formed.outer.finalZip,
  outerSha256:formed.outer.digest,
  candidateHead:HEAD,
  candidateTree:TREE,
  innerTaskRef:formed.inner.manifest.taskRef,
  stageGate:formed.inner.manifest.completionPolicy.stageGateOrNull,
}, null, 2) + '\n');

const runner = path.join(sdkRoot, 'lib/vexlocalbridge/templates/RUN-VEX-TASK.command');
const child = spawnSync('/bin/bash', [runner, formed.outer.finalZip], {
  cwd: outputDirectory,
  encoding: 'utf8',
  maxBuffer: 64 * 1024 * 1024,
});
if (child.stdout) process.stdout.write(child.stdout);
if (child.stderr) process.stderr.write(child.stderr);
if (child.status !== 0) throw new Error(`ACCEPTED_MAC_RUNNER_EXIT:${child.status}`);

const matches = [...String(child.stdout || '').matchAll(/"resultZip"\s*:\s*"([^"]+)"/g)];
if (!matches.length) throw new Error('CANONICAL_RETURN_PATH_NOT_OBSERVED');
const canonicalReturn = matches[matches.length-1][1];
if (!path.isAbsolute(canonicalReturn) || !fs.existsSync(canonicalReturn)) throw new Error(`CANONICAL_RETURN_UNREADABLE:${canonicalReturn}`);

const bytes = fs.readFileSync(canonicalReturn);
const digest = crypto.createHash('sha256').update(bytes).digest('hex');
const target = path.join(outputDirectory, `RETURN-VEXLIFE-CONTINUITY-CACHE-BASELINE-A003--sha256-${digest}.zip`);
if (!fs.existsSync(target)) fs.copyFileSync(canonicalReturn, target, fs.constants.COPYFILE_EXCL);
const copied = crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
if (copied !== digest) throw new Error('RETURN_CARRIER_COPY_DRIFT');
spawnSync('/usr/bin/open', ['-R', target], { encoding:'utf8' });

process.stdout.write(`\nVEX_CONTINUITY_CACHE_BASELINE_SOURCE_PROOF_COMPLETE\nUPLOAD_THIS_ZIP=${target}\nCANONICAL_RETURN_SHA256=${digest}\n`);

VexLife PR #210 Mac Startup Artifact A004
[VXG RealForever]

Purpose:
Build and verify the exact PR #210 product candidate as the human-facing DMG required by
VexLife-Prod onboarding, then retain that DMG under ~/Downloads/VexLife-PR210-d370079f/.

Product candidate (immutable):
  head d370079fbaaa863412f859f233f37cc706e25f2d
  tree c2698fba02810a8278152d142338c27d78a40c6d

The bundle itself is carriage only and may be committed after the product candidate.

The build follows the source-owned Mac application route:
  archiveVexLifeProdMacApplication
    -> source-bound private service image
    -> VexLife.app
    -> VexLife-macOS-AppleSilicon.dmg

It verifies:
- exact Git head + tree + clean checkout
- DMG SHA-256
- hdiutil verify
- VexLife.app present with Applications shortcut
- bundle identifier com.vexlife.prod
- app/volume icon contract

The output folder also contains START-HERE.txt and COLLECT-BASELINE.command.

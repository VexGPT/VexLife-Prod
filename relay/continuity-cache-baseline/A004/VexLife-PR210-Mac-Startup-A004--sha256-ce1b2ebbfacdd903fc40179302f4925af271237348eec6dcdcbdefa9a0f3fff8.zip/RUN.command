#!/bin/bash
set -euo pipefail

SOURCE_SHA="d370079fbaaa863412f859f233f37cc706e25f2d"
SOURCE_TREE="c2698fba02810a8278152d142338c27d78a40c6d"
REPOSITORY="VexGPT/VexLife-Prod"
OUT="$HOME/Downloads/VexLife-PR210-d370079f"

GH=""
for candidate in /opt/homebrew/bin/gh /usr/local/bin/gh; do
  if [ -x "$candidate" ]; then GH="$candidate"; break; fi
done
[ -n "$GH" ] || { printf '%s\n' "GitHub CLI not found." >&2; exit 127; }
"$GH" auth status --hostname github.com >/dev/null

ROOT="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/vexlife-pr210-dmg.XXXXXX")"
SRC="$ROOT/source"
MOUNT="$ROOT/mount"
cleanup() {
  /usr/bin/hdiutil detach "$MOUNT" >/dev/null 2>&1 || true
  /bin/rm -rf "$ROOT"
}
trap cleanup EXIT

"$GH" repo clone "$REPOSITORY" "$SRC" -- --no-checkout
/usr/bin/git -C "$SRC" checkout --detach "$SOURCE_SHA" >/dev/null

OBS_HEAD="$(/usr/bin/git -C "$SRC" rev-parse HEAD)"
OBS_TREE="$(/usr/bin/git -C "$SRC" rev-parse 'HEAD^{tree}')"
[ "$OBS_HEAD" = "$SOURCE_SHA" ] || {
  printf 'Candidate head mismatch expected=%s observed=%s\n' "$SOURCE_SHA" "$OBS_HEAD" >&2
  exit 20
}
[ "$OBS_TREE" = "$SOURCE_TREE" ] || {
  printf 'Candidate tree mismatch expected=%s observed=%s\n' "$SOURCE_TREE" "$OBS_TREE" >&2
  exit 21
}
[ -z "$(/usr/bin/git -C "$SRC" status --porcelain=v1 --untracked-files=all)" ] || {
  printf '%s\n' "Candidate checkout is not clean." >&2
  exit 22
}

cd "$SRC"
./gradlew --no-daemon -PvexlifeAppVersion=0.0.0 archiveVexLifeProdMacApplication

APP_DIR="$SRC/build/vexlife-prod-mac-application/$SOURCE_SHA"
DMG="$APP_DIR/VexLife-macOS-AppleSilicon.dmg"
SHA_FILE="$APP_DIR/VexLife-macOS-AppleSilicon.dmg.sha256"
RECEIPT="$APP_DIR/VexLife-macOS-AppleSilicon.receipt.json"

test -f "$DMG"
test -f "$SHA_FILE"
test -f "$RECEIPT"
(cd "$APP_DIR" && /usr/bin/shasum -a 256 -c "VexLife-macOS-AppleSilicon.dmg.sha256")
/usr/bin/hdiutil verify "$DMG"

mkdir -p "$MOUNT"
/usr/bin/hdiutil attach "$DMG" -readonly -nobrowse -mountpoint "$MOUNT"
test -d "$MOUNT/VexLife.app"
test -e "$MOUNT/Applications"
/usr/bin/plutil -extract CFBundleIdentifier raw -o - "$MOUNT/VexLife.app/Contents/Info.plist" | /usr/bin/grep -Fx 'com.vexlife.prod'
/usr/bin/plutil -extract CFBundleIconFile raw -o - "$MOUNT/VexLife.app/Contents/Info.plist" | /usr/bin/grep -Fx 'applet'
test -s "$MOUNT/VexLife.app/Contents/Resources/applet.icns"
test ! -e "$MOUNT/VexLife.app/Contents/Resources/Assets.car"
if /usr/bin/plutil -extract CFBundleIconName raw -o - "$MOUNT/VexLife.app/Contents/Info.plist" >/dev/null 2>&1; then
  printf '%s\n' "CFBundleIconName must be absent." >&2
  exit 23
fi
test -s "$MOUNT/.VolumeIcon.icns"
/usr/bin/hdiutil detach "$MOUNT"
mkdir -p "$OUT"

copy_exact() {
  SRC_FILE="$1"
  DEST="$2"
  if [ -e "$DEST" ]; then
    A="$(/usr/bin/shasum -a 256 "$SRC_FILE" | /usr/bin/awk '{print $1}')"
    B="$(/usr/bin/shasum -a 256 "$DEST" | /usr/bin/awk '{print $1}')"
    [ "$A" = "$B" ] || {
      printf 'Existing output differs; preserving both by refusing overwrite: %s\n' "$DEST" >&2
      exit 24
    }
  else
    /bin/cp "$SRC_FILE" "$DEST"
  fi
}

copy_exact "$DMG" "$OUT/VexLife-macOS-AppleSilicon.dmg"
copy_exact "$SHA_FILE" "$OUT/VexLife-macOS-AppleSilicon.dmg.sha256"
copy_exact "$RECEIPT" "$OUT/VexLife-macOS-AppleSilicon.receipt.json"

cat > "$OUT/START-HERE.txt" <<'EOF'
VexLife PR #210 — lived cache baseline
[VXG RealForever]

1. Open VexLife-macOS-AppleSilicon.dmg.
2. Drag VexLife.app to Applications. If macOS asks whether to replace an older VexLife.app, replace it.
3. Launch VexLife from Applications.
4. This build is ad-hoc signed, not Developer ID signed/notarized.
   If Gatekeeper blocks the first launch:
     System Settings -> Privacy & Security -> Open Anyway
   macOS may separately ask to open the bundled Java runtime; choose Open only for this exact candidate.
5. Let the existing Setup Journey observe your existing Home. Do NOT recreate Home just for this test.
   Take only the control the card actually offers:
     UPDATE_AVAILABLE          -> Update & Restart
     START_REQUIRED            -> Start VexLife
     CURRENT                   -> Open VexLife
     SETUP_REQUIRED            -> Set Up VexLife
     HOME_HELD / HOST_HELD /
     STORAGE_HELD /
     MODEL_FILES_HELD /
     HOLD_UNKNOWN              -> stop and return evidence; do not improvise repair.
6. Once the workspace is open, keep the SAME serving model for all baseline turns. Do not switch models.

Baseline turns:
TURN 1
For this cache baseline, answer in exactly two short sentences: explain the difference between semantic continuity and compute-cache reuse. Do not use web or other capabilities.

TURN 2
Continue from your previous answer in exactly two short sentences: explain why a cache miss should make Vex slower without changing what remains true. Do not use web or other capabilities.

TURN 3
Summarize the distinction across your last two answers in exactly three bullets using the terms semantic truth, context projection, and KV cache. Do not use web or other capabilities.

After Turn 3:
Settings -> Debug & diagnostics -> Export Debug ZIP

Return that debug ZIP to ChatGPT.
EOF

cat > "$OUT/COLLECT-BASELINE.command" <<'EOF'
#!/bin/bash
set -euo pipefail
OUT="$(cd "$(dirname "$0")" && pwd -P)"
STAMP="$(/bin/date -u +%Y%m%dT%H%M%SZ)"
TARGET="$OUT/VexLife-PR210-baseline-debug-$STAMP.zip"
/usr/bin/curl -fSs "http://127.0.0.1:18210/api/v1/diagnostics/export" -o "$TARGET"
DIGEST="$(/usr/bin/shasum -a 256 "$TARGET" | /usr/bin/awk '{print $1}')"
printf 'DEBUG_ZIP=%s\nSHA256=%s\n' "$TARGET" "$DIGEST"
/usr/bin/open -R "$TARGET"
EOF
/bin/chmod +x "$OUT/COLLECT-BASELINE.command"

DMG_SHA="$(/usr/bin/shasum -a 256 "$OUT/VexLife-macOS-AppleSilicon.dmg" | /usr/bin/awk '{print $1}')"
printf '\nVEXLIFE_PR210_DMG_READY\nSOURCE_SHA=%s\nSOURCE_TREE=%s\nDMG=%s\nDMG_SHA256=%s\nSTART_HERE=%s\n\n'   "$SOURCE_SHA" "$SOURCE_TREE" "$OUT/VexLife-macOS-AppleSilicon.dmg" "$DMG_SHA" "$OUT/START-HERE.txt"

/usr/bin/open -R "$OUT/VexLife-macOS-AppleSilicon.dmg"

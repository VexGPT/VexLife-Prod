VexLife Memory Review / Keep — Relay Formation A001
[VXG RealForever]

Exact Product candidate
-----------------------
PR #276
base 428bb31c8609474ecd6528a044ee47a9a9e89628
head 7cb94f3f73c1de5c5b40254e10318c3ad0a607d8
tree a5808934d53839e7674d454ca5ffd3494c45718f

Five-path membrane
------------------
- docs/work/memory-correction-review-keep/README.md
- src/commonMain/kotlin/vexlife/memory/VexLifeMemoryReviewFamily.kt
- src/commonTest/kotlin/vexlife/memory/VexLifeMemoryReviewFamilyTest.kt
- src/jvmMain/kotlin/vexlife/memory/VexLifeMemoryReviewOwner.kt
- src/jvmTest/kotlin/vexlife/memory/VexLifeMemoryReviewOwnerTest.kt

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact five-path SourceOwner review

What A001 must prove
--------------------
- pending correction review is non-authoritative;
- Keep / Not now / Decline are typed against one exact review candidate;
- Not now / Decline create no semantic acceptance or Score;
- Keep uses the merged #247 semantic writer and existing Score;
- stale Conversation blocks Keep;
- retry after acceptance reuses exact human-decision-bound acceptance;
- retry after Score reuses the deterministic current statement without duplication.

No prompt/provider/service/web/Home/model/publication/merge effect is authorized.

Return
------
Upload the Finder-revealed ZIP beginning:

RETURN-VEXLIFE-MEMORY-REVIEW-KEEP-SOURCEOWNER-A001--sha256-

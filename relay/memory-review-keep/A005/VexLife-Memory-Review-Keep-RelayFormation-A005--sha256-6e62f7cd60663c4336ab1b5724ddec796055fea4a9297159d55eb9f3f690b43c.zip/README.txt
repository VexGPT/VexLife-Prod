VexLife Memory Review / Keep — Relay Formation A005
[VXG RealForever]

Why A005 exists
---------------
A004 proved the exact Score-probe-corrected candidate. Fresh semantic Assurance then found two
restart/custody gaps before READY:

1. one pending review could durably record a human decision and crash before state resolution,
   then later accept a conflicting second decision;
2. Keep checked Conversation currentness before acceptance, but acceptance and Score did not share
   one Conversation writer lease.

PR #276 now preserves:

- ONE PENDING REVIEW -> ONE FIRST DURABLE HUMAN DECISION;
- same-human/same-control retry reuses the exact decision ref/hash/decidedAt;
- different human or control is rejected once a decision is durable;
- Not now / Decline write the decision once, then resolve without Memory mutation;
- Keep writes its decision only after acquiring the exact Conversation writer lease;
- semantic acceptance and Score append occur under that same Conversation custody;
- the merged semantic writer's public Keep path is unchanged; one internal leased entry point was
  added for this composition.

A001-A004 remain immutable history in TEMP RELAY PR #278.

Exact Product candidate
-----------------------
base 428bb31c8609474ecd6528a044ee47a9a9e89628
head 573c9589e310b4d46d6a9cd6d9ce4e3c48c569ab
tree 3e69e83f069be788abbc021ee702d2b18da80aa0
branch VXG-111726-memory-correction-review-keep-a001
PR #276

Exact six-path proof membrane
-----------------------------
- docs/work/memory-correction-review-keep/README.md
- src/commonMain/kotlin/vexlife/memory/VexLifeMemoryReviewFamily.kt
- src/commonTest/kotlin/vexlife/memory/VexLifeMemoryReviewFamilyTest.kt
- src/jvmMain/kotlin/vexlife/memory/VexLifeMemoryReviewOwner.kt
- src/jvmMain/kotlin/vexlife/memory/VexLifeSemanticAcceptanceWriter.kt
- src/jvmTest/kotlin/vexlife/memory/VexLifeMemoryReviewOwnerTest.kt

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact six-path SourceOwner review

No prompt/provider/service/web/Home/model/publication/merge effect is authorized.

Return
------
Upload the Finder-revealed ZIP beginning:

RETURN-VEXLIFE-MEMORY-REVIEW-KEEP-SOURCEOWNER-A005--sha256-

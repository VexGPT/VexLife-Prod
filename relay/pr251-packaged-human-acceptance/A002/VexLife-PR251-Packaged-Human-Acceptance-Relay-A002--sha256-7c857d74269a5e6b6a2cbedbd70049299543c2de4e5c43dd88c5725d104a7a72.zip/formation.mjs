import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const sdkRoot = process.argv[2];
const outputDirectory = process.argv[3];

if (!sdkRoot || !outputDirectory) throw new Error('usage: formation.mjs <sdk-root> <output-directory>');

const require = createRequire(import.meta.url);
const { createCanonicalTaskZip } = require(path.join(sdkRoot, 'lib/vexlocalbridge/package-builder.js'));
const sha256 = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');

const contentRoot = fs.mkdtempSync(path.join(outputDirectory, '.pr251-dmg-task-content-'));
try {
  fs.mkdirSync(path.join(contentRoot, 'payload'), { recursive: true });
  fs.mkdirSync(path.join(contentRoot, 'inputs'), { recursive: true });

  const payloadBytes = fs.readFileSync(path.join(here, 'payload.sh'));
  const checklistBytes = fs.readFileSync(path.join(here, 'human-test-checklist.txt'));

  const authority = {
    authoritySchemaRef: 'authority.vexlife-prod.packaged-human-acceptance/v1',
    semanticAdmissionRef: 'admission.vexlife-prod.pr251.packaged-human-acceptance.a002',
    transactionRef: 'transaction.vexlife-prod.pr251.packaged-human-acceptance.a002',
    transactionVersion: 1,
    allowedEffectRefs: [
      'effect.github.read.vexlife-prod',
      'effect.local.build.vexlife-prod-macos-dmg',
      'effect.local.verify.vexlife-prod-macos-dmg',
      'effect.local.write.downloads.human-test-artifact'
    ],
    heldEffectRefs: [
      'effect.github.write',
      'effect.vexlife-prod.source-mutation',
      'effect.vexlife-prod.home-mutation',
      'effect.vexlife-prod.model-runtime',
      'effect.vexlife-prod.installation',
      'effect.vexlife-prod.publication',
      'effect.vexlife-prod.ready',
      'effect.vexlife-prod.merge',
      'effect.vexlife-prod.feature-acceptance-inference'
    ]
  };

  const authorityBytes = Buffer.from(JSON.stringify(authority, null, 2) + '\n');
  fs.writeFileSync(path.join(contentRoot, 'authority.json'), authorityBytes);
  fs.writeFileSync(path.join(contentRoot, 'payload/run.sh'), payloadBytes);
  fs.writeFileSync(path.join(contentRoot, 'inputs/human-test-checklist.txt'), checklistBytes);

  const taskTemplate = {
    schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
    artifactClass: 'EXECUTABLE_RELAY',
    taskRef: 'task.vexlife-prod.pr251.packaged-human-acceptance-dmg.a002',
    attemptRef: 'attempt.vexlife-prod.pr251.packaged-human-acceptance-dmg.a002',
    packageRef: 'package.vexlife-prod.pr251.packaged-human-acceptance-dmg.a002',
    requestRef: 'request.vexlife-prod.pr251.packaged-human-acceptance-dmg.a002',
    correlationRef: 'correlation.vexlife-prod.pr251.packaged-human-acceptance-dmg.a002',
    taskStorageKey: 'vexlife-pr251-packaged-human-acceptance-a002',
    attemptStorageKey: 'attempt-001',
    requestingRoleRef: 'Coder[PACKAGED-HUMAN-ACCEPTANCE]',
    requestingInstanceRef: 'instance.local-vex-operations.pr251-test-forward.a002',
    parentOperationsRef: 'github.pr.VexGPT.VexLife-Prod.364',
    returnRouteRef: 'return.github.pr.VexGPT.VexLife-Prod.364.packaged-human-acceptance.a002',
    hostProfileRef: 'macos-victor',
    repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
    repositoryRefOrNull: 'VexGPT/VexLife-Prod',
    baseRefOrNull: null,
    headRefOrNull: 'a58777106b08bd58c167608fa0115729185ae3dd',
    treeRefOrNull: '3baf658da68adfdd03eca19fc1877f656ec0a56e',
    branchRefOrNull: 'main',
    claimRefOrNull: 'github.pr.VexGPT/VexLife-Prod.364',
    exactPathRefs: ['payload/run.sh','inputs/human-test-checklist.txt'],
    authorityBinding: {
      ...authority,
      authorityEnvelopePath: 'authority.json',
      authorityEnvelopeSha256: sha256(authorityBytes)
    },
    payload: {
      payloadClass: 'VEXLIFE_PROD_PACKAGED_HUMAN_ACCEPTANCE_DMG',
      payloadRuntime: 'bash',
      payloadPath: 'payload/run.sh',
      payloadSha256: sha256(payloadBytes),
      typedArgv: [],
      immutableInputs: [{
        path: 'inputs/human-test-checklist.txt',
        sha256: sha256(checklistBytes)
      }]
    },
    executionStateAtFormation: 'TASK_PREPARED',
    singleUseNonce: 'nonce-pr251-packaged-human-acceptance-a002-20261118',
    stopConditions: [
      'stop.on.source.identity.mismatch',
      'stop.on.build.failure',
      'stop.on.artifact.verification.failure',
      'stop.before.installation',
      'stop.before.publication',
      'stop.before.feature.acceptance.inference'
    ],
    archiveDigestBinding: 'FILENAME_SHA256'
  };

  const formed = createCanonicalTaskZip({
    taskTemplate,
    contentRoot,
    outputDirectory,
    outputStem: 'VexLife-PR251-Packaged-Human-Acceptance-DMG-A002',
    ttlMs: 2 * 60 * 60 * 1000
  });

  process.stdout.write(JSON.stringify({
    finalZip: formed.finalZip,
    digest: formed.digest,
    taskRef: formed.task.taskRef,
    attemptRef: formed.task.attemptRef,
    formedAt: formed.task.formedAt,
    expiresAt: formed.task.expiresAt
  }));
} finally {
  fs.rmSync(contentRoot, { recursive: true, force: true });
}

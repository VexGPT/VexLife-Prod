#!/bin/bash
set -Eeuo pipefail

SDK_REPO='vgong24/Vextreme-SDK'
SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_TREE='6376f68279f0750ee6d3868b8472368199763064'
CONTRACT_BLOB='b53cbac01c2deeb45fad5c32ce98e0796c04126f'
CONTRACT_REF='source.vexrelay.current-contract/v1'
PRODUCT_HEAD='a58777106b08bd58c167608fa0115729185ae3dd'
PRODUCT_TREE='3baf658da68adfdd03eca19fc1877f656ec0a56e'
PR_NUMBER='364'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
DOWNLOADS="$HOME/Downloads"
BOOTSTRAP="$(/usr/bin/mktemp -d "$DOWNLOADS/.pr251-dmg-relay-a002.XXXXXX")"
SDK_ROOT="$BOOTSTRAP/Vextreme-SDK"

cleanup() {
  case "$BOOTSTRAP" in
    "$DOWNLOADS"/.pr251-dmg-relay-a002.*) /bin/rm -rf -- "$BOOTSTRAP" ;;
  esac
}
trap cleanup EXIT HUP INT TERM

fail() {
  echo "FAIL:$1" >&2
  exit "${2:-1}"
}

[ "$(/usr/bin/uname -s)" = 'Darwin' ] || fail 'MACOS_REQUIRED' 11
case "$(/usr/bin/uname -m)" in arm64|aarch64) ;; *) fail 'APPLE_SILICON_REQUIRED' 12 ;; esac
command -v gh >/dev/null 2>&1 || fail 'GITHUB_CLI_REQUIRED' 13
command -v git >/dev/null 2>&1 || fail 'GIT_REQUIRED' 14
command -v node >/dev/null 2>&1 || fail 'NODE_REQUIRED' 15
gh auth status -h github.com >/dev/null 2>&1 || fail 'GITHUB_LOGIN_REQUIRED' 16

echo 'Acquire exact current Vex Relay / VexLocalBridge source...'
gh repo clone "$SDK_REPO" "$SDK_ROOT" -- --filter=blob:none --no-checkout --origin origin
git -C "$SDK_ROOT" fetch --no-tags origin main
OBSERVED_SDK_MAIN="$(git -C "$SDK_ROOT" rev-parse refs/remotes/origin/main)"
[ "$OBSERVED_SDK_MAIN" = "$SDK_HEAD" ] || fail "SDK_MAIN_MOVED:$OBSERVED_SDK_MAIN" 19
git -C "$SDK_ROOT" checkout --detach "$SDK_HEAD"
OBSERVED_SDK_HEAD="$(git -C "$SDK_ROOT" rev-parse HEAD)"
OBSERVED_SDK_TREE="$(git -C "$SDK_ROOT" rev-parse 'HEAD^{tree}')"
[ "$OBSERVED_SDK_HEAD" = "$SDK_HEAD" ] || fail "SDK_HEAD_MISMATCH:$OBSERVED_SDK_HEAD" 20
[ "$OBSERVED_SDK_TREE" = "$SDK_TREE" ] || fail "SDK_TREE_MISMATCH:$OBSERVED_SDK_TREE" 21
[ -z "$(git -C "$SDK_ROOT" status --porcelain=v1 --untracked-files=all)" ] || fail 'SDK_SOURCE_NOT_CLEAN' 22

CONTRACT="$SDK_ROOT/docs/private-continuity/vexrelay/current-contract.json"
[ "$(git -C "$SDK_ROOT" hash-object "$CONTRACT")" = "$CONTRACT_BLOB" ] || fail 'RELAY_CONTRACT_BLOB_MISMATCH' 23
OBSERVED_CONTRACT_REF="$(node -e 'const fs=require("fs"); const v=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.stdout.write(v.contractRef||"")' "$CONTRACT")"
[ "$OBSERVED_CONTRACT_REF" = "$CONTRACT_REF" ] || fail "RELAY_CONTRACT_REF_MISMATCH:$OBSERVED_CONTRACT_REF" 24

echo 'Form source-managed digest-bound VexLocalBridge task...'
FORM_JSON="$(node "$SCRIPT_DIR/formation.mjs" "$SDK_ROOT" "$DOWNLOADS")"
TASK_ZIP="$(node -e 'const v=JSON.parse(process.argv[1]); process.stdout.write(v.finalZip)' "$FORM_JSON")"
TASK_SHA="$(node -e 'const v=JSON.parse(process.argv[1]); process.stdout.write(v.digest)' "$FORM_JSON")"
[ -f "$TASK_ZIP" ] || fail 'FORMED_TASK_MISSING' 30
OBSERVED_TASK_SHA="$(/usr/bin/shasum -a 256 "$TASK_ZIP" | /usr/bin/awk '{print $1}')"
[ "$OBSERVED_TASK_SHA" = "$TASK_SHA" ] || fail "FORMED_TASK_SHA_MISMATCH:$OBSERVED_TASK_SHA:$TASK_SHA" 31

echo
echo 'Execute admitted exact-current-main DMG task...'
set +e
VEX_EXPECTED_PACKAGE_SHA256="$TASK_SHA" /bin/bash "$SDK_ROOT/lib/vexlocalbridge/templates/RUN-VEX-TASK.command" "$TASK_ZIP"
STATUS=$?
set -e

CAPSULE="$DOWNLOADS/VLB-${TASK_SHA:0:16}"
[ -d "$CAPSULE" ] || fail "CAPSULE_MISSING:$CAPSULE" 40
RETURN_SOURCE="$(/usr/bin/find "$CAPSULE/results" -type f -name 'RETURN-*--sha256-*.zip' 2>/dev/null | /usr/bin/sort | /usr/bin/tail -n 1)"
[ -n "$RETURN_SOURCE" ] && [ -f "$RETURN_SOURCE" ] || fail 'CANONICAL_RETURN_NOT_FOUND' 41
RETURN_NAME="$(/usr/bin/basename "$RETURN_SOURCE")"
RETURN_ROOT="$DOWNLOADS/$RETURN_NAME"

if [ -e "$RETURN_ROOT" ]; then
  SRC_SHA="$(/usr/bin/shasum -a 256 "$RETURN_SOURCE" | /usr/bin/awk '{print $1}')"
  DST_SHA="$(/usr/bin/shasum -a 256 "$RETURN_ROOT" | /usr/bin/awk '{print $1}')"
  [ "$SRC_SHA" = "$DST_SHA" ] || fail "RETURN_ROOT_COLLISION:$RETURN_ROOT" 42
else
  /bin/cp -p "$RETURN_SOURCE" "$RETURN_ROOT"
fi

RETURN_SHA="$(/usr/bin/shasum -a 256 "$RETURN_ROOT" | /usr/bin/awk '{print $1}')"
case "$RETURN_NAME" in
  *--sha256-"$RETURN_SHA".zip) ;;
  *) fail "RETURN_FILENAME_DIGEST_MISMATCH:$RETURN_NAME:$RETURN_SHA" 43 ;;
esac

ARTIFACT_DIR="$DOWNLOADS/VexLife-PR251-Packaged-Acceptance-${PRODUCT_HEAD:0:12}-A002"
DMG="$ARTIFACT_DIR/VexLife-macOS-AppleSilicon.dmg"

echo
echo '============================================================'
echo "TASK_EXIT=$STATUS"
echo "PRODUCT_SOURCE=$PRODUCT_HEAD"
echo "PRODUCT_TREE=$PRODUCT_TREE"
echo "PURPOSE_PR=https://github.com/VexGPT/VexLife-Prod/pull/$PR_NUMBER"
echo "CANONICAL_RETURN=$RETURN_ROOT"
echo "CANONICAL_RETURN_SHA256=$RETURN_SHA"
if [ -f "$DMG" ]; then
  echo "DMG_TO_TEST=$DMG"
  echo "DMG_SHA256=$(/usr/bin/shasum -a 256 "$DMG" | /usr/bin/awk '{print $1}')"
else
  echo "DMG_TO_TEST=NOT_FORMED"
fi
echo 'FEATURE_ACCEPTANCE=PENDING_VICTOR_INSTALLED_APP_TEST'
echo '============================================================'

exit "$STATUS"

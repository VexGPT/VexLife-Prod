#!/bin/bash
set -Eeuo pipefail

PRODUCT_REPO='VexGPT/VexLife-Prod'
EXPECTED_HEAD='a58777106b08bd58c167608fa0115729185ae3dd'
EXPECTED_TREE='3baf658da68adfdd03eca19fc1877f656ec0a56e'
EXPECTED_BRANCH='main'
PR_REF='github.pr.VexGPT.VexLife-Prod.364'
RESULT_DIR="${VEXLOCALBRIDGE_RESULT_DIR:?VEXLOCALBRIDGE_RESULT_DIR missing}"
CAPSULE_ROOT="${VEXLOCALBRIDGE_CAPSULE_ROOT:?VEXLOCALBRIDGE_CAPSULE_ROOT missing}"
WORK="$PWD/work"
REPO_ROOT="$WORK/VexLife-Prod"
ARTIFACT_DIR="$HOME/Downloads/VexLife-PR251-Packaged-Acceptance-${EXPECTED_HEAD:0:12}-A001"
SUCCESS=0
STOP_REASON='PAYLOAD_FAILED'
FAIL_STAGE='START'
DMG_SHA=''
DMG_BYTES=0
OBSERVED_MAIN=''
OBSERVED_TREE=''
RECEIPT_SOURCE=''

mkdir -p "$RESULT_DIR"

json_escape() {
  /usr/bin/printf '%s' "$1" | /usr/bin/sed 's/\\/\\\\/g; s/"/\\"/g'
}

write_result() {
  local rc="${1:-1}"
  local disposition='SAFE_FAILURE'
  local stop_json='"PAYLOAD_FAILED"'
  local candidate='[]'
  local harness='[]'
  local environment='[]'
  if [ "$SUCCESS" = '1' ] && [ "$rc" -eq 0 ]; then
    disposition='PASS'
    stop_json='null'
  else
    case "$FAIL_STAGE" in
      SOURCE_BIND) candidate='["SOURCE_IDENTITY_NOT_PROVEN"]' ;;
      BUILD|VERIFY|COPY) harness='["DMG_ARTIFACT_PROOF_NOT_COMPLETE"]' ;;
      *) environment='["DMG_TASK_DID_NOT_COMPLETE"]' ;;
    esac
  fi
  local tmp="$RESULT_DIR/payload-result.json.tmp"
  cat > "$tmp" <<EOF
{
  "schemaVersion": "vextreme.vexlocalbridge-mac-payload-result/v1",
  "disposition": "$disposition",
  "stopReasonOrNull": $stop_json,
  "firstSubstantiveFailureOrNull": null,
  "acceptedExitCodes": [0],
  "candidateFindings": $candidate,
  "harnessFindings": $harness,
  "environmentFindings": $environment,
  "unknownFindings": [],
  "effects": {
    "sourceMutationPerformed": false,
    "branchMutationPerformed": false,
    "claimMutationPerformed": false,
    "prMetadataMutationPerformed": false,
    "reviewPerformed": false,
    "approvalPerformed": false,
    "readyTransitionPerformed": false,
    "mergePerformed": false,
    "mainMutationPerformed": false,
    "checkpointMutationPerformed": false,
    "forcePushPerformed": false,
    "historyRewritePerformed": false,
    "hostInstallationPerformed": false,
    "modelRuntimePerformed": false,
    "providerOrNetworkEffectPerformed": true,
    "publicationPerformed": false,
    "credentialSerializationPerformed": false,
    "filesystemOutsideQualifiedRootsPerformed": false
  },
  "beforeState": {
    "productRepository": "$PRODUCT_REPO",
    "expectedHead": "$EXPECTED_HEAD",
    "expectedTree": "$EXPECTED_TREE",
    "expectedBranch": "$EXPECTED_BRANCH",
    "purposePr": "$PR_REF",
    "featureAcceptance": "PENDING_PACKAGED_HUMAN_TEST"
  },
  "afterState": {
    "observedOriginMain": "$OBSERVED_MAIN",
    "observedTree": "$OBSERVED_TREE",
    "receiptSourceSha": "$RECEIPT_SOURCE",
    "dmgSha256": "$DMG_SHA",
    "dmgBytes": $DMG_BYTES,
    "artifactDirectory": "$ARTIFACT_DIR",
    "featureAcceptance": "PENDING_PACKAGED_HUMAN_TEST",
    "artifactBuildAcceptance": "$disposition"
  },
  "completedStepReceipts": [
    { "step": "source-bind", "state": "$([ -n "$OBSERVED_TREE" ] && echo PASS || echo NOT_COMPLETE)" },
    { "step": "dmg-build", "state": "$([ -n "$DMG_SHA" ] && echo PASS || echo NOT_COMPLETE)" },
    { "step": "human-feature-acceptance", "state": "PENDING_VICTOR_INSTALLED_APP_TEST" }
  ]
}
EOF
  /bin/mv -f "$tmp" "$RESULT_DIR/payload-result.json"
}

on_exit() {
  rc=$?
  trap - EXIT
  set +e
  write_result "$rc"
  exit "$rc"
}
trap on_exit EXIT

fail() {
  STOP_REASON="$1"
  echo "FAIL:$1" >&2
  return 1
}

echo '============================================================'
echo 'VexLife #251 packaged human acceptance DMG formation'
echo "Product source: $EXPECTED_HEAD"
echo 'ARTIFACT BUILD PASS DOES NOT ACCEPT THE FEATURE.'
echo 'Victor installed-app test remains required.'
echo '============================================================'

[ "$(uname -s)" = 'Darwin' ] || { FAIL_STAGE='HOST'; fail 'MACOS_REQUIRED'; }
case "$(uname -m)" in arm64|aarch64) ;; *) FAIL_STAGE='HOST'; fail "APPLE_SILICON_REQUIRED:$(uname -m)" ;; esac
command -v gh >/dev/null 2>&1 || { FAIL_STAGE='HOST'; fail 'GITHUB_CLI_REQUIRED'; }
command -v git >/dev/null 2>&1 || { FAIL_STAGE='HOST'; fail 'GIT_REQUIRED'; }
gh auth status -h github.com >/dev/null 2>&1 || { FAIL_STAGE='HOST'; fail 'GITHUB_LOGIN_REQUIRED'; }

[ ! -e "$ARTIFACT_DIR" ] || { FAIL_STAGE='COPY'; fail "ARTIFACT_DIR_ALREADY_EXISTS:$ARTIFACT_DIR"; }
mkdir -p "$WORK"

FAIL_STAGE='SOURCE_BIND'
gh repo clone "$PRODUCT_REPO" "$REPO_ROOT" -- --filter=blob:none --no-checkout --origin origin
git -C "$REPO_ROOT" fetch --no-tags origin main
OBSERVED_MAIN="$(git -C "$REPO_ROOT" rev-parse refs/remotes/origin/main)"
[ "$OBSERVED_MAIN" = "$EXPECTED_HEAD" ] || fail "REMOTE_MAIN_MOVED:$OBSERVED_MAIN"
git -C "$REPO_ROOT" checkout --detach "$EXPECTED_HEAD"
OBSERVED_HEAD="$(git -C "$REPO_ROOT" rev-parse HEAD)"
OBSERVED_TREE="$(git -C "$REPO_ROOT" rev-parse 'HEAD^{tree}')"
[ "$OBSERVED_HEAD" = "$EXPECTED_HEAD" ] || fail "HEAD_MISMATCH:$OBSERVED_HEAD"
[ "$OBSERVED_TREE" = "$EXPECTED_TREE" ] || fail "TREE_MISMATCH:$OBSERVED_TREE"
[ -z "$(git -C "$REPO_ROOT" status --porcelain=v1 --untracked-files=all)" ] || fail 'SOURCE_NOT_CLEAN'

FAIL_STAGE='BUILD'
cd "$REPO_ROOT"
export GRADLE_OPTS='-Dorg.gradle.jvmargs=-Xmx4096m -XX:MaxMetaspaceSize=1024m -Dorg.gradle.workers.max=1 -Dkotlin.compiler.execution.strategy=in-process'
export KOTLIN_DAEMON_JVMARGS='-Xmx4096m'
./gradlew --no-daemon --max-workers=1 -PvexlifeAppVersion=0.0.0 archiveVexLifeProdMacApplication

APP_DIR="$REPO_ROOT/build/vexlife-prod-mac-application/$EXPECTED_HEAD"
APP="$APP_DIR/VexLife.app"
DMG="$APP_DIR/VexLife-macOS-AppleSilicon.dmg"
DMG_SHA_FILE="$APP_DIR/VexLife-macOS-AppleSilicon.dmg.sha256"
RECEIPT="$APP_DIR/VexLife-macOS-AppleSilicon.receipt.json"

FAIL_STAGE='VERIFY'
[ -d "$APP" ] || fail 'MAC_APP_MISSING'
[ -f "$DMG" ] || fail 'MAC_DMG_MISSING'
[ -f "$DMG_SHA_FILE" ] || fail 'MAC_DMG_SHA_MISSING'
[ -f "$RECEIPT" ] || fail 'MAC_RECEIPT_MISSING'

/usr/bin/codesign --verify --strict "$APP"
(
  cd "$APP_DIR"
  /usr/bin/shasum -a 256 -c VexLife-macOS-AppleSilicon.dmg.sha256
)
/usr/bin/hdiutil verify "$DMG"
RECEIPT_SOURCE="$(/usr/bin/plutil -extract sourceSha raw -o - "$RECEIPT" 2>/dev/null || true)"
[ "$RECEIPT_SOURCE" = "$EXPECTED_HEAD" ] || fail "MAC_RECEIPT_SOURCE_MISMATCH:${RECEIPT_SOURCE:-NONE}"

DMG_SHA="$(/usr/bin/shasum -a 256 "$DMG" | /usr/bin/awk '{print $1}')"
DMG_BYTES="$(/usr/bin/stat -f '%z' "$DMG")"
EXPECTED_DMG_SHA="$(/usr/bin/awk '{print $1}' "$DMG_SHA_FILE")"
[ "$DMG_SHA" = "$EXPECTED_DMG_SHA" ] || fail "DMG_SHA_MISMATCH:$DMG_SHA:$EXPECTED_DMG_SHA"

MOUNT="$WORK/dmg-mount"
mkdir -p "$MOUNT"
/usr/bin/hdiutil attach "$DMG" -readonly -nobrowse -mountpoint "$MOUNT" >/dev/null
trap '/usr/bin/hdiutil detach "'"$MOUNT"'" >/dev/null 2>&1 || true' RETURN
/usr/bin/plutil -extract CFBundleIconFile raw -o - "$MOUNT/VexLife.app/Contents/Info.plist" | /usr/bin/grep -Fx 'applet' >/dev/null
test -s "$MOUNT/VexLife.app/Contents/Resources/applet.icns"
test ! -e "$MOUNT/VexLife.app/Contents/Resources/Assets.car"
/usr/bin/hdiutil detach "$MOUNT" >/dev/null
trap - RETURN

FAIL_STAGE='COPY'
mkdir "$ARTIFACT_DIR"
/bin/cp -p "$DMG" "$ARTIFACT_DIR/VexLife-macOS-AppleSilicon.dmg"
/bin/cp -p "$DMG_SHA_FILE" "$ARTIFACT_DIR/VexLife-macOS-AppleSilicon.dmg.sha256"
/bin/cp -p "$RECEIPT" "$ARTIFACT_DIR/VexLife-macOS-AppleSilicon.receipt.json"
/bin/cp -p "$PWD/../../../../inputs/human-test-checklist.txt" "$ARTIFACT_DIR/WHAT-TO-TEST.txt" 2>/dev/null || true
cat > "$ARTIFACT_DIR/SOURCE.txt" <<EOF
repository=$PRODUCT_REPO
sourceSha=$EXPECTED_HEAD
sourceTree=$EXPECTED_TREE
purposePr=$PR_REF
dmgSha256=$DMG_SHA
dmgBytes=$DMG_BYTES
featureAcceptance=PENDING_PACKAGED_HUMAN_TEST
EOF

# Re-verify the delivered copy, not just the build output.
DELIVERED_DMG="$ARTIFACT_DIR/VexLife-macOS-AppleSilicon.dmg"
DELIVERED_SHA="$(/usr/bin/shasum -a 256 "$DELIVERED_DMG" | /usr/bin/awk '{print $1}')"
[ "$DELIVERED_SHA" = "$DMG_SHA" ] || fail "DELIVERED_DMG_SHA_MISMATCH:$DELIVERED_SHA:$DMG_SHA"

SUCCESS=1
STOP_REASON=''
echo
echo 'DMG_ARTIFACT_PROOF=PASS'
echo "DMG_TO_TEST=$DELIVERED_DMG"
echo "DMG_SHA256=$DMG_SHA"
echo "DMG_BYTES=$DMG_BYTES"
echo 'FEATURE_ACCEPTANCE=PENDING_VICTOR_INSTALLED_APP_TEST'
echo '============================================================'

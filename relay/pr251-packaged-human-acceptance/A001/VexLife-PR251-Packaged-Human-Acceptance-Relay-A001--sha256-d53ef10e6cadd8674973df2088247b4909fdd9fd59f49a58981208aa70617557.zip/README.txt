[VXG RealForever]

PR #364 packaged human acceptance A001

This doorway uses current Vex Relay / VexLocalBridge source:
SDK head 8543c7d755faba04d4c4019c02e84f992667918a
SDK tree 6376f68279f0750ee6d3868b8472368199763064
contract source.vexrelay.current-contract/v1

It forms and executes a source-managed digest-bound VexLocalBridge task on Victor's Mac.

The task builds exact VexLife-Prod current main:
head a58777106b08bd58c167608fa0115729185ae3dd
tree 3baf658da68adfdd03eca19fc1877f656ec0a56e

On artifact PASS it leaves:
~/Downloads/VexLife-PR251-Packaged-Acceptance-a58777106b08-A001/
  VexLife-macOS-AppleSilicon.dmg
  VexLife-macOS-AppleSilicon.dmg.sha256
  VexLife-macOS-AppleSilicon.receipt.json
  SOURCE.txt
  WHAT-TO-TEST.txt

It also copies the exact canonical RETURN ZIP to ~/Downloads root.

IMPORTANT:
DMG artifact build PASS does NOT accept the feature.
Feature acceptance remains PENDING until Victor installs/opens the exact DMG and tests the real Product.
No install, publication, merge, READY, source mutation, Home mutation or model-runtime effect is authorized.

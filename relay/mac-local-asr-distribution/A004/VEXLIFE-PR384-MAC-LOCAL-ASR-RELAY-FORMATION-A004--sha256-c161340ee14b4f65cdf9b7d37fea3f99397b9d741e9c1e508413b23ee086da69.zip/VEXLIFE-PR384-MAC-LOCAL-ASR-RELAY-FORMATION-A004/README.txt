# PR #384 Mac Local-ASR SourceOwner A004

[VXG RealForever]

A003 proved the 2 GB / one-worker proof-resource correction: Kotlin JVM production and test
compilation completed and all 834 JVM tests ran. Exactly one test failed:

`VexLifeProdPrivateServiceImageTest.localQualifiedVisionRuntimeIsExplicitlyObserved`

The failure occurred at `VexLifeProdPrivateServiceImage.observe()` with
`IllegalArgumentException`, not from heap exhaustion.

Root cause is owned by PR #384. When #384 split service-image schema identity into:

- v3 `LegacySchema`
- v4 `VisionSchema`
- v5 current `Schema` with bundled Local-ASR provider

the later schema/runtime relationship validator correctly accepted v4, but the earlier manifest
identity gate still allowed only v3 + v5. A legitimate v4 Vision image was therefore rejected
before its v4 descriptor validation.

#384 has the smallest correction: include `VisionSchema` in that first allowed schema set.

Corrected Product candidate:

```text
base b8bda514fae5e3ec0c0e0718dd48766e39cd6b45
head cb47d5c92db709048ac668cfa3c0eadd34b02152
tree c500a68873499ec754ea50a43d85f427debccb99
```

A004 preserves the same SourceOwner task, rotates attempt/request/correlation/package identity, and
re-runs the same source/package threshold with the already-proven 2 GB / one-worker proof envelope.

No Product launch, real Vex Home mutation, microphone, approval, READY, merge, or release publication
is authorized.

Current VexRelay/VexLocalBridge checkout-free Mac carriage is retained. Local Workspace is not used.

<!-- [VXG RealForever][PR384][PR386][A004][V4-VISION-SCHEMA-CORRECTION][DO-NOT-MERGE] -->

# A005 — complete remaining SourceOwner checks after A004 host-path defect

[VXG RealForever]

A004 canonical outer RETURN:
```text
sha256 c50fb14976b7653f73fbee9214c518e697a7a2107a006d364a1c4d99f699fdc4
outer disposition PASS
```

A004 retained canonical inner RETURN:
```text
sha256 b231bcd99a0333cbc8027523a5e73be1a153667793f41539ae1eef5b755371ce
inner disposition SAFE_FAILURE
```

A004 materially passed on the exact corrected #384 candidate:
- exact head/tree checks;
- JVM + Kotlin/JS + strings proof;
- Mac app/DMG formation;
- independent `hdiutil verify`.

It then stopped before provider identity checks because the proof manifest named
`/usr/bin/test`, which is not an executable on this Mac. The accepted executable is
`/bin/test`.

A005 preserves all valid A004 evidence and does not rerun the JVM/JS/string gate.
It rebuilds the Mac application in its fresh attempt workspace so the exact service-image
artifacts exist, then executes only the remaining provider checks:
- `/bin/test -x` on bundled `whisper-server`;
- exact whisper.cpp source commit;
- exact whisper.cpp source tree;
- private-service-image-root launcher binding;
- packaged `whisper-server --help` with packaged dylibs;
- SourceOwner review snapshot / canonical RETURN.

Product source is unchanged:

```text
#384 head cb47d5c92db709048ac668cfa3c0eadd34b02152
tree      c500a68873499ec754ea50a43d85f427debccb99
```

Local Workspace is not used. Product launch, real Home mutation, microphone, approval,
READY, merge and release publication remain held.

<!-- [VXG RealForever][PR384][PR386][A005][REUSE-A004-EVIDENCE][DO-NOT-MERGE] -->

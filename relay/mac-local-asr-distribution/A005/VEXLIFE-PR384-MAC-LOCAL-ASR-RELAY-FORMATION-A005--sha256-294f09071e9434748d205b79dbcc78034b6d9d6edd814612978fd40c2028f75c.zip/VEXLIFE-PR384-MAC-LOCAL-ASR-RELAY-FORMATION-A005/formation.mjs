import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const sdkRoot = path.resolve(process.argv[2] || '');
const outputDirectory = path.resolve(process.argv[3] || '');
if (!sdkRoot || !outputDirectory) throw new Error('PR384_A005_ARGUMENTS_REQUIRED');

const SDK_HEAD = "8543c7d755faba04d4c4019c02e84f992667918a";
const SDK_TREE = "6376f68279f0750ee6d3868b8472368199763064";
const BASE = "b8bda514fae5e3ec0c0e0718dd48766e39cd6b45";
const HEAD = "cb47d5c92db709048ac668cfa3c0eadd34b02152";
const TREE = "c500a68873499ec754ea50a43d85f427debccb99";
const BRANCH = "VXG-111926-chatgpt-mac-local-asr-provider-distribution-a001";
const changedPaths = [
  ".github/workflows/mac-app-proof.yml",
  "build.gradle.kts",
  "packaging/private-service-image/bin/vexlife-prod-service",
  "packaging/private-service-image/local-asr-provider-contract.json",
  "src/jvmMain/kotlin/vexlife/localasr/VexLifeLocalAsrMacArm64ProviderRealization.kt",
  "src/jvmMain/kotlin/vexlife/packaging/VexLifeProdPrivateServiceImage.kt",
  "src/jvmTest/kotlin/vexlife/localasr/VexLifeLocalAsrProviderTest.kt",
  "src/jvmTest/kotlin/vexlife/packaging/VexLifeProdPrivateServiceImageTest.kt"
];

const producerUrl = pathToFileURL(path.join(
  sdkRoot,
  'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
)).href;
const { formVexRelayTaskArchiveCarrier } = await import(producerUrl);

const require = createRequire(import.meta.url);
const { renderMacSourceBootstrapCommand } = require(
  path.join(sdkRoot, 'lib/vexlocalbridge/mac-source-bootstrap-command.js'),
);

const providerRoot = "build/vexlife-prod-service-image/images/cb47d5c92db709048ac668cfa3c0eadd34b02152/local-asr-provider/whispercpp/v1.9.5";
const providerBin = "build/vexlife-prod-service-image/images/cb47d5c92db709048ac668cfa3c0eadd34b02152/local-asr-provider/whispercpp/v1.9.5/bin";
const providerExe = "build/vexlife-prod-service-image/images/cb47d5c92db709048ac668cfa3c0eadd34b02152/local-asr-provider/whispercpp/v1.9.5/bin/whisper-server";
const dmg = "build/vexlife-prod-mac-application/cb47d5c92db709048ac668cfa3c0eadd34b02152/VexLife-macOS-AppleSilicon.dmg";
const launcher = "build/vexlife-prod-service-image/images/cb47d5c92db709048ac668cfa3c0eadd34b02152/bin/vexlife-prod-service";
const gradleHeap = "-Dorg.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=768m -XX:ReservedCodeCacheSize=512m";

const commonGradleArgs = [
  '--stacktrace',
  '--no-daemon',
  '--max-workers=1',
  gradleHeap,
];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.pr384.mac-local-asr.source-owner',
  attemptRef: 'attempt.vexlife-prod.pr384.mac-local-asr.source-owner.a005.20261119a005',
  requestRef: 'request.vexlife-prod.pr384.mac-local-asr.source-owner.a005.20261119a005',
  correlationRef: 'correlation.vexlife-prod.pr384.mac-local-asr.source-owner.a005.20261119a005',
  packageRef: 'package.vexlife-prod.pr384.mac-local-asr.source-owner.a005.20261119a005',
  original: {
    originalIntent: 'Close the fresh-install Mac Local-ASR provider distribution gap without changing VoiceInput semantics or creating a fake provider-install control.',
    originalGoal: 'Prove the exact PR #384 Mac provider/package candidate on macOS arm64 through the current VexRelay SourceOwner contract.',
    userProtectedIntent: 'Keep Product source authority in PR #384, use one companion proof PR, avoid Local Workspace, preserve Home/model/microphone/lifecycle effects as held, and return one canonical result.',
    sourceRefs: [
      'github.pr.vexlife-prod.384',
      'github.pr.vexlife-prod.386',
      'source.vexrelay.current-contract/v1',
      'return.pr384.a002.outer.6f67f2d5ebd4554f23dc00a05cf8cac5ca9bd8f0d48f43378cc415fa21cd1c9d',
      'return.pr384.a002.inner.d1909b06cd085591a3c3a7c30aa8475a4b00d5e3d836624a607d8ff8dcd5f02a',
      'return.pr384.a003.outer.1373727998c6ec72caab731bba034b09e4960482f1133fa0b517342be7faeb65',
      'return.pr384.a003.inner.d0bd58591254580ed2d0e7a2d4534bf1f033f8dd4c99e5dea723367fb7883399',
      'return.pr384.a004.outer.c50fb14976b7653f73fbee9214c518e697a7a2107a006d364a1c4d99f699fdc4',
      'return.pr384.a004.inner.b231bcd99a0333cbc8027523a5e73be1a153667793f41539ae1eef5b755371ce',
    ],
  },
  lane: {
    entryClass: 'SAME_LANE_SUCCESSOR',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'lane.vexlife-prod.pr384.mac-local-asr-distribution',
    parentRootRef: 'github.pr.vexlife-prod.338',
    workRef: 'work.vexlife-prod.pr384.mac-local-asr-distribution',
    claimRef: 'claim.vexlife-prod.pr384.mac-local-asr-source-owner',
    returnRouteRef: 'github.pr.vexlife-prod.386',
    ownerRef: 'github.pr.vexlife-prod.384',
    rootHubRef: 'github.pr.vexlife-prod.338',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.pr384.a005',
    instanceRef: 'instance.vexlife-prod.pr384.a005',
    occupancyRef: 'occupancy.vexlife-prod.pr384.a005',
    providerBindingRef: 'provider.macos-victor.vexlife-prod.pr384.a005',
    threadRef: 'thread.local-vex-operations.pr384.a005',
    authorityEnvelopeRef: 'authority-envelope.vexlife-prod.pr384.a005',
  },
  capabilities: {
    platformGitHubRead: 'AVAILABLE',
    platformGitHubWrite: 'UNAVAILABLE',
  },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-pr384-mac-local-asr-source-owner-a005-20261119',
    duplicateAttemptMarker: 'marker.vexlife-prod.pr384.source-owner.a005',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: new Date().toISOString(),
    expiresAtOrNull: null,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.pr384.source-owner',
    projectPath: 'workspace',
    createRoot: true,
    createProjectPath: true,
  },
  repositories: [{
    repositoryRef: 'primary',
    mode: 'CLONE_IN_WORKSPACE',
    cloneTransport: 'GIT',
    cloneUrl: 'https://github.com/VexGPT/VexLife-Prod.git',
    nameWithOwner: 'VexGPT/VexLife-Prod',
    localPath: 'repositories/primary',
    remote: 'origin',
    baseBranch: 'main',
    acceptedBase: BASE,
    checkoutRef: HEAD,
    expectedHead: HEAD,
    branch: BRANCH,
  }],
  authority: {
    authorityRef: 'authority.vexlife-prod.pr384.source-owner.a005',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: ['READ_REPOSITORY','CHECK_STATE','RUN_LOCAL_COMMAND','QUERY_PROVIDER','FORM_RESULT'],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: ['READ_REPOSITORY','CHECK_STATE','RUN_LOCAL_COMMAND','QUERY_PROVIDER','FORM_RESULT'],
    heldEffects: [
      'WRITE_SOURCE','PUSH_BRANCH','CREATE_PULL_REQUEST','APPROVE_EXACT_HEAD','MARK_READY',
      'ORDINARY_MERGE','RELEASE_PUBLICATION','REAL_HOME_MUTATION','MICROPHONE',
    ],
    repositoryMembranes: [{
      repositoryRef: 'primary',
      allowedPaths: changedPaths,
    }],
    allowedExecutables: [
      '/bin/bash',
      '/usr/bin/hdiutil',
      '/usr/bin/grep',
      '/bin/test',
      providerExe,
    ],
    allowedEnvironment: ['HOME','PATH','DYLD_LIBRARY_PATH'],
    remoteObservationOwner: 'Operations',
    allowMutationLoop: false,
    stopConditions: ['STOP_ON_UNKNOWN','STOP_ON_PATH_ESCAPE','STOP_ON_AUTH_BLOCK','STOP_ON_TEST_FAILURE'],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.pr384.mac-local-asr',
    sourceVersionRef: `git.${HEAD}`,
    overlapEvidenceRef: 'github.pr.vexlife-prod.384.bounded-eight-path-scope',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: changedPaths.map((p) => ({ repositoryRef: 'primary', path: p })),
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 10,
    maxSelectedSourceBytes: 5000000,
    maxDiffBytes: 10000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: true,
    signoffCommit: false,
    draftPullRequest: true,
  },
};

const stage = {
  repositoryRef: 'primary',
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: BRANCH,
  maxFiles: 8,
  proofCommands: [
    {
      command: '/bin/bash',
      args: ['./gradlew','-PvexlifeAppVersion=0.0.0','archiveVexLifeProdMacApplication', ...commonGradleArgs],
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'proof.pr384.a005.mac-app-dmg-materialization',
      proofClass: 'TEST',
      acceptedExitCodes: [0],
      timeoutMs: 900000,
    },
    {
      command: '/bin/test',
      args: ['-x', providerExe],
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'proof.pr384.a005.provider-executable',
      proofClass: 'TEST',
      acceptedExitCodes: [0],
    },
    {
      command: '/usr/bin/grep',
      args: ['-Fx','d1be6fde11ac6e0407606b4e42fe72d34add8037', `${providerRoot}/provider-source.txt`],
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'proof.pr384.a005.provider-source',
      proofClass: 'TEST',
      acceptedExitCodes: [0],
    },
    {
      command: '/usr/bin/grep',
      args: ['-Fx','6fe2755682242a5c01aba65a22b3c0305d747841', `${providerRoot}/provider-tree.txt`],
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'proof.pr384.a005.provider-tree',
      proofClass: 'TEST',
      acceptedExitCodes: [0],
    },
    {
      command: '/usr/bin/grep',
      args: ['-F','--','-Dvexlife.privateServiceImageRoot="$ROOT"', launcher],
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'proof.pr384.a005.private-image-root',
      proofClass: 'TEST',
      acceptedExitCodes: [0],
    },
    {
      command: providerExe,
      args: ['--help'],
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'proof.pr384.a005.whisper-server-help',
      proofClass: 'TEST',
      acceptedExitCodes: [0],
      env: { DYLD_LIBRARY_PATH: providerBin },
      timeoutMs: 120000,
    },
  ],

  stateRef: 'state.vexlife-prod.pr384.source-owner.a005',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal: 'Complete the remaining PR #384 Mac Local-ASR provider identity/runtime checks after A004 passed JVM/JS/strings, Mac app/DMG formation and hdiutil verification.',
  remainingGoals: [
    'Compose the accepted #372/#382/#384 work into the final #338 candidate.',
    'Run exact final-byte Mac and Windows regressions before lifecycle.',
  ],
  onPass: {
    lifecycleState: 'SOURCE_READY',
    nextFunction: 'F09.COMPOSE_FINAL_CANDIDATE',
    nextOwner: 'Operations',
    whyThisIsNext: 'The exact #384 Mac provider distribution source/package proof is complete; final #338 composition is the next unconsumed release edge.',
  },
  resultFilename: 'RETURN-VEXLIFE-PR384-MAC-LOCAL-ASR-SOURCE-OWNER-A005.zip',
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef: 'github.pr.vexlife-prod.384',
  transactionRef: 'transaction.vexlife-prod.pr384.mac-local-asr.source-owner.a005',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: [
    'effect.product.launch',
    'effect.vexhome.mutate',
    'effect.microphone',
    'effect.approve',
    'effect.ready',
    'effect.merge',
    'effect.release.publish',
  ],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexlife-prod.pr384.mac-local-asr.carrier',
  attemptRef: 'attempt.vexlife-prod.pr384.mac-local-asr.carrier.a005.20261119',
  packageRef: 'package.vexlife-prod.pr384.mac-local-asr.carrier.a005.20261119',
  requestRef: 'request.vexlife-prod.pr384.mac-local-asr.carrier.a005.20261119',
  correlationRef: 'correlation.vexlife-prod.pr384.mac-local-asr.carrier.a005.20261119',
  taskStorageKey: 'task-vexlife-prod-pr384-mac-local-asr-carrier',
  attemptStorageKey: 'attempt-a005',
  requestingRoleRef: 'Operations[PR384]',
  requestingInstanceRef: 'instance.local-vex-operations.pr384.a005',
  parentOperationsRef: 'github.pr.vexlife-prod.384',
  returnRouteRef: 'github.pr.vexlife-prod.386',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: null,
  baseRefOrNull: null,
  headRefOrNull: null,
  treeRefOrNull: null,
  branchRefOrNull: null,
  claimRefOrNull: 'claim.vexlife-prod.pr384.mac-local-asr-source-owner',
  exactPathRefs: [],
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'stale',
    transactionRef: 'stale',
    transactionVersion: 1,
    allowedEffectRefs: ['stale'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: 'VEXRELAY_TASK_ARCHIVE',
    payloadRuntime: 'NATIVE_VEXRELAY',
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [{ path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) }],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexlife-prod-pr384-mac-local-asr-carrier-a005-20261119',
  stopConditions: [
    'stop.on.identity.drift',
    'stop.on.rejected.inner.return',
  ],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const formed = await formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'VEXLIFE-PR384-MAC-LOCAL-ASR-SOURCE-OWNER-A005',
  ttlMs: 6 * 60 * 60 * 1000,
});

if (formed.outer.formationEvidence?.finalByteQualification !== 'PASS') {
  throw new Error('PR384_A005_OUTER_FINAL_BYTE_QUALIFICATION_FAILED');
}

const macCommand = renderMacSourceBootstrapCommand({
  packageSha256: formed.outer.digest,
  sdkHead: SDK_HEAD,
  sdkTree: SDK_TREE,
});

console.log(`PR384_A005_OUTER_PACKAGE=${formed.outer.finalZip}`);
console.log(`PR384_A005_OUTER_SHA256=${formed.outer.digest}`);
console.log('PR384_A005_ENTERING_CURRENT_MAC_VEXLOCALBRIDGE');

const run = spawnSync('/bin/bash', ['-lc', macCommand], {
  stdio: 'inherit',
  env: process.env,
});

if (run.error) throw run.error;
if (run.signal) {
  console.error(`PR384_A005_SIGNAL=${run.signal}`);
  process.exit(128);
}
console.log(`PR384_A005_EXIT=${run.status ?? 1}`);
process.exit(run.status ?? 1);

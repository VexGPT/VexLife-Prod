import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';

const SDK_HEAD = '8543c7d755faba04d4c4019c02e84f992667918a';
const SDK_TREE = '6376f68279f0750ee6d3868b8472368199763064';
const PRODUCT_BASE = 'b8bda514fae5e3ec0c0e0718dd48766e39cd6b45';
const PRODUCT_HEAD = 'caf20c78a797ac0579349915c26c79cfc4b1a39f';
const PRODUCT_TREE = '7e499f4a3ae88ab6ccc906146d3f3ac7bc0509cb';
const PRODUCT_BRANCH = 'VXG-111926-chatgpt-mac-local-asr-provider-distribution-a001';
const PRODUCT_REPOSITORY = 'VexGPT/VexLife-Prod';
const RESULT_FILENAME = 'RETURN-VEXLIFE-PR384-MAC-LOCAL-ASR-SOURCE-OWNER-A002.zip';
const OUTER_STEM = 'VEXLIFE-PR384-MAC-LOCAL-ASR-SOURCE-OWNER-A002';
const TTL_MS = 6 * 60 * 60 * 1000;

const sdkRoot = path.resolve(process.argv[2] ?? '');
const outputDirectory = path.resolve(process.argv[3] ?? '');
if (!sdkRoot || !outputDirectory) throw new Error('PR384_A002_FORMATION_ARGS_REQUIRED');

const formationModule = await import(pathToFileURL(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs')).href);
const require = createRequire(import.meta.url);
const nativeCarrier = require(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js'));
const macBootstrap = require(path.join(sdkRoot, 'lib/vexlocalbridge/mac-source-bootstrap-command.js'));
const { formVexRelayTaskArchiveCarrier } = formationModule;
const { VEXRELAY_ARCHIVE_PAYLOAD_CLASS, VEXRELAY_ARCHIVE_RUNTIME } = nativeCarrier;
const { renderMacSourceBootstrapCommand } = macBootstrap;

const changedPaths = [
  '.github/workflows/mac-app-proof.yml',
  'build.gradle.kts',
  'packaging/private-service-image/bin/vexlife-prod-service',
  'packaging/private-service-image/local-asr-provider-contract.json',
  'src/jvmMain/kotlin/vexlife/localasr/VexLifeLocalAsrMacArm64ProviderRealization.kt',
  'src/jvmMain/kotlin/vexlife/packaging/VexLifeProdPrivateServiceImage.kt',
  'src/jvmTest/kotlin/vexlife/localasr/VexLifeLocalAsrProviderTest.kt',
  'src/jvmTest/kotlin/vexlife/packaging/VexLifeProdPrivateServiceImageTest.kt',
];

const serviceImageRoot = `build/vexlife-prod-service-image/images/${PRODUCT_HEAD}`;
const providerRoot = `${serviceImageRoot}/local-asr-provider/whispercpp/v1.9.5`;
const appRoot = `build/vexlife-prod-mac-application/${PRODUCT_HEAD}`;
const dmgPath = `${appRoot}/VexLife-macOS-AppleSilicon.dmg`;
const providerExecutable = `${providerRoot}/bin/whisper-server`;

const formedAt = new Date().toISOString();
const stable = '20261119a002';

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.pr384.mac-local-asr.source-owner',
  attemptRef: `attempt.vexlife-prod.pr384.mac-local-asr.source-owner.a002.${stable}`,
  requestRef: `request.vexlife-prod.pr384.mac-local-asr.source-owner.a002.${stable}`,
  correlationRef: `correlation.vexlife-prod.pr384.mac-local-asr.source-owner.a002.${stable}`,
  packageRef: `package.vexlife-prod.pr384.mac-local-asr.source-owner.a002.${stable}`,
  original: {
    originalIntent: 'Close the fresh-install Mac Local-ASR provider distribution gap without changing VoiceInput semantics or creating a fake provider-install control.',
    originalGoal: 'Prove the exact PR #384 Mac provider/package candidate on macOS arm64 through the current VexRelay SourceOwner contract.',
    userProtectedIntent: 'Keep Product source authority in PR #384, use one companion proof PR, avoid Local Workspace, preserve Home/model/microphone/lifecycle effects as held, and return one canonical result.',
    sourceRefs: ['github.pr.vexlife-prod.384', 'github.pr.vexlife-prod.386', 'source.vexrelay.current-contract/v1'],
  },
  lane: {
    entryClass: 'SAME_LANE_SUCCESSOR',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'lane.vexlife-prod.pr384.mac-local-asr-distribution',
    parentRootRef: 'github.pr.vexlife-prod.338',
    workRef: 'work.vexlife-prod.pr384.mac-local-asr-distribution',
    claimRef: 'claim.vexlife-prod.pr384.mac-local-asr-source-owner',
    returnRouteRef: 'github.pr.vexlife-prod.386',
    ownerRef: 'github.pr.vexlife-prod.384',
    rootHubRef: 'github.pr.vexlife-prod.338',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.pr384.a002',
    instanceRef: 'instance.vexlife-prod.pr384.a002',
    occupancyRef: 'occupancy.vexlife-prod.pr384.a002',
    providerBindingRef: 'provider.macos-victor.vexlife-prod.pr384.a002',
    threadRef: 'thread.local-vex-operations.pr384.a002',
    authorityEnvelopeRef: 'authority-envelope.vexlife-prod.pr384.a002',
  },
  capabilities: {
    platformGitHubRead: 'AVAILABLE',
    platformGitHubWrite: 'UNAVAILABLE',
  },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-pr384-a002-20261119',
    duplicateAttemptMarker: 'marker.vexlife-prod.pr384.source-owner.a002',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt,
    expiresAtOrNull: null,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.pr384.source-owner',
    projectPath: 'workspace',
    createRoot: true,
    createProjectPath: true,
  },
  repositories: [{
    repositoryRef: 'primary',
    mode: 'CLONE_IN_WORKSPACE',
    cloneTransport: 'GIT',
    cloneUrl: 'https://github.com/VexGPT/VexLife-Prod.git',
    nameWithOwner: PRODUCT_REPOSITORY,
    localPath: 'repositories/primary',
    remote: 'origin',
    baseBranch: 'main',
    acceptedBase: PRODUCT_BASE,
    checkoutRef: PRODUCT_HEAD,
    expectedHead: PRODUCT_HEAD,
    branch: PRODUCT_BRANCH,
  }],
  authority: {
    authorityRef: 'authority.vexlife-prod.pr384.source-owner.a002',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: ['READ_REPOSITORY', 'CHECK_STATE', 'RUN_LOCAL_COMMAND', 'QUERY_PROVIDER', 'FORM_RESULT'],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: ['READ_REPOSITORY', 'CHECK_STATE', 'RUN_LOCAL_COMMAND', 'QUERY_PROVIDER', 'FORM_RESULT'],
    heldEffects: ['WRITE_SOURCE', 'PUSH_BRANCH', 'CREATE_PULL_REQUEST', 'APPROVE_EXACT_HEAD', 'MARK_READY', 'ORDINARY_MERGE', 'RELEASE_PUBLICATION', 'REAL_HOME_MUTATION', 'MICROPHONE'],
    repositoryMembranes: [{
      repositoryRef: 'primary',
      allowedPaths: changedPaths,
    }],
    allowedExecutables: [
      '/bin/bash',
      '/usr/bin/hdiutil',
      '/usr/bin/grep',
      '/usr/bin/test',
      providerExecutable,
    ],
    allowedEnvironment: ['HOME', 'PATH', 'DYLD_LIBRARY_PATH'],
    remoteObservationOwner: 'Operations',
    allowMutationLoop: false,
    stopConditions: ['STOP_ON_UNKNOWN', 'STOP_ON_PATH_ESCAPE', 'STOP_ON_AUTH_BLOCK', 'STOP_ON_TEST_FAILURE'],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.pr384.mac-local-asr',
    sourceVersionRef: `git.${PRODUCT_HEAD}`,
    overlapEvidenceRef: 'github.pr.vexlife-prod.384.bounded-eight-path-scope',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: PRODUCT_HEAD,
    candidateTree: PRODUCT_TREE,
    expectedChangedPaths: changedPaths.map((p) => ({ repositoryRef: 'primary', path: p })),
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 10,
    maxSelectedSourceBytes: 5000000,
    maxDiffBytes: 10000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: true,
    signoffCommit: false,
    draftPullRequest: true,
  },
};

const stage = {
  repositoryRef: 'primary',
  expectedBase: PRODUCT_BASE,
  expectedHead: PRODUCT_HEAD,
  expectedTree: PRODUCT_TREE,
  branch: PRODUCT_BRANCH,
  proofCommands: [
    {
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.pr384.jvm-js-strings',
      command: '/bin/bash',
      args: ['./gradlew', 'jvmTest', 'checkVexLifeStrings', 'compileKotlinJs', 'compileTestKotlinJs', '--stacktrace', '--no-daemon'],
      inheritEnvKeys: ['HOME', 'PATH'],
      timeoutMs: 1800000,
    },
    {
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.pr384.mac-app-dmg-formation',
      command: '/bin/bash',
      args: ['./gradlew', 'archiveVexLifeProdMacApplication', '--stacktrace', '--no-daemon'],
      inheritEnvKeys: ['HOME', 'PATH'],
      timeoutMs: 1800000,
    },
    {
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.pr384.dmg-verify',
      command: '/usr/bin/hdiutil',
      args: ['verify', dmgPath],
      timeoutMs: 300000,
    },
    {
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.pr384.provider-executable',
      command: '/usr/bin/test',
      args: ['-x', providerExecutable],
    },
    {
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.pr384.provider-source-commit',
      command: '/usr/bin/grep',
      args: ['-Fx', 'd1be6fde11ac6e0407606b4e42fe72d34add8037', `${providerRoot}/provider-source.txt`],
    },
    {
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.pr384.provider-source-tree',
      command: '/usr/bin/grep',
      args: ['-Fx', '6fe2755682242a5c01aba65a22b3c0305d747841', `${providerRoot}/provider-tree.txt`],
    },
    {
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.pr384.provider-runnable',
      command: providerExecutable,
      args: ['--help'],
      env: { DYLD_LIBRARY_PATH: `${providerRoot}/bin` },
      timeoutMs: 120000,
    },
    {
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.pr384.private-image-root-handoff',
      command: '/usr/bin/grep',
      args: ['-F', '--', '-Dvexlife.privateServiceImageRoot="$ROOT"', `${serviceImageRoot}/bin/vexlife-prod-service`],
    },
  ],
  maxFiles: 10,
  stateRef: 'state.vexlife-prod.pr384.source-owner.a002',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal: 'Prove the exact PR #384 Mac Local-ASR provider distribution source/package candidate.',
  remainingGoals: ['Compose the accepted #372/#382/#384 work into the final #338 candidate.', 'Run exact final-byte Mac and Windows regressions before lifecycle.'],
  onPass: {
    lifecycleState: 'SOURCE_READY',
    nextFunction: 'F12.FORM_CONTINUATION',
    nextOwner: 'Operations',
    whyThisIsNext: 'PR #384 source/package proof is complete; final composition and same-byte regressions remain separate gates.',
  },
  resultFilename: RESULT_FILENAME,
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef: 'github.pr.vexlife-prod.384',
  transactionRef: 'transaction.vexlife-prod.pr384.mac-local-asr.source-owner.a002',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: ['effect.product.launch', 'effect.vexhome.real-mutation', 'effect.microphone', 'effect.approval', 'effect.ready', 'effect.merge', 'effect.release-publication'],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexlife-prod.pr384.mac-local-asr.carrier',
  attemptRef: 'attempt.vexlife-prod.pr384.mac-local-asr.carrier.a002.20261119',
  packageRef: 'package.vexlife-prod.pr384.mac-local-asr.carrier.a002.20261119',
  requestRef: 'request.vexlife-prod.pr384.mac-local-asr.carrier.a002.20261119',
  correlationRef: 'correlation.vexlife-prod.pr384.mac-local-asr.carrier.a002.20261119',
  taskStorageKey: 'task-vexlife-prod-pr384-mac-local-asr-carrier',
  attemptStorageKey: 'attempt-a002',
  requestingRoleRef: 'Operations[PR384]',
  requestingInstanceRef: 'instance.local-vex-operations.pr384.a002',
  parentOperationsRef: 'github.pr.vexlife-prod.384',
  returnRouteRef: 'github.pr.vexlife-prod.386',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: 'vgong24/Vextreme-SDK',
  baseRefOrNull: SDK_HEAD,
  headRefOrNull: SDK_HEAD,
  treeRefOrNull: SDK_TREE,
  branchRefOrNull: 'main',
  claimRefOrNull: 'claim.vexlife-prod.pr384.relay-carrier',
  exactPathRefs: [],
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'stale',
    transactionRef: 'stale',
    transactionVersion: 1,
    allowedEffectRefs: ['stale'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [{ path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) }],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexlife-prod-pr384-carrier-a002-20261119',
  stopConditions: ['stop.on.identity.drift', 'stop.on.payload.failure', 'stop.on.return.failure'],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const formed = await formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: OUTER_STEM,
  ttlMs: TTL_MS,
});

console.log(`PR384 A002: canonical outer package=${formed.outer.finalZip}`);
console.log(`PR384 A002: canonical outer sha256=${formed.outer.digest}`);
console.log(`PR384 A002: inner task=${formed.inner.manifest.taskRef}`);
console.log(`PR384 A002: inner attempt=${formed.inner.manifest.attemptRef}`);

const macCommand = renderMacSourceBootstrapCommand({
  packageSha256: formed.outer.digest,
  sdkHead: SDK_HEAD,
  sdkTree: SDK_TREE,
});

console.log('PR384 A002: entering the current checkout-free Mac VexLocalBridge carrier...');
const run = spawnSync('/bin/bash', ['-c', macCommand], {
  stdio: 'inherit',
  env: process.env,
});
if (run.error) throw run.error;
if (run.status !== 0) process.exit(run.status ?? 1);

#!/bin/bash
set -euo pipefail

SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_TREE='6376f68279f0750ee6d3868b8472368199763064'
SDK_REPOSITORY='vgong24/Vextreme-SDK'
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"

resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

BASH_BIN="$(resolve_exec /bin/bash)" || { printf '%s\n' 'PR384 A002: qualified Bash unavailable.' >&2; exit 10; }
GIT_BIN="$(resolve_exec /usr/bin/git)" || { printf '%s\n' 'PR384 A002: qualified Git unavailable.' >&2; exit 11; }
GH_BIN="$(resolve_exec /opt/homebrew/bin/gh /usr/local/bin/gh)" || { printf '%s\n' 'PR384 A002: qualified GitHub CLI unavailable.' >&2; exit 12; }
NODE_BIN="$(resolve_exec /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node)" || { printf '%s\n' 'PR384 A002: qualified Node unavailable.' >&2; exit 13; }
MKTEMP_BIN="$(resolve_exec /usr/bin/mktemp)" || { printf '%s\n' 'PR384 A002: qualified mktemp unavailable.' >&2; exit 14; }
RM_BIN="$(resolve_exec /bin/rm /usr/bin/rm)" || { printf '%s\n' 'PR384 A002: qualified rm unavailable.' >&2; exit 15; }

if /usr/bin/pgrep -f 'RUN-MAC-LOCAL-ASR-DISTRIBUTION-A001.command' >/dev/null 2>&1; then
  printf '%s\n' 'PR384 A002: the superseded A001 direct-run process is still alive. Stop that original terminal with Ctrl-C before running A002; no second business execution was started.' >&2
  exit 40
fi

"$GH_BIN" auth status --hostname github.com >/dev/null 2>&1 || {
  printf '%s\n' 'PR384 A002: GitHub authentication unavailable. Run: gh auth login --hostname github.com --web' >&2
  exit 41
}

FORMATION_ROOT="$("$MKTEMP_BIN" -d "$HOME/Downloads/.vexlife-pr384-a002-formation.XXXXXX")"
cleanup() {
  case "$FORMATION_ROOT" in
    "$HOME"/Downloads/.vexlife-pr384-a002-formation.*) "$RM_BIN" -rf -- "$FORMATION_ROOT" ;;
    *) return 1 ;;
  esac
}
trap cleanup EXIT HUP INT TERM

SDK_ROOT="$FORMATION_ROOT/Vextreme-SDK"
printf '%s\n' 'PR384 A002: acquiring exact current VexRelay/VexLocalBridge source for formation...'
"$GH_BIN" repo clone "$SDK_REPOSITORY" "$SDK_ROOT" -- --no-checkout >/dev/null
"$GIT_BIN" -C "$SDK_ROOT" checkout --detach "$SDK_HEAD" >/dev/null
OBSERVED_HEAD="$("$GIT_BIN" -C "$SDK_ROOT" rev-parse HEAD)"
OBSERVED_TREE="$("$GIT_BIN" -C "$SDK_ROOT" rev-parse 'HEAD^{tree}')"
[ "$OBSERVED_HEAD" = "$SDK_HEAD" ] || { printf '%s\n' 'PR384 A002: SDK head mismatch.' >&2; exit 42; }
[ "$OBSERVED_TREE" = "$SDK_TREE" ] || { printf '%s\n' 'PR384 A002: SDK tree mismatch.' >&2; exit 43; }
[ -z "$("$GIT_BIN" -C "$SDK_ROOT" status --porcelain=v1 -uall)" ] || { printf '%s\n' 'PR384 A002: acquired SDK source is dirty.' >&2; exit 44; }

"$NODE_BIN" -e 'const fs=require("node:fs");const p=process.argv[1];const x=JSON.parse(fs.readFileSync(p,"utf8"));if(x.contractRef!=="source.vexrelay.current-contract/v1")process.exit(45);' "$SDK_ROOT/docs/private-continuity/vexrelay/current-contract.json"

printf '%s\n' 'PR384 A002: forming and qualifying the canonical Relay task from current source...'
"$NODE_BIN" "$SCRIPT_DIR/formation.mjs" "$SDK_ROOT" "$HOME/Downloads"

[VXG RealForever]
PR #384 / companion #386 / Mac Local-ASR distribution SourceOwner A002

This is a formation carrier for one canonical VexRelay/VexLocalBridge host attempt.
It is not Product source and must not be merged.

A002 uses the current SDK source-managed primitives to:
- form an ExactHeadSourceOwnerProof task for exact #384 head/tree;
- wrap it in the current native VexRelay task-archive carrier;
- form the outer task window/digest with the current source-managed package builder;
- render and execute the current checkout-free macOS source bootstrap;
- return one canonical result.

No Local Workspace is used.
No Product launch, real Vex Home mutation, microphone, approval, READY, merge or release publication is part of this attempt.

A001 direct-run carriage remains preserved as superseded evidence and is not replayed.

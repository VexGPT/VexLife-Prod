#!/bin/bash
set -euo pipefail

SDK_HEAD='8543c7d755faba04d4c4019c02e84f992667918a'
SDK_TREE='6376f68279f0750ee6d3868b8472368199763064'
REPOSITORY='vgong24/Vextreme-SDK'
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"

resolve_exec() {
  local candidate
  for candidate in "$@"; do
    if [ -x "$candidate" ] && [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

GH="$(resolve_exec /opt/homebrew/bin/gh /usr/local/bin/gh)" || { echo 'PR384 A003: qualified GitHub CLI unavailable.' >&2; exit 10; }
GIT="$(resolve_exec /usr/bin/git)" || { echo 'PR384 A003: qualified Git unavailable.' >&2; exit 11; }
NODE="$(resolve_exec /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node)" || { echo 'PR384 A003: qualified Node unavailable.' >&2; exit 12; }
RM="$(resolve_exec /bin/rm /usr/bin/rm)" || exit 13
MKTEMP="$(resolve_exec /usr/bin/mktemp)" || exit 14

"$GH" auth status --hostname github.com >/dev/null 2>&1 || {
  echo 'PR384 A003: GitHub authentication unavailable.' >&2
  exit 15
}

ROOT="$("$MKTEMP" -d "$HOME/Downloads/.pr384-a003-sdk.XXXXXX")"
case "$ROOT" in
  "$HOME/Downloads"/.pr384-a003-sdk.*) ;;
  *) echo 'PR384 A003: bootstrap root escaped Downloads.' >&2; exit 16 ;;
esac
cleanup() {
  case "$ROOT" in
    "$HOME/Downloads"/.pr384-a003-sdk.*) "$RM" -rf -- "$ROOT" ;;
  esac
}
trap cleanup EXIT HUP INT TERM

SDK_ROOT="$ROOT/Vextreme-SDK"
"$GH" repo clone "$REPOSITORY" "$SDK_ROOT" -- --no-checkout >/dev/null
"$GIT" -C "$SDK_ROOT" checkout --detach "$SDK_HEAD" >/dev/null

OBS_HEAD="$("$GIT" -C "$SDK_ROOT" rev-parse HEAD)"
OBS_TREE="$("$GIT" -C "$SDK_ROOT" rev-parse 'HEAD^{tree}')"
[ "$OBS_HEAD" = "$SDK_HEAD" ] || { echo 'PR384 A003: SDK head mismatch.' >&2; exit 17; }
[ "$OBS_TREE" = "$SDK_TREE" ] || { echo 'PR384 A003: SDK tree mismatch.' >&2; exit 18; }
[ -z "$("$GIT" -C "$SDK_ROOT" status --porcelain=v1 -uall)" ] || { echo 'PR384 A003: acquired SDK source is dirty.' >&2; exit 19; }

"$NODE" -e 'const fs=require("node:fs");const p=process.argv[1];const x=JSON.parse(fs.readFileSync(p,"utf8"));if(x.contractRef!=="source.vexrelay.current-contract/v1")process.exit(20)' "$SDK_ROOT/docs/private-continuity/vexrelay/current-contract.json"

echo 'PR384 A003: exact current SDK/Relay source verified.'
exec "$NODE" "$SCRIPT_DIR/formation.mjs" "$SDK_ROOT" "$HOME/Downloads"

# PR #384 Mac Local-ASR SourceOwner A003

[VXG RealForever]

A002 proved that the current checkout-free Mac VexRelay/VexLocalBridge carriage works end-to-end:
outer admission/reservation, native inner execution, exact inner RETURN retention/consumption and
cleanup all passed.

The inner SourceOwner proof stopped at its first Gradle command because `compileKotlinJvm` exhausted
the default Java heap. The observable failure was `java.lang.OutOfMemoryError: Java heap space`;
there was no Kotlin source diagnostic, no Product mutation, no Vex Home mutation, and no microphone
effect.

A003 preserves the same SourceOwner `taskRef`, rotates attempt/request/correlation/package identity,
and repairs only the proof execution envelope:

- Gradle daemon heap: `-Xmx2048m`
- metaspace: `768m`
- reserved code cache: `512m`
- `--max-workers=1`

PR #384 Product bytes remain exact and unchanged.

The remaining proof is the same source/package threshold: JVM/JS/strings, exact Mac app/DMG
formation, exact pinned whisper.cpp provider identity, service launcher private-image-root binding,
and packaged `whisper-server --help`.

This formation carrier uses the current source-managed VexRelay producer and the checkout-free Mac
VexLocalBridge bootstrap. Local Workspace is not used.

<!-- [VXG RealForever][PR384][PR386][A003][HEAP-REPAIR][DO-NOT-MERGE] -->

VexLife Current Accepted Semantic Continuity — Relay Formation A001
[VXG RealForever]

Exact Product candidate
-----------------------
PR #284
base 6c86e72594ea57a890324a8b7a745244d7acc94d
head 153ba5f50089e22031335cf5c0a287f4ae35dfee
tree 5ea8df1d4743fe76a6c6b48b433f20e2da45d77a

Four-path proof membrane
------------------------
- docs/work/memory-current-accepted-semantic/README.md
- src/jvmMain/kotlin/vexlife/memory/VexLifeCurrentMemoryReader.kt
- src/jvmMain/kotlin/vexlife/memory/VexLifeCurrentAcceptedSemanticProjection.kt
- src/jvmTest/kotlin/vexlife/memory/VexLifeCurrentAcceptedSemanticProjectionTest.kt

Proof target
------------
- no Score -> EMPTY accepted-semantic projection;
- Keep -> accepted statement visible while Daily is still absent/held;
- unrelated later Conversation -> accepted statement remains current;
- observed Conversation head advances while Score-source head remains historical;
- projection reads perform no Home mutation.

The source-managed task runs:
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact four-path SourceOwner review

No prompt/provider/service/web/Daily/model/publication/merge effect is authorized.

Return one Finder-revealed ZIP beginning:
RETURN-VEXLIFE-MEMORY-CURRENT-ACCEPTED-SEMANTIC-SOURCEOWNER-A001--sha256-

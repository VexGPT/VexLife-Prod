#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const SDK_HEAD = '8543c7d755faba04d4c4019c02e84f992667918a';
const SDK_TREE = '6376f68279f0750ee6d3868b8472368199763064';
const CONTRACT_BLOB = 'b53cbac01c2deeb45fad5c32ce98e0796c04126f';

const BASE = '6c86e72594ea57a890324a8b7a745244d7acc94d';
const HEAD = '153ba5f50089e22031335cf5c0a287f4ae35dfee';
const TREE = '5ea8df1d4743fe76a6c6b48b433f20e2da45d77a';
const BRANCH = 'VXG-111726-memory-current-accepted-semantic-a001';
const BASE_BRANCH = 'main';
const PRODUCT_PATHS = Object.freeze([
  'docs/work/memory-current-accepted-semantic/README.md',
  'src/jvmMain/kotlin/vexlife/memory/VexLifeCurrentMemoryReader.kt',
  'src/jvmMain/kotlin/vexlife/memory/VexLifeCurrentAcceptedSemanticProjection.kt',
  'src/jvmTest/kotlin/vexlife/memory/VexLifeCurrentAcceptedSemanticProjectionTest.kt',
]);

const sdkRoot = process.argv[2];
const outputDirectory = process.argv[3];
if (!sdkRoot || !path.isAbsolute(sdkRoot)) throw new Error('SDK_ROOT_ABSOLUTE_REQUIRED');
if (!outputDirectory || !path.isAbsolute(outputDirectory)) throw new Error('OUTPUT_DIRECTORY_ABSOLUTE_REQUIRED');

function git(...args) {
  return spawnSync('/usr/bin/git', ['-C', sdkRoot, ...args], { encoding: 'utf8' });
}

const gitHead = git('rev-parse', 'HEAD');
if (gitHead.status !== 0 || gitHead.stdout.trim() !== SDK_HEAD) {
  throw new Error(`SDK_HEAD_MISMATCH:${gitHead.stdout.trim()}`);
}
const gitTree = git('rev-parse', 'HEAD^{tree}');
if (gitTree.status !== 0 || gitTree.stdout.trim() !== SDK_TREE) {
  throw new Error(`SDK_TREE_MISMATCH:${gitTree.stdout.trim()}`);
}
const contractBlob = git('rev-parse', `HEAD:docs/private-continuity/vexrelay/current-contract.json`);
if (contractBlob.status !== 0 || contractBlob.stdout.trim() !== CONTRACT_BLOB) {
  throw new Error(`SDK_CURRENT_CONTRACT_BLOB_MISMATCH:${contractBlob.stdout.trim()}`);
}
const dirty = git('status', '--porcelain=v1', '--untracked-files=all');
if (dirty.status !== 0 || dirty.stdout.trim()) {
  throw new Error(`SDK_SOURCE_NOT_CLEAN:${dirty.stdout.trim()}`);
}

const contractPath = path.join(
  sdkRoot,
  'docs/private-continuity/vexrelay/current-contract.json',
);
const contract = JSON.parse(fs.readFileSync(contractPath, 'utf8'));
if (contract.contractRef !== 'source.vexrelay.current-contract/v1') {
  throw new Error(`RELAY_CONTRACT_REF_MISMATCH:${contract.contractRef}`);
}
if (
  !contract.acceptedRecipeFamilies?.includes('ExactHeadSourceOwnerProof') ||
  !contract.acceptedAdapters?.some(
    (entry) =>
      entry.adapterRef === 'adapter.vexlocalbridge.native-vexrelay-task-archive/v1' &&
      entry.state === 'TERMINAL_ACCEPTED_CURRENT',
  )
) {
  throw new Error('RELAY_CURRENT_CONTRACT_REQUIRED_ROUTE_NOT_ACCEPTED');
}

for (const rel of [
  'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
  'lib/vexlocalbridge/vexrelay-task-archive.js',
  'lib/vexlocalbridge/package-builder.js',
  'lib/vexlocalbridge/templates/RUN-VEX-TASK.command',
  'lib/vexrelay/recipe-compiler.mjs',
]) {
  if (!fs.existsSync(path.join(sdkRoot, rel))) {
    throw new Error(`REQUIRED_SDK_SOURCE_MISSING:${rel}`);
  }
}

const formationModule = await import(
  pathToFileURL(
    path.join(
      sdkRoot,
      'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs',
    ),
  ).href,
);
const nativeCarrier = createRequire(import.meta.url)(
  path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js'),
);

const effects = [
  'READ_REPOSITORY',
  'CHECK_STATE',
  'QUERY_PROVIDER',
  'RUN_LOCAL_COMMAND',
  'FORM_RESULT',
];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexlife-prod.memory-current-accepted-semantic.source-owner.v1',
  attemptRef: 'attempt.vexlife-prod.memory-current-accepted-semantic.source-owner.a001',
  requestRef: 'request.vexlife-prod.memory-current-accepted-semantic.source-owner.a001',
  correlationRef: 'correlation.vexlife-prod.memory-current-accepted-semantic.source-owner.a001',
  packageRef: 'package.vexlife-prod.memory-current-accepted-semantic.source-owner.a001',
  original: {
    originalIntent:
      'Project current accepted semantic continuity immediately from validated Score membership and current semantic authority without taking prompt, service, provider, or Daily Dream ownership.',
    originalGoal:
      'Prove the exact PR #284 read-only current accepted-semantic projection on the qualified Mac source-owner surface.',
    userProtectedIntent:
      'Preserve Memory ownership: Daily freshness remains consolidation truth, current Score plus current semantic authority owns accepted semantic validity, projection reads perform no mutation, and prompt/service/web integration remains held.',
    sourceRefs: [
      'github.pull.VexGPT.VexLife-Prod.284',
      'github.pull.VexGPT.VexLife-Prod.285',
      'source.vexrelay.current-contract/v1',
      'vexarchitecture.first-stable-body',
      'vexarchitecture.live-demonstration',
    ],
  },
  lane: {
    entryClass: 'SAME_LANE_SUCCESSOR',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'lane.vexlife-prod.memory-current-accepted-semantic.a001',
    parentRootRef: 'root.vexlife-prod.memory-depth',
    workRef: 'work.vexlife.memory.current-accepted-semantic.a001',
    claimRef: 'work.vexlife.memory.current-accepted-semantic.a001',
    returnRouteRef: 'github.pull.VexGPT.VexLife-Prod.284',
    ownerRef: 'actor.chatgpt.memory-current-accepted-semantic',
    rootHubRef: 'github.repository.VexGPT.VexLife-Prod',
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexlife-prod.memory-current-accepted-semantic',
    instanceRef: 'instance.chatgpt.memory-current-accepted-semantic.relay.a001',
    occupancyRef: 'occupancy.vexlife-prod.memory-current-accepted-semantic.a001',
    providerBindingRef: 'provider.macos-victor.vexlife-prod.memory-current-accepted-semantic.a001',
    threadRef: 'thread.github.pull.VexGPT.VexLife-Prod.284',
    authorityEnvelopeRef: 'authority-envelope.user.memory-current-accepted-semantic.20261117a',
  },
  capabilities: {
    platformGitHubRead: 'AVAILABLE',
    platformGitHubWrite: 'AVAILABLE',
  },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexlife-prod-memory-current-accepted-semantic-sourceowner-a001',
    duplicateAttemptMarker: 'marker.vexlife-prod-memory-current-accepted-semantic-sourceowner-a001',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: new Date().toISOString(),
    expiresAtOrNull: null,
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexlife-prod.memory-current-accepted-semantic.proof',
    projectPath: 'workspace',
    createRoot: true,
    createProjectPath: true,
  },
  repositories: [
    {
      repositoryRef: 'primary',
      mode: 'CLONE_IN_WORKSPACE',
      cloneTransport: 'GIT',
      cloneUrl: 'https://github.com/VexGPT/VexLife-Prod.git',
      nameWithOwner: 'VexGPT/VexLife-Prod',
      localPath: 'repositories/primary',
      remote: 'origin',
      baseBranch: BASE_BRANCH,
      acceptedBase: BASE,
      checkoutRef: HEAD,
      expectedHead: HEAD,
      branch: BRANCH,
    },
  ],
  authority: {
    authorityRef: 'authority.user.vexlife-prod.memory-current-accepted-semantic.continue.20261117a',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: [...effects],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: [...effects],
    heldEffects: [
      'WRITE_SOURCE',
      'CREATE_COMMIT',
      'PUSH_BRANCH',
      'CREATE_PULL_REQUEST',
      'APPROVE_EXACT_HEAD',
      'MARK_READY',
      'ORDINARY_MERGE',
      'MODEL_RUNTIME_EFFECT',
      'HOME_MUTATION',
      'MEMORY_MUTATION',
    ],
    repositoryMembranes: [
      {
        repositoryRef: 'primary',
        allowedPaths: [...PRODUCT_PATHS],
      },
    ],
    allowedExecutables: ['bash'],
    allowedEnvironment: [],
    remoteObservationOwner: 'Operations',
    allowMutationLoop: false,
    stopConditions: [
      'STOP_ON_UNKNOWN',
      'STOP_ON_PATH_ESCAPE',
      'STOP_ON_AUTH_BLOCK',
      'STOP_ON_TEST_FAILURE',
    ],
  },
  source: {
    sourceSetRef: 'source-set.vexlife-prod.memory-current-accepted-semantic.pr284',
    sourceVersionRef: `git:${HEAD}`,
    overlapEvidenceRef: 'github.pull.VexGPT.VexLife-Prod.284',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: PRODUCT_PATHS.map((productPath) => ({
      repositoryRef: 'primary',
      path: productPath,
    })),
    intentionallyUnchangedAuthorizedPaths: [],
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 4,
    maxSelectedSourceBytes: 1500000,
    maxDiffBytes: 5000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: true,
    signoffCommit: true,
    draftPullRequest: true,
  },
};

const stage = {
  repositoryRef: 'primary',
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: BRANCH,
  proofCommands: [
    {
      command: 'bash',
      args: [
        './gradlew',
        '--no-daemon',
        'checkVexLifeStrings',
        '--stacktrace',
      ],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.memory-current-accepted-semantic.strings',
      timeoutMs: 1200000,
    },
    {
      command: 'bash',
      args: [
        './gradlew',
        '--no-daemon',
        'jvmTest',
        '--stacktrace',
      ],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.memory-current-accepted-semantic.jvm-suite',
      timeoutMs: 1800000,
    },
    {
      command: 'bash',
      args: [
        './gradlew',
        '--no-daemon',
        'compileKotlinJs',
        'compileTestKotlinJs',
        '--stacktrace',
      ],
      proofClass: 'TEST',
      candidateEvidence: true,
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexlife-prod.memory-current-accepted-semantic.common-js-compile',
      timeoutMs: 1200000,
    },
  ],
  maxFiles: 4,
  stateRef: 'state.vexlife-prod.memory-current-accepted-semantic.before-a001',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal:
    'Prove the exact latest-main #247 Consideration/Memory candidate including the Memory Family source-truth correction before merge.',
  remainingGoals: [
    'Consume the canonical RETURN and classify the exact first failure or PASS.',
    'If A001 passes, run fresh semantic Assurance over accepted-semantic currentness versus Daily snapshot freshness and read-only ownership.',
    'Then complete merge-readiness currentness and lifecycle disposition.',
    'Keep #230 prompt-coordinate integration as a separate coordinated successor edge.',
  ],
  onPass: {
    lifecycleState: 'ASSURANCE_PENDING',
    nextFunction: 'F13.RUN_FRESH_ASSURANCE',
    nextOwner: 'Operations',
    whyThisIsNext:
      'The exact PR #284 current accepted-semantic projection is proven; fresh semantic assurance and later prompt/service integration remain separate predicates.',
  },
  resultFilename: 'RETURN-VEXLIFE-MEMORY-CURRENT-ACCEPTED-SEMANTIC-SOURCEOWNER-A001.zip',
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef:
    'authority.user.vexlife-prod.memory-current-accepted-semantic.continue.20261117a',
  transactionRef: 'transaction.vexlife-prod.memory-current-accepted-semantic.sourceowner.a001',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: [
    'effect.source-mutation',
    'effect.publication',
    'effect.model-runtime',
    'effect.vexlife-home-mutation',
    'effect.memory-mutation',
    'effect.merge',
  ],
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexlife-prod.memory-current-accepted-semantic.sourceowner.outer.v1',
  attemptRef: 'attempt.vexlife-prod.memory-current-accepted-semantic.sourceowner.outer.a001',
  packageRef: 'package.vexlife-prod.memory-current-accepted-semantic.sourceowner.outer.a001',
  requestRef: 'request.vexlife-prod.memory-current-accepted-semantic.sourceowner.outer.a001',
  correlationRef: 'correlation.vexlife-prod.memory-current-accepted-semantic.sourceowner.outer.a001',
  taskStorageKey: 'vexlife-memory-current-accepted-semantic-pr284',
  attemptStorageKey: 'attempt-a001',
  requestingRoleRef: 'Operations[VexLifeMemoryCurrentAcceptedSemantic]',
  requestingInstanceRef: 'instance.chatgpt.memory-current-accepted-semantic.relay.a001',
  parentOperationsRef: 'github.pull.VexGPT.VexLife-Prod.284',
  returnRouteRef: 'github.pull.VexGPT.VexLife-Prod.285',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: 'VexGPT/VexLife-Prod',
  baseRefOrNull: BASE,
  headRefOrNull: HEAD,
  treeRefOrNull: TREE,
  branchRefOrNull: BRANCH,
  claimRefOrNull: 'work.vexlife.memory.current-accepted-semantic.a001',
  exactPathRefs: [...PRODUCT_PATHS],
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'pending-source-managed-binding',
    transactionRef: 'pending-source-managed-binding',
    transactionVersion: 1,
    allowedEffectRefs: ['pending-source-managed-binding'],
    heldEffectRefs: [],
  },
  payload: {
    payloadClass: nativeCarrier.VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: nativeCarrier.VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [
      {
        path: 'inputs/vexrelay-binding.json',
        sha256: '0'.repeat(64),
      },
    ],
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexlife-prod-memory-current-accepted-semantic-sourceowner-outer-a001',
  stopConditions: [
    'stop.on.identity.drift',
    'stop.on.test.failure',
    'stop.on.result.integrity',
  ],
  archiveDigestBinding: 'FILENAME_SHA256',
};

const formed = await formationModule.formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'Vex-Memory-Review-Keep-SourceOwner-A001',
  ttlMs: 12 * 60 * 60 * 1000,
});

if (formed.outer.formationEvidence.finalByteQualification !== 'PASS') {
  throw new Error('OUTER_FINAL_BYTE_QUALIFICATION_NOT_PASS');
}
if (formed.inner.manifest.source.candidateHead !== HEAD) {
  throw new Error('INNER_CANDIDATE_HEAD_DRIFT');
}
if (formed.inner.manifest.source.candidateTree !== TREE) {
  throw new Error('INNER_CANDIDATE_TREE_DRIFT');
}
if (formed.inner.manifest.source.expectedChangedPaths.length !== PRODUCT_PATHS.length) {
  throw new Error('INNER_CHANGED_PATH_MEMBRANE_DRIFT');
}

process.stdout.write(
  JSON.stringify(
    {
      state: 'FORMED',
      outerZip: formed.outer.finalZip,
      outerSha256: formed.outer.digest,
      candidateHead: HEAD,
      candidateTree: TREE,
      innerTaskRef: formed.inner.manifest.taskRef,
      stageGate: formed.inner.manifest.completionPolicy.stageGateOrNull,
    },
    null,
    2,
  ) + '\n',
);

const runner = path.join(
  sdkRoot,
  'lib/vexlocalbridge/templates/RUN-VEX-TASK.command',
);
const child = spawnSync('/bin/bash', [runner, formed.outer.finalZip], {
  cwd: outputDirectory,
  encoding: 'utf8',
  maxBuffer: 64 * 1024 * 1024,
});

if (child.stdout) process.stdout.write(child.stdout);
if (child.stderr) process.stderr.write(child.stderr);

if (child.status !== 0) {
  throw new Error(`ACCEPTED_MAC_RUNNER_EXIT:${child.status}`);
}

const matches = [
  ...String(child.stdout || '').matchAll(/"resultZip"\s*:\s*"([^"]+)"/g),
];
if (!matches.length) {
  throw new Error('CANONICAL_RETURN_PATH_NOT_OBSERVED');
}
const canonicalReturn = matches[matches.length - 1][1];
if (!path.isAbsolute(canonicalReturn) || !fs.existsSync(canonicalReturn)) {
  throw new Error(`CANONICAL_RETURN_UNREADABLE:${canonicalReturn}`);
}

const returnBytes = fs.readFileSync(canonicalReturn);
const returnSha256 = crypto.createHash('sha256').update(returnBytes).digest('hex');
const carrierName =
  `RETURN-VEXLIFE-MEMORY-REVIEW-KEEP-SOURCEOWNER-A001--sha256-${returnSha256}.zip`;
const carrierPath = path.join(outputDirectory, carrierName);

if (fs.existsSync(carrierPath)) {
  const existing = fs.readFileSync(carrierPath);
  const existingSha256 = crypto.createHash('sha256').update(existing).digest('hex');
  if (existingSha256 !== returnSha256) {
    throw new Error(`RETURN_CARRIER_CONFLICT:${carrierPath}`);
  }
} else {
  fs.copyFileSync(canonicalReturn, carrierPath, fs.constants.COPYFILE_EXCL);
}
const copied = fs.readFileSync(carrierPath);
const copiedSha256 = crypto.createHash('sha256').update(copied).digest('hex');
if (copiedSha256 !== returnSha256) {
  throw new Error('RETURN_CARRIER_COPY_DRIFT');
}

spawnSync('/usr/bin/open', ['-R', carrierPath], {
  encoding: 'utf8',
  maxBuffer: 1024 * 1024,
});

process.stdout.write(
  [
    '',
    'VEX_MEMORY_REVIEW_KEEP_SOURCEOWNER_A001_COMPLETE',
    `CANONICAL_RETURN_ZIP=${canonicalReturn}`,
    `CANONICAL_RETURN_SHA256=${returnSha256}`,
    `UPLOAD_THIS_ZIP=${carrierPath}`,
    '',
  ].join('\n'),
);

VexLife Current Accepted Semantic Continuity — Relay Formation A002
[VXG RealForever]

Why A002 exists
---------------
A001 passed exact-head SourceOwner proof, then fresh semantic Assurance found one bounded law gap:
the projection treated every current Score statement as accepted continuity.

The corrected PR #284 now reuses the existing Daily accepted-continuity law:

current in Score
+ acceptedForContinuity = true
+ positive consent (PERMITTED or NARROWED)
+ exact current semantic-authority membership
= current accepted semantic continuity

A current Score statement that is held/deferred/non-consent-admitted is not projected merely because
it is current in Score.

A001 remains immutable PASS evidence in TEMP RELAY PR #285.

Exact Product candidate
-----------------------
base 6c86e72594ea57a890324a8b7a745244d7acc94d
head 0ad04255e429aefe7850cbbb18c523a337cac9e2
tree ace6fcdeaea72a9815bdcc008eb2904b0454d52e
branch VXG-111726-memory-current-accepted-semantic-a001
PR #284

Proof
-----
1. checkVexLifeStrings
2. full jvmTest
3. compileKotlinJs + compileTestKotlinJs
4. exact four-path SourceOwner review

No prompt/provider/service/web/Daily/model/publication/merge effect is authorized.

Return
------
Upload the Finder-revealed ZIP beginning:

RETURN-VEXLIFE-MEMORY-CURRENT-ACCEPTED-SEMANTIC-SOURCEOWNER-A002--sha256-

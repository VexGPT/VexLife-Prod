VexLife Memory / Consideration — Relay Formation Bundle A002
[VXG RealForever]

Why this exists
---------------
The canonical VexRelay/VexLocalBridge task ZIP is time-bounded by the current contract
(formedAt/expiresAt). This stable digest-bound formation bundle forms the fresh canonical task on
Victor's Mac at execution time and keeps attempt history in temporary Relay PR #254 rather than in
Product source PR #247.

One run
-------
1. acquires exact Vextreme-SDK source;
2. verifies SDK head/tree/current-contract blob and source.vexrelay.current-contract/v1;
3. forms a fresh ExactHeadSourceOwnerProof package for exact PR #247;
4. executes the exact Product candidate through the accepted macOS VexLocalBridge runner;
5. runs separate checkVexLifeStrings, full jvmTest, and Kotlin/JS main+test compile gates;
6. forms the exact local review snapshot over the nine PR #247 Product paths;
7. copies the canonical outer RETURN ZIP byte-for-byte into ~/Downloads and reveals it.


A001 predecessor
----------------
A001 reached full Product JVM execution and exposed one fixture-only source-binding defect:
proposal.sourceEventHashes supplied only the RESPONSE event, while the existing Score owner requires
complete REQUEST + RESPONSE pairs. PR #247 corrected only that test fixture and advanced to the exact
head/tree above. A001 remains immutable history in PR #254; A002 re-runs the same SourceOwner gate.

Bound VexLife-Prod source
-------------------------
base:
b0b6fb9a6107f2475ae434472ed13335a303af87

exact Product candidate head:
db0bda47aebb77e5df58e55545fa76eb9b42e4c4

exact Product candidate tree:
dbb07f55d86cdfaffc76391bf0be26eeb3564349

Product branch:
VXG-111726-memory-consideration-foundation-a001

Product PR:
#247

Temporary Relay history PR:
#254

Bound SDK formation source
--------------------------
head 8543c7d755faba04d4c4019c02e84f992667918a
tree 6376f68279f0750ee6d3868b8472368199763064
current-contract blob b53cbac01c2deeb45fad5c32ce98e0796c04126f
contractRef source.vexrelay.current-contract/v1
recipe ExactHeadSourceOwnerProof
carrier adapter.vexlocalbridge.native-vexrelay-task-archive/v1
host macos-victor

Attempt-history guards
----------------------
- no retained-SDK / VEX_HOME assumption;
- exact SDK source is acquired checkout-free for this formation;
- Gradle string/JVM/JS gates are separate commands;
- no filtered --tests argument can leak into checkVexLifeStrings;
- Product candidate head/tree stay distinct from Relay carriage commits;
- current head advances nowhere: this task is read/test/review/result only;
- review membrane contains all nine Product candidate paths;
- A001 remains preserved; any new harness/transport failure stays A002 history and is not rewritten into Product failure.

Human return
------------
Upload the file revealed in Finder whose name begins:
RETURN-VEXLIFE-MEMORY-CONSIDERATION-SOURCEOWNER-A002--sha256-

No source mutation, push, merge, Product Home mutation, Memory mutation, model-runtime effect or
publication is authorized.
